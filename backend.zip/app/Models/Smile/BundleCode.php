<?php

namespace App\Models\Smile;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BundleCode extends Model
{
    use HasFactory;
    public $table = 'smile_bundle_code';
}
