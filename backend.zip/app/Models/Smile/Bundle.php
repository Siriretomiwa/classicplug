<?php

namespace App\Models\Smile;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Bundle extends Model
{
    use HasFactory;
    public $table = 'smile_bundle';
}
