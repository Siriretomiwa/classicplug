<?php

namespace App\Models\Cable;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CableCode extends Model
{
    use HasFactory;
    public $table = "cable_code";
}
