<?php

namespace App\Models\Airtime;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AirtimeList extends Model
{
    use HasFactory;
    public $table = "airtime_list";
}
