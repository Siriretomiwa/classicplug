<?php

namespace App\Models\Host;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HostSwitch extends Model
{
    use HasFactory;
    public $table = "host_switch";
}
