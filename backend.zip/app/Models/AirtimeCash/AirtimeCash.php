<?php

namespace App\Models\AirtimeCash;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AirtimeCash extends Model
{
    use HasFactory;
    public $table = "airtime_cash";
}
