<?php

namespace App\Models\Spectranet;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Spectranet extends Model
{
    use HasFactory;
    public $table = "spectranet";
}
