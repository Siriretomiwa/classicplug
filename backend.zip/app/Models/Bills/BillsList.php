<?php

namespace App\Models\Bills;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BillsList extends Model
{
    use HasFactory;
    public $table = "bills_list";
}
