<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class ReferralController extends Controller
{
    //

    protected function log(Request $request) {
            if ($request->ajax()) {
                $entries = $request->entries;
                $search = $request->search;
                $query =  DB::table('referral')->orderBy('id', 'desc')->where('referred_by', 'like', '%'.$search.'%')->paginate($entries);
            $table =  "<table id='table' class='table table-striped table-bordered' style='width:100%'>
            <thead>
                <tr>
                    <th>S/N</th>
                    <th>Username</th>
                    <th>Referred By</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>";

            $i = ($query->perPage() * ($query->currentPage() - 1)) + 1;
            foreach ($query as $referral)  {
            $serialNumber = $i++;
             $table .=  "<tr>
                    <td>{$serialNumber}</td>
                    <td>{$referral->username}</td>
                    <td>{$referral->referred_by}</td>
                    <td>
                    <button class='btn btn-danger btn-sm' data-toggle='tooltip' id='delete' data-id=". $referral->id ." style='padding: 8px'> <i class='fas fa-trash action_icon' style='font-size: 10px;'></i> </button>
                    </td>
                </tr>";
            }

            $table .= "</tbody>
        </table>
        <div class='float-start'> Showing ". $query->firstItem() ." to ". $query->lastItem() ." of ". $query->total() ." entries</div>
        <div class='float-end mt-4 mb-2'>". $query->links('pagination::bootstrap-4') ."</div>";

            return $table;


            } else {
                return view('referral.log');
            }
    }





// Delete Referral
    protected function delete(Request $request) {
        if ($request->ajax()) {
            if (!empty($request)) {
                if (!empty($request->id)) {
                    $id = $request->id;
                    $query = DB::table('referral')->where(['id' => $id])->get();
                    if ($query->count() == 1) {
                        $query =  DB::table('referral')->where(['id' => $id])->delete();
                    if($query) {
                        return response()->json(["code" => 200, "message" => "Row successfully deleted"]);
                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                    }

                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                    }
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            }
        }
    }


// Referral Earnings


    protected function earning(Request $request) {
        if ($request->ajax()) {
            $entries = $request->entries;
            $search = $request->search;
            $query =  DB::table('earnings')->orderBy('id', 'desc')->where('username', 'like', '%'.$search.'%')->paginate($entries);
        $table =  "<table id='table' class='table table-striped table-bordered' style='width:100%'>
        <thead>
            <tr>
                <th>S/N</th>
                <th>Username</th>
                <th>Description</th>
                <th>Amount</th>
                <th>Date</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>";

        $i = ($query->perPage() * ($query->currentPage() - 1)) + 1;
        foreach ($query as $referral)  {
        $serialNumber = $i++;
         $table .=  "<tr>
                <td>{$serialNumber}</td>
                <td>{$referral->username}</td>
                <td>{$referral->description}</td>
                <td>{$referral->amount}</td>
                <td>{$referral->date}</td>
                <td>
                <button class='btn btn-danger btn-sm' data-toggle='tooltip' id='delete' data-id=". $referral->id ." style='padding: 8px'> <i class='fas fa-trash action_icon' style='font-size: 10px;'></i> </button>
                </td>
            </tr>";
        }

        $table .= "</tbody>
    </table>
    <div class='float-start'> Showing ". $query->firstItem() ." to ". $query->lastItem() ." of ". $query->total() ." entries</div>
    <div class='float-end mt-4 mb-2'>". $query->links('pagination::bootstrap-4') ."</div>";

        return $table;


        } else {
            return view('referral.earnings');
        }
}






// Delete Referral
protected function deleteEarning(Request $request) {
    if ($request->ajax()) {
        if (!empty($request)) {
            if (!empty($request->id)) {
                $id = $request->id;
                $query = DB::table('earnings')->where(['id' => $id])->get();
                if ($query->count() == 1) {
                    $query =  DB::table('earnings')->where(['id' => $id])->delete();
                if($query) {
                    return response()->json(["code" => 200, "message" => "Row successfully deleted"]);
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }

                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
            }
        }
    }
}







    protected function commission(Request $request) {
        if ($request->ajax()) {

            $validator = Validator::make($request->all(),[
                'bonus'=>'nullable',
                "subsequent_bonus" => 'nullable',
                "bonus_type" => 'required|string',
                "minimum_withdrawal" => 'nullable|numeric'
             ]);

              if ($validator->fails())  {
                    $error = $validator->errors()->first();
                    return response()->json(["code" => 500, "type" => "error", "message" => $error]);
              } else {
                  $app = new AppController();
                  $bonus = $app->sanitize($request->bonus);
                  $subsequent_bonus = $app->sanitize($request->subsequent_bonus);
                  $bonus_type = $app->sanitize($request->bonus_type);
                  $minimum_withdrawal = $app->sanitize($request->minimum_withdrawal);
                  $query = DB::table('commission')->get();
                  if ($bonus !== "" || $subsequent_bonus !== "") {
                    if ($query->count() == 0) {
                        $insert = DB::table('commission')->insert([
                            'bonus' => $bonus,
                            'subsequent_bonus' => $subsequent_bonus,
                            'bonus_type' => $bonus_type,
                            'minimum_withdrawal' => $minimum_withdrawal
                        ]);
                        if ($insert) {
                            return response()->json(["code" => 200, "type" => "success", "message" => "Commission successfully saved"]);
                        } else {
                            return response()->json(["code" => 500, "type" => "error", "message" => "A critical error ocurred"]);
                        }

                    } else {

                        DB::table('commission')->update([
                            'bonus' => $bonus,
                            'subsequent_bonus' => $subsequent_bonus,
                            'bonus_type' => $bonus_type,
                            'minimum_withdrawal' => $minimum_withdrawal
                        ]);
                            return response()->json(["code" => 200, "type" => "success", "message" => "Commission successfully updated"]);
                    }
                  } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Please fill the blank fields"]);
                  }
              }

        } else {
            $query = DB::table('commission')->first();
            return view('referral.commission', ["referral" => $query]);
        }
    }







}
