<?php

namespace App\Http\Controllers\Exam;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\Category\Category;
use App\Models\Exam\ExamList;
use App\Http\Controllers\AppController;
use Illuminate\Support\Facades\Validator;

class ExamPriceController extends Controller
{
    //



    public function index(Request $request) {
        $app = new AppController();
        $category = $app->sanitize($request->category);
        if ($request->ajax()) {
            if (!empty($category)) {
            $list = ExamList::where(["category" => $category])->get();
                if ($list->count() !== 0) {
                $table =  "<table id='table' class='table table-striped table-bordered' style='width:100%'>
                <thead>
                    <tr>
                        <th>S/N</th>
                        <th>Exam</th>
                        <th>Name</th>
                        <th>Amount(&#8358;) Per Quantity</th>
                    </tr>
                </thead>
                <tbody>";
                $init = 1;
                foreach ($list as $exam)  {
                $serialNumber = $init++;
                $table .=  "<tr>
                        <td>{$serialNumber}</td>
                        <td>{$exam->exam}</td>
                        <td>{$exam->name}</td>
                        <td><input type='number' data-id='$exam->id' name='amount[]' class='form-control form-white' value='$exam->amount' style='width: 150px'/></td>
                    </tr>";
                }

            $table .= "</tbody>
        </table>
        <br/>
        <button type='button' class='btn btn-block btn-secondary waves-effect waves-light' id='proceed' style='padding-top: 10px;'> <span id='btn-spinner'></span> <span id='btn-txt'> Save <i class='fas fa-save'></i></span></button>";

            return $table;

                } else {
                    echo "<script> alert('No result found for this category');</script>";
                }
            } else {
                echo "<script> alert('No result found for this category');</script>";
            }
        } else {
            return view("exam.price", ['categories' => Category::all()]);
        }

}



protected function update(Request $request) {
    if (!empty($request)) {
        if (!empty($request->amount)) {
            foreach ($request->amount as $amount) {
                $id = $amount["id"];
                if (empty($amount["value"])){
                    $amount = "";
                } else {
                    $amount = $amount["value"];
                }
                if (is_numeric($amount) || $amount == '') {
                    ExamList::where(["id" => $id])->update(["amount" => $amount]);
                }
            }

            return response()->json(["code" => 200, "message" => "Amount successfully saved"]);
        }
    }
}






protected function merge(Request $request) {
    if ($request->ajax()) {
        $validator = Validator::make($request->all(),[
            'category_1'=>'required',
            'category_2' => 'required',
         ]);
          if ($validator->fails())  {
                $error = $validator->errors()->first();
                return response()->json(["code" => 500, "type" => "error", "message" => $error]);
          } else {
            $app = new AppController();
            $category_1 = $app->sanitize($request->category_1);
            $category_2 = $app->sanitize($request->category_2);
            if ($app->getCategory($category_1)->count() == 1 && $app->getCategory($category_1)->count() == 1) {
                $query = ExamList::where('category', $category_1)->get();
                foreach ($query as $row) {
                    ExamList::where(['exam_id' => $row->exam_id, 'category' => $category_2])->update([
                        'amount' => $row->amount,
                    ]);
                }
                return response()->json(["code" => 200, "type" => "success", "message" => "Merging successfully done"]);
            } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "An invalid host received"]);
            }
          }
    }
}








}
