<?php

namespace App\Http\Controllers\Exam;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\Exam\Exam;
use App\Models\Exam\ExamPin;
use App\Http\Controllers\AppController;
use Illuminate\Support\Facades\Validator;

class ExamPinController extends Controller
{
    //

    protected function index(Request $request) {
        if ($request->ajax()) {
            $query =  ExamPin::orderBy('status')->paginate(100);
        if ($query->count() > 0) {
        $table =  "<table id='table' class='table table-striped table-bordered' style='width:100%'>
        <thead>
            <tr>
            <th><div class='custom-control custom-switch'>
            <input class='form-check-input' id='allCheck' type='checkbox' value=''>
            </div></th>
                <th>S/N</th>
                <th>Exam</th>
                <th>Pin</th>
                <th>Serial Number</th>
                <th>Status</th>
                <th style='padding-right: 50px;'>Action</th>
            </tr>
        </thead>
        <tbody>";
        $i = ($query->perPage() * ($query->currentPage() - 1)) + 1;
        foreach ($query as $exam)  {
        $serialNumber = $i++;
        if ($exam->status == "available") {
            $checked = "checked";
        } else {
            $checked = "";
        }
         $table .=  "<tr>
         <td><div class='custom-control custom-switch'>
         <input class='form-check-input checkbox' type='checkbox' name='checkbox[]' data-id=". $exam->id ." value=''>
         </div>
         </td>
                <td>{$serialNumber}</td>
                <td>{$exam->exam}</td>
                <td>{$exam->pin}</td>
                <td>{$exam->serial_number}</td>
                <td>

                <div class='custom-control custom-switch'>
                <input type='checkbox' class='custom-control-input toggleSwitch' data-id=". $exam->id ." id='customSwitches$serialNumber' $checked>
                <label class='custom-control-label' for='customSwitches$serialNumber'></label>
              </div>

                </td>
                <td>
                <button class='btn btn-success btn-sm' data-toggle='tooltip'  id='edit' data-id=". $exam->id ." style='background-color: #2dbe60; padding: 8px; margin-right: 8px'> <i class='fas fa-edit action_icon' style='font-size: 10px;'></i> </button>
                <button class='btn btn-danger btn-sm' data-toggle='tooltip' id='delete' data-id=". $exam->id ." style='padding: 8px'> <i class='fas fa-trash action_icon' style='font-size: 10px;'></i> </button>
            </td>
            </tr>";
        }

        $table .= "</tbody>
            </table>
        </div>
        <div class='mt-3'>
      <div class='text-center'> Showing ". $query->firstItem() ." to ". $query->lastItem() ." of ". $query->total() ." entries</div>
      <div class='text-center mt-4 mb-2'>".
          // $query->links('pagination::bootstrap-4')
          $query->links('pagination::simple-tailwind')
      ."</div></div>";
          return $table;

      } else {
         $notFound = "<div class='text-center'>
              <img src='/images/no-result-found.png' width='200px' />
         </div>";
         return $notFound;
      }

        } else {
            $stat = [];
            $exams = Exam::all();
            if ($exams->count() > 0) {
                foreach($exams as $exam) {
                    $available = $this->countPIN($exam->exam, 'available');
                    $unavailable = $this->countPIN($exam->exam, 'unavailable');
                    $arr = [
                            "exam" => $exam->exam,
                            "available" => $available,
                            "unavailable" => $unavailable,
                    ];
                    array_push($stat, $arr);
                }
            }
            return view('exam.pin',['exams' => Exam::all(), 'stat' => $stat]);
        }
    }



    private function countPIN($exam, $status) {
        $count = ExamPin::where(['exam' => $exam, 'status' => $status])->count();
        return $count;
    }



/*******************************************************************************************************/


    protected function create(Request $request) {
        if ($request->ajax()) {
            $validator = Validator::make($request->all(),[
                'exam'=>'required',
                'pin' => 'required',
                'status'=>'required',
             ]);

              if ($validator->fails())  {
                    $error = $validator->errors()->first();
                    return response()->json(["code" => 500, "type" => "error", "message" => $error]);
              } else {
                  $app = new AppController();
                  $exam = $app->sanitize($request->exam);
                  $pin = $app->sanitize($request->pin);
                  $serialNumber = $app->sanitize($request->serialNumber);
                  $status = $app->sanitize($request->status);
                  $examQuery = Exam::where(["exam" => $exam])->get();
                  if ($examQuery->count() == 1) {
                      if (empty($serialNumber)) {
                          $serialNumber = "null";
                      }
                  $query = ExamPin::where(["exam" => $exam, "pin" => $pin]);
                  $count = ExamPin::all()->count();
                  $row = Exam::where(["exam" => $exam,])->get();
                  if ($query->count() == 0) {
                      if ($row->count() == 1) {
                    $exam_id = $count + 1;
                      $examPin = new ExamPin();
                      $examPin->key = $exam_id;
                      $examPin->exam = strtoupper($exam);
                      $examPin->pin = $pin;
                      $examPin->serial_number = $serialNumber;
                      $examPin->exam_id = $examQuery[0]->id;
                      $examPin->user = "";
                      $examPin->ref = "";
                      $examPin->status = $status;
                     if ($examPin->save()){
                        return response()->json(["code" => 200, "type" => "success", "message" => "PIN successfully saved"]);
                     } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "A critical error occured"]);
                     }

                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Invalid Exam"]);
                      }

                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Exam pin already exist"]);
                      }


                  } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Invalid exam"]);
                  }



              }
        }
    }



/*******************************************************************************************************/


    protected function statusUpdate(Request $request) {
        if ($request->ajax()) {
            if (!empty($request)) {
                if (!empty($request->id) && !empty($request->status)) {
                    $app = new AppController();
                    $id = $app->sanitize($request->id);
                    $status = $app->sanitize($request->status);
                    $query = ExamPin::where(['id' => $id])->get();
                    if ($query->count() == 1) {
                        $query = ExamPin::where(['id' => $id])->update(['status' => $status]);
                    if($query) {
                        return response()->json(["code" => 200, "status" => $status, "message" => "Status successfully set ".$status]);
                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                    }

                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                    }
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            }
        }
    }



/*******************************************************************************************************/


    protected function delete(Request $request) {
        if ($request->ajax()) {
            if (!empty($request)) {
                if (!empty($request->id)) {
                    $id = $request->id;
                    $query = ExamPin::where(['id' => $id])->get();
                    if ($query->count() == 1) {
                        $query = ExamPin::where(['id' => $id])->delete();
                    if($query) {
                        return response()->json(["code" => 200, "message" => "Exam successfully deleted"]);
                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                    }

                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                    }
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            }
        }
    }



/*******************************************************************************************************/

protected function action(Request $request) {
    if ($request->ajax()) {
        if (!empty($request)) {
            if (!empty($request->arr) && !empty($request->action)) {
                foreach ($request->arr as $arr) {
                    if ($request->action == "delete") {
                     $query = ExamPin::where(['id' => $arr])->delete();
                    } else  {
                     $query = ExamPin::where(['id' => $arr])->update(['status' => $request->action]);
                    }
                }
                if($query) {
                    return response()->json(["code" => 200, "message" => "Action successfully processed"]);
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
            }
        }
    }
}

/*******************************************************************************************************/

protected function edit(Request $request) {
    if ($request->ajax()) {
        if (!empty($request)) {
            if (!empty($request->id)) {
                $id = $request->id;
                $query = ExamPin::where(['id' => $id])->get();
                if ($query->count() == 1) {
                    $query = $query->first();
                    return response()->json(["code" => 200, "data" => [
                        'id' => $query->id,
                        'exam' => $query->exam,
                        'pin' => $query->pin,
                        'serialNumber' => $query->serial_number,
                        'status' => $query->status,
                    ]]);
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
            }
        }
    }
}







protected function update(Request $request) {
    if ($request->ajax()) {
        $validator = Validator::make($request->all(),[
            'id'=>'required',
            'exam'=>'required',
            'serialNumber'=>'required',
            'pin'=>'required',
            'status'=>'required',
         ]);

          if ($validator->fails())  {
                $error = $validator->errors()->first();
                return response()->json(["code" => 500, "type" => "error", "message" => $error]);
          } else {
              $app = new AppController();
              $id = $app->sanitize($request->id);
              $exam = strtoupper($app->sanitize($request->exam));
              $pin = $app->sanitize($request->pin);
              $serialNumber = $app->sanitize($request->serialNumber);
              $status = $app->sanitize($request->status);
              $query = ExamPin::where(["id" => $id]);
              $row = Exam::where(["exam" => $exam,])->get();
              if ($query->count() == 1) {
                  if ($row->count() == 1) {
                $query = $query->first();
                if ($exam !== $query->exam || $pin !== $query->pin || $serialNumber !== $query->serial_number || $status !== $query->status) {
                    $query = ExamPin::where(['id' => $id])->update(['pin' => $pin, 'exam' => $exam, 'exam_id' => $row[0]->id, 'serial_number' => $serialNumber, 'status' => $status]);
                 if ($query) {
                    return response()->json(["code" => 200, "type" => "success", "message" => "Exam pin successfully updated"]);
                 } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong!!"]);
                 }


                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "No change was made"]);
                  }

                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Invalid Exam"]);
                  }

              } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong!!"]);
              }

          }
    }
}










}
