<?php

namespace App\Http\Controllers\Exam;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\Exam\Exam;
use App\Models\Exam\ExamList;
use App\Models\Category\Category;
use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\AppController;

class ExamController extends Controller
{
    //



    protected function index(Request $request) {
        if ($request->ajax()) {
            $query =  Exam::all();
        $table =  "<table id='table' class='table table-striped table-bordered' style='width:100%'>
        <thead>
            <tr>
            <th><div class='custom-control custom-switch'>
            <input class='form-check-input' id='allCheck' type='checkbox' value=''>
            </div></th>
                <th>S/N</th>
                <th>Exam</th>
                <th>Name</th>
                <th>Status</th>
                <th style='padding-right: 50px;'>Action</th>
            </tr>
        </thead>
        <tbody>";
        $init = 1;
        foreach ($query as $exam)  {
        $serialNumber = $init++;
        if ($exam->status == "available") {
            $checked = "checked";
        } else {
            $checked = "";
        }
         $table .=  "<tr>
         <td><div class='custom-control custom-switch'>
         <input class='form-check-input checkbox' type='checkbox' name='checkbox[]' data-id=". $exam->id ." value=''>
         </div>
         </td>
                <td>{$serialNumber}</td>
                <td>{$exam->exam}</td>
                <td>{$exam->name}</td>
                <td>

                <div class='custom-control custom-switch'>
                <input type='checkbox' class='custom-control-input toggleSwitch' data-id=". $exam->id ." id='customSwitches$serialNumber' $checked>
                <label class='custom-control-label' for='customSwitches$serialNumber'></label>
              </div>

                </td>
                <td>
                <button class='btn btn-success btn-sm' data-toggle='tooltip'  id='edit' data-id=". $exam->id ." style='background-color: #2dbe60; padding: 8px; margin-right: 8px'> <i class='fas fa-edit action_icon' style='font-size: 10px;'></i> </button>
                <button class='btn btn-danger btn-sm' data-toggle='tooltip' id='delete' data-id=". $exam->id ." style='padding: 8px'> <i class='fas fa-trash action_icon' style='font-size: 10px;'></i> </button>
            </td>
            </tr>";
        }

        $table .= "</tbody>
    </table>";

        return $table;


        } else {
            return view('exam.exam');
        }
    }


/*******************************************************************************************************/


    private function examList($id, $key, $name, $exam, $status, $category) {
        $resultChecker = new ExamList();
        $resultChecker->key = $key;
        $resultChecker->exam_id = $id;
        $resultChecker->name = $name;
        $resultChecker->exam = strtoupper($exam);
        $resultChecker->category = $category;
        $resultChecker->amount = "";
        $resultChecker->status = $status;
        if ($resultChecker->save()) {
            return true;
        }
    }


/*******************************************************************************************************/

protected function edit(Request $request) {
    if ($request->ajax()) {
        if (!empty($request)) {
            if (!empty($request->id)) {
                $id = $request->id;
                $query = Exam::where(['id' => $id])->get();
                if ($query->count() == 1) {
                    $query = $query->first();
                    return response()->json(["code" => 200, "data" => [
                        'id' => $query->id,
                        'exam' => $query->exam,
                        'name' => $query->name,
                        'status' => $query->status,
                    ]]);
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
            }
        }
    }
}

/*******************************************************************************************************/



    protected function create(Request $request) {
        if ($request->ajax()) {
            $validator = Validator::make($request->all(),[
                'exam'=>'required',
                'name' => 'required',
                'status'=>'required',
             ]);

              if ($validator->fails())  {
                    $error = $validator->errors()->first();
                    return response()->json(["code" => 500, "type" => "error", "message" => $error]);
              } else {
                  $app = new AppController();
                  $exam = $app->sanitize($request->exam);
                  $name = $app->sanitize($request->name);
                  $status = $app->sanitize($request->status);
                  $query = Exam::where(["exam" => $exam, "name" => $name]);
                  $count = Exam::all()->count();
                  if ($query->count() == 0) {
                    $exam_key = $count + 1;
                      $resultChecker = new Exam();
                      $resultChecker->key = $exam_key;
                      $resultChecker->exam = strtoupper($exam);
                      $resultChecker->name = $name;
                      $resultChecker->status = $status;
                     if ($resultChecker->save()){
                        $query = Category::all();
                        foreach ($query as $category) {
                            $this->examList($resultChecker->id, $exam_key, $name, $exam, $status, $category->name);
                        }

                        return response()->json(["code" => 200, "type" => "success", "message" => "Exam successfully saved"]);
                     } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "A critical error occured"]);
                     }


                  } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Exam already exist"]);
                  }


              }
        }
    }



/*******************************************************************************************************/

    protected function action(Request $request) {
        if ($request->ajax()) {
            if (!empty($request)) {
                if (!empty($request->arr) && !empty($request->action)) {
                    foreach ($request->arr as $arr) {
                        if ($request->action == "delete") {
                         $query = Exam::where(['id' => $arr])->delete();
                                  ExamList::where(['exam_id' => $arr])->delete();
                        } else  {
                         $query = Exam::where(['id' => $arr])->update(['status' => $request->action]);
                                  ExamList::where(['exam_id' => $arr])->update(['status' => $request->action]);
                        }
                    }
                    if($query) {
                        return response()->json(["code" => 200, "message" => "Action successfully processed"]);
                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                    }
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            }
        }
    }

/*******************************************************************************************************/

    protected function statusUpdate(Request $request) {
        if ($request->ajax()) {
            if (!empty($request)) {
                if (!empty($request->id) && !empty($request->status)) {
                    $app = new AppController();
                    $id = $app->sanitize($request->id);
                    $status = $app->sanitize($request->status);
                    $query = Exam::where(['id' => $id])->get();
                    if ($query->count() == 1) {
                        $query = Exam::where(['id' => $id])->update(['status' => $status]);
                        ExamList::where(['exam_id' => $id])->update(['status' => $status]);
                    if($query) {
                        return response()->json(["code" => 200, "status" => $status, "message" => "Status successfully set ".$status]);
                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                    }

                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                    }
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            }
        }
    }


/*******************************************************************************************************/

    protected function delete(Request $request) {
        if ($request->ajax()) {
            if (!empty($request)) {
                if (!empty($request->id)) {
                    $id = $request->id;
                    $query = Exam::where(['id' => $id])->get();
                    if ($query->count() == 1) {
                        $query = Exam::where(['id' => $id])->delete();
                        ExamList::where(['exam_id' => $id])->delete();
                    if($query) {
                        return response()->json(["code" => 200, "message" => "Exam successfully deleted"]);
                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                    }

                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                    }
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            }
        }
    }



/*******************************************************************************************************/

private function updateName($id, $name, $exam, $status) {
    $query = Exam::where(['id' => $id])->update(['name' => $name, 'exam' => $exam, 'status' => $status]);
    ExamList::where(['exam_id' => $id])->update(['name' => $name, 'exam' => $exam, 'status' => $status]);
    if ($query) {
        return true;
    } else {
        return false;
    }
}


/*******************************************************************************************************/

    protected function update(Request $request) {
        if ($request->ajax()) {
            $validator = Validator::make($request->all(),[
                'id'=>'required',
                'exam'=>'required',
                'name'=>'required',
                'status'=>'required',
             ]);

              if ($validator->fails())  {
                    $error = $validator->errors()->first();
                    return response()->json(["code" => 500, "type" => "error", "message" => $error]);
              } else {
                  $app = new AppController();
                  $id = $app->sanitize($request->id);
                  $exam = strtoupper($app->sanitize($request->exam));
                  $name = $app->sanitize($request->name);
                  $status = $app->sanitize($request->status);
                  $query = Exam::where(["id" => $id]);
                  if ($query->count() == 1) {
                    $query = $query->first();
                    if ($name !== $query->name || $exam !== $query->exam || $status !== $query->status) {
                        if ($exam == $query->exam) {

                     if ($this->updateName($id, $name, $exam, $status)){
                        return response()->json(["code" => 200, "type" => "success", "message" => "Exam successfully updated"]);
                     } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong!!"]);
                     }

                    } else {
                        $query = Exam::where(['exam' => $exam])->get();
                        if ($query->count() == 0) {
                            if ($this->updateName($id, $name, $exam, $status)){
                                return response()->json(["code" => 200, "type" => "success", "message" => "Exam successfully updated"]);
                             } else {
                                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong!!"]);
                             }
                        } else {
                            return response()->json(["code" => 500, "type" => "error", "message" => "Exam already exist"]);
                        }

                    }


                        } else {
                            return response()->json(["code" => 500, "type" => "error", "message" => "No change was made"]);
                      }

                  } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong!!"]);
                  }

              }
        }
    }


}
