<?php

namespace App\Http\Controllers\Cable;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\Cable\Cable;
use App\Models\Cable\CablePlan;
use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\AppController;
use App\Models\Host\Host;
use App\Models\Cable\CableCode;


class CablePlanController extends Controller
{
    //

    protected function index(Request $request) {
        if ($request->ajax()) {
            $query =  CablePlan::orderBy('key', 'asc')->get();
        $table =  "<table id='table' class='table table-striped table-bordered' style='width:100%'>
        <thead>
            <tr>
            <th><div class='custom-control custom-switch'>
            <input class='form-check-input' id='allCheck' type='checkbox' value=''>
            </div></th>
                <th>S/N</th>
                <th>TV</th>
                <th>Plan</th>
                <th>Amount</th>
                <th>Status</th>
                <th style='padding-right: 50px;'>Action</th>
            </tr>
        </thead>
        <tbody>";
        $init = 1;
        foreach ($query as $plan)  {
        $serialNumber = $init++;
        if ($plan->status == "available") {
            $checked = "checked";
        } else {
            $checked = "";
        }
         $table .=  "<tr>
                 <td><div class='custom-control custom-switch'>
                <input class='form-check-input checkbox' type='checkbox' name='checkbox[]' data-id=". $plan->id ." value=''>
                </div>
                </td>
                <td>{$serialNumber}</td>
                <td>{$plan->cable}</td>
                <td>{$plan->plan}</td>
                <td>{$plan->amount}</td>
                <td>

                <div class='custom-control custom-switch'>
                <input type='checkbox' class='custom-control-input toggleSwitch' data-id=". $plan->id ." id='customSwitches$serialNumber' $checked>
                <label class='custom-control-label' for='customSwitches$serialNumber'></label>
              </div>

                </td>
                <td>
                <button class='btn btn-success btn-sm' data-toggle='tooltip'  id='edit' data-id=". $plan->id ." style='background-color: #2dbe60; padding: 8px; margin-right: 8px'> <i class='fas fa-edit action_icon' style='font-size: 10px;'></i> </button>
                <button class='btn btn-danger btn-sm' data-toggle='tooltip' id='delete' data-id=". $plan->id ." style='padding: 8px'> <i class='fas fa-trash action_icon' style='font-size: 10px;'></i> </button>
            </td>
            </tr>";
        }



        $table .= "</tbody>
    </table>";

        return $table;


        } else {
            return view('cable.plan', ["cable" => Cable::select('cable')->get()]);
        }
    }


/*******************************************************************************************************/

    private function cableCode($id, $key, $tv, $cable_id, $plan, $price, $status, $host) {
        $cable = new CableCode();
        $cable->key = $key;
        $cable->plan_id = $id;
        $cable->cable = $tv;
        $cable->cable_id = $cable_id;
        $cable->plan = $plan;
        $cable->code = "";
        $cable->provider = $host;
        $cable->status = $status;
        if ($cable->save()) {
            return true;
        }
    }

/*******************************************************************************************************/

    protected function create(Request $request) {
        if ($request->ajax()) {
            $validator = Validator::make($request->all(),[
                'tv'=>'required',
                'plan' => 'required',
                'price' => 'required',
                'status'=>'required',
             ]);

              if ($validator->fails())  {
                    $error = $validator->errors()->first();
                    return response()->json(["code" => 500, "type" => "error", "message" => $error]);
              } else {
                  $app = new AppController();
                  $tv = $app->sanitize($request->tv);
                  $plan = $app->sanitize($request->plan);
                  $price = $app->sanitize($request->price);
                  $status = $app->sanitize($request->status);
                  $query = CablePlan::where(["cable" => $tv, "plan" => $plan]);
                  $count = CablePlan::all()->count();
                  $cableQuery = Cable::where('cable', $tv)->get();
                  if ($query->count() == 0) {
                    $cable_id = $cableQuery[0]->id;
                    $key = $count + 1;
                      $cable = new CablePlan();
                      $cable->key = $key;
                      $cable->cable = $tv;
                      $cable->cable_id = $cable_id;
                      $cable->plan = $plan;
                      $cable->amount = $price;
                      $cable->status = $status;
                     if ($cable->save()){
                        $query = Host::all();
                        foreach ($query as $host) {
                            $this->cableCode($cable->id, $key, $tv, $cable_id, $plan, $price, $status, $host->name);
                        }
                        return response()->json(["code" => 200, "type" => "success", "message" => "Plan successfully saved"]);
                     } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "A critical error occured"]);
                     }


                  } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "plan already exist"]);
                  }



              }
        }
    }

/*******************************************************************************************************/

    protected function statusUpdate(Request $request) {
        if ($request->ajax()) {
            if (!empty($request)) {
                if (!empty($request->id) && !empty($request->status)) {
                    $app = new AppController();
                    $id = $app->sanitize($request->id);
                    $status = $app->sanitize($request->status);
                    $query = CablePlan::where(['id' => $id])->get();
                    if ($query->count() == 1) {
                        $query = CablePlan::where(['id' => $id])->update(['status' => $status]);
                        CableCode::where(['plan_id' => $id])->update(['status' => $status]);
                    if($query) {
                        return response()->json(["code" => 200, "status" => $status, "message" => "Status successfully set ".$status]);
                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                    }

                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                    }
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            }
        }
    }



/*******************************************************************************************************/

    protected function action(Request $request) {
        if ($request->ajax()) {
            if (!empty($request)) {
                if (!empty($request->arr) && !empty($request->action)) {
                    foreach ($request->arr as $arr) {
                        if ($request->action == "delete") {
                         $query = CablePlan::where(['id' => $arr])->delete();
                                  CableCode::where(['plan_id' => $arr])->delete();
                        } else  {
                         $query = CablePlan::where(['id' => $arr])->update(['status' => $request->action]);
                                  CableCode::where(['plan_id' => $arr])->update(['status' => $request->action]);
                        }
                    }
                    if($query) {
                        return response()->json(["code" => 200, "message" => "Action successfully processed"]);
                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                    }
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            }
        }
    }




/*******************************************************************************************************/

    protected function delete(Request $request) {
        if ($request->ajax()) {
            if (!empty($request)) {
                if (!empty($request->id)) {
                    $id = $request->id;
                    $query = CablePlan::where(['id' => $id])->get();
                    if ($query->count() == 1) {
                        $query = CablePlan::where(['id' => $id])->delete();
                        CableCode::where(['plan_id' => $id])->delete();
                    if($query) {
                        return response()->json(["code" => 200, "message" => "Plan successfully deleted"]);
                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                    }

                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                    }
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            }
        }
    }

/*******************************************************************************************************/

protected function edit(Request $request) {
    if ($request->ajax()) {
        if (!empty($request)) {
            if (!empty($request->id)) {
                $id = $request->id;
                $query = CablePlan::where(['id' => $id])->get();
                if ($query->count() == 1) {
                    $query = $query->first();
                    return response()->json(["code" => 200, "data" => [
                        'id' => $query->id,
                        'cable' => $query->cable,
                        'plan' => $query->plan,
                        'amount' => $query->amount,
                        'status' => $query->status,
                    ]]);
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
            }
        }
    }
}

/*******************************************************************************************************/

private function updateQuery($id, $tv, $cable_id, $plan, $amount, $status) {
    CablePlan::where(['id' => $id])->update(['cable' => $tv, 'cable_id' => $cable_id, 'plan' => $plan, 'amount' => $amount, 'status' => $status]);
    CableCode::where(['plan_id' => $id])->update(['cable' => $tv, 'cable_id' => $cable_id, 'plan' => $plan, 'status' => $status]);
    return true;
}


protected function update(Request $request) {
    if ($request->ajax()) {
        $validator = Validator::make($request->all(),[
            'id'=>'required',
            'tv'=>'required',
            'plan'=>'required',
            'price'=>'required',
            'status'=>'required',
         ]);

          if ($validator->fails())  {
                $error = $validator->errors()->first();
                return response()->json(["code" => 500, "type" => "error", "message" => $error]);
          } else {
              $app = new AppController();
              $id = $app->sanitize($request->id);
              $tv = $app->sanitize($request->tv);
              $plan = $app->sanitize($request->plan);
              $amount = $app->sanitize($request->price);
              $status = $app->sanitize($request->status);
              $cableQuery = Cable::where(["cable" => $tv])->get();
              $query = CablePlan::where(["id" => $id]);
              if ($query->count() == 1) {
                  if ($cableQuery->count() == 1) {
                $query = $query->first();
                if ($tv !== $query->cable || $plan !== $query->plan || $amount !== $query->amount ||  $status !== $query->status) {
                    if ($tv == $query->cable &&  $plan == $query->plan) {
                    $query = $this->updateQuery($id, $tv, $cableQuery[0]->id, $plan, $amount, $status);
                 if ($query){
                    return response()->json(["code" => 200, "type" => "success", "message" => "Plan successfully updated"]);
                 } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong!!"]);
                 }
                } else {
                    $query = CablePlan::where(['cable' => $tv, 'plan' => $plan])->get();
                    if ($query->count() == 0) {
                        $query = $this->updateQuery($id, $tv, $cableQuery[0]->id, $plan, $amount, $status);
                         if ($query){
                            return response()->json(["code" => 200, "type" => "success", "message" => "Plan successfully updated"]);
                         } else {
                            return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong!!"]);
                         }
                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Plan already exist"]);
                    }

                }
                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "No change was made"]);
                  }

                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Invalid Tv"]);
                  }

              } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong!!"]);
              }

          }
    }
}












}
