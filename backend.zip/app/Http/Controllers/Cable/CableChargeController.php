<?php

namespace App\Http\Controllers\Cable;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Http\Controllers\AppController;
use App\Models\Cable\CableList;
use App\Models\Category\Category;
use Illuminate\Support\Facades\Validator;

class CableChargeController extends Controller
{
    //



    public function index(Request $request) {
        $app = new AppController();
        $category = $app->sanitize($request->category);
        if ($request->ajax()) {
            if (!empty($category)) {
            $list = CableList::where(["category" => $category])->get();
                if ($list->count() !== 0) {
                $table =  "<table id='table' class='table table-striped table-bordered' style='width:100%'>
                <thead>
                    <tr>
                        <th>S/N</th>
                        <th>TV</th>
                        <th>Charge (% | &#8358;)</th>
                        <th  style='padding-right:130px'>Charge Type</th>
                    </tr>
                </thead>
                <tbody>";
                $init = 1;
                foreach ($list as $cable)  {
                $serialNumber = $init++;

                if ($cable->charge_type == "fee") {
                    $fee = "selected";
                    $discount = "";
                } else if ($cable->charge_type == "discount") {
                    $fee = "";
                    $discount = "selected";
                } else {
                    $fee = "";
                    $discount = "";
                }

                $table .=  "<tr>
                        <td>{$serialNumber}</td>
                        <td>{$cable->cable}</td>
                        <td><input type='number' data-id='$cable->id' name='charge[]' class='form-control form-white' value='$cable->charge' style='width: 120px'/></td>
                        <td>
                        <select name='charge_type[]' data-id='$cable->id' class='form-control form-white'>
                        <option value='fee' $fee>Convinient Fee (&#8358;) </option>
                        <option value='discount' $discount>Discount (%)</option>
                        </select>
                        </td>
                    </tr>";
                }

            $table .= "</tbody>
        </table>
        <br/>
        <button type='button' class='btn btn-block btn-secondary waves-effect waves-light' id='proceed' style='padding-top: 10px;'> <span id='btn-spinner'></span> <span id='btn-txt'> Save <i class='fas fa-save'></i></span></button>";

            return $table;

                } else {
                    echo "<script> alert('No result found for this category');</script>";
                }
            } else {
                echo "<script> alert('No result found for this category');</script>";
            }
        } else {
            return view("cable.charge", ['categories' => Category::all()]);
        }

}



protected function update(Request $request) {
    if (!empty($request)) {
        if (!empty($request->charge) && !empty($request->charge)) {
            foreach ($request->charge as $charge) {
                $id = $charge["id"];
                if ($charge["value"] == ""){
                    $charge = "";
                } else {
                    $charge = $charge["value"];
                }

                if (is_numeric($charge) || $charge == '') {
                    CableList::where(["id" => $id])->update(["charge" => $charge]);
                }

            }

            foreach ($request->charge_type as $charge_type) {
                $id = $charge_type["id"];
                if (empty($charge_type["value"])){
                    $charge_type = "";
                } else {
                    $charge_type = $charge_type["value"];
                }
                 CableList::where(["id" => $id])->update(["charge_type" => $charge_type]);
            }

                return response()->json(["code" => 200, "message" => "Charge successfully saved"]);

        }
    }
}







protected function merge(Request $request) {
    if ($request->ajax()) {
        $validator = Validator::make($request->all(),[
            'category_1'=>'required',
            'category_2' => 'required',
         ]);
          if ($validator->fails())  {
                $error = $validator->errors()->first();
                return response()->json(["code" => 500, "type" => "error", "message" => $error]);
          } else {
            $app = new AppController();
            $category_1 = $app->sanitize($request->category_1);
            $category_2 = $app->sanitize($request->category_2);
            if ($app->getCategory($category_1)->count() == 1 && $app->getCategory($category_1)->count() == 1) {
                $query = CableList::where('category', $category_1)->get();
                foreach ($query as $row) {
                    CableList::where(['cable_id' => $row->cable_id, 'category' => $category_2])->update([
                        'charge' => $row->charge,
                        'charge_type' => $row->charge_type,
                    ]);
                }
                return response()->json(["code" => 200, "type" => "success", "message" => "Merging successfully done"]);
            } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "An invalid host received"]);
            }
          }
    }
}








}
