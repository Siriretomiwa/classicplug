<?php

namespace App\Http\Controllers\Cable;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Cable\Cable;
use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\AppController;
use App\Models\Cable\CableList;
use App\Models\Category\Category;

class CableController extends Controller
{
    //


    protected function index(Request $request) {
        if ($request->ajax()) {
            $query =  Cable::all();
        $table =  "<table id='table' class='table table-striped table-bordered' style='width:100%'>
        <thead>
            <tr>
                <th><div class='custom-control custom-switch'>
                <input class='form-check-input' id='allCheck' type='checkbox' value=''>
                </div></th>
                <th>S/N</th>
                <th>Tv</th>
                <th>Status</th>
                <th style='padding-right: 50px;'>Action</th>
            </tr>
        </thead>
        <tbody>";
        $init = 1;
        foreach ($query as $cable)  {
        $serialNumber = $init++;
        if ($cable->status == "available") {
            $checked = "checked";
        } else {
            $checked = "";
        }
         $table .=  "<tr>
                <td><div class='custom-control custom-switch'>
                <input class='form-check-input checkbox' type='checkbox' name='checkbox[]' data-id=". $cable->id ." value=''>
                </div>
                </td>
                <td>{$serialNumber}</td>
                <td>{$cable->cable}</td>
                <td>

                <div class='custom-control custom-switch'>
                <input type='checkbox' class='custom-control-input toggleSwitch' data-id=". $cable->id ." id='customSwitches$serialNumber' $checked>
                <label class='custom-control-label' for='customSwitches$serialNumber'></label>
              </div>

                </td>
                <td>
                <button class='btn btn-success btn-sm' data-toggle='tooltip'  id='edit' data-id=". $cable->id ." style='background-color: #2dbe60; padding: 8px; margin-right: 8px'> <i class='fas fa-edit action_icon' style='font-size: 10px;'></i> </button>
                <button class='btn btn-danger btn-sm' data-toggle='tooltip' id='delete' data-id=". $cable->id ." style='padding: 8px'> <i class='fas fa-trash action_icon' style='font-size: 10px;'></i> </button>
            </td>
            </tr>";
        }

        $table .= "</tbody>
    </table>";

        return $table;


        } else {
            return view('cable.cable');
        }
    }





    private function cableList($cable_id, $key, $name, $status, $category) {
        $cable = new CableList();
        $cable->key = $key;
        $cable->cable_id = $cable_id;
        $cable->cable = $name;
        $cable->category = $category;
        $cable->charge = "";
        $cable->charge_type = "";
        $cable->status = $status;
        if ($cable->save()) {
            return true;
        }
    }





    protected function create(Request $request) {
        if ($request->ajax()) {
            $validator = Validator::make($request->all(),[
                'name'=>'required|regex:/^\S*$/u',
                'status'=>'required',
             ]);

              if ($validator->fails())  {
                    $error = $validator->errors()->first();
                    return response()->json(["code" => 500, "type" => "error", "message" => $error]);
              } else {
                  $app = new AppController();
                  $name = $app->sanitize($request->name);
                  $status = $app->sanitize($request->status);
                  $query = Cable::where(["cable" => $name]);
                  $count = Cable::all()->count();
                  if ($query->count() == 0) {
                        $key = $count + 1;
                      $cable = new Cable();
                      $cable->key = $key;
                      $cable->cable = strtoupper($name);
                      $cable->status = $status;
                     if ($cable->save()){
                        $query = Category::all();
                        foreach ($query as $category) {
                            $this->cableList($cable->id, $key, $name, $status, $category->name);
                        }
                        return response()->json(["code" => 200, "type" => "success", "message" => "$name successfully added"]);
                     } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "A critical error occured"]);
                     }


                  } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "$name already exist"]);
                  }



              }
        }
    }

/*******************************************************************************************************/

    protected function statusUpdate(Request $request) {
        if ($request->ajax()) {
            if (!empty($request)) {
                if (!empty($request->id) && !empty($request->status)) {
                    $app = new AppController();
                    $id = $app->sanitize($request->id);
                    $status = $app->sanitize($request->status);
                    $query = Cable::where(['id' => $id])->get();
                    if ($query->count() == 1) {
                        $query = Cable::where(['id' => $id])->update(['status' => $status]);
                        CableList::where(['cable_id' => $id])->update(['status' => $status]);
                    if($query) {
                        return response()->json(["code" => 200, "status" => $status, "message" => "Status successfully set ".$status]);
                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                    }

                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                    }
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            }
        }
    }

/*******************************************************************************************************/

    protected function action(Request $request) {
        if ($request->ajax()) {
            if (!empty($request)) {
                if (!empty($request->arr) && !empty($request->action)) {
                    foreach ($request->arr as $arr) {
                        if ($request->action == "delete") {
                         $query = Cable::where(['id' => $arr])->delete();
                                  CableList::where(['cable_id' => $arr])->delete();
                        } else  {
                         $query = Cable::where(['id' => $arr])->update(['status' => $request->action]);
                                  CableList::where(['cable_id' => $arr])->update(['status' => $request->action]);
                        }
                    }
                    if($query) {
                        return response()->json(["code" => 200, "message" => "Action successfully processed"]);
                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                    }
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            }
        }
    }

/*******************************************************************************************************/

    protected function delete(Request $request) {
        if ($request->ajax()) {
            if (!empty($request)) {
                if (!empty($request->id)) {
                    $id = $request->id;
                    $query = Cable::where(['id' => $id])->get();
                    if ($query->count() == 1) {
                        $query = Cable::where(['id' => $id])->delete();
                        CableList::where(['cable_id' => $id])->delete();
                    if($query) {
                        return response()->json(["code" => 200, "message" => "Tv successfully deleted"]);
                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                    }

                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                    }
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            }
        }
    }


/*******************************************************************************************************/

    protected function edit(Request $request) {
        if ($request->ajax()) {
            if (!empty($request)) {
                if (!empty($request->id)) {
                    $id = $request->id;
                    $query = Cable::where(['id' => $id])->get();
                    if ($query->count() == 1) {
                        $query = $query->first();
                        return response()->json(["code" => 200, "data" => [
                            'id' => $query->id,
                            'name' => $query->cable,
                            'status' => $query->status,
                        ]]);
                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                    }
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            }
        }
    }

/*******************************************************************************************************/

private function updateName($id, $name, $status) {
    $query = Cable::where(['id' => $id])->update(['cable' => $name, 'status' => $status]);
    CableList::where(['cable_id' => $id])->update(['cable' => $name, 'status' => $status]);
    if ($query) {
        return true;
    } else {
        return false;
    }
}


/*******************************************************************************************************/

    protected function update(Request $request) {
        if ($request->ajax()) {
            $validator = Validator::make($request->all(),[
                'id'=>'required',
                'name'=>'required',
                'status'=>'required',
             ]);

              if ($validator->fails())  {
                    $error = $validator->errors()->first();
                    return response()->json(["code" => 500, "type" => "error", "message" => $error]);
              } else {
                  $app = new AppController();
                  $id = $app->sanitize($request->id);
                  $name = strtoupper($app->sanitize($request->name));
                  $status = $app->sanitize($request->status);
                  $query = Cable::where(["id" => $id]);
                  if ($query->count() == 1) {
                    $query = $query->first();
                    if ($name !== $query->cable || $status !== $query->status) {
                        if ($name == $query->cable) {

                     if ($this->updateName($id, $name, $status)){
                        return response()->json(["code" => 200, "type" => "success", "message" => "Tv successfully updated"]);
                     } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong!!"]);
                     }

                    } else {
                        $query = Cable::where(['cable' => $name])->get();
                        if ($query->count() == 0) {
                            if ($this->updateName($id, $name, $status)){
                                return response()->json(["code" => 200, "type" => "success", "message" => "Tv successfully updated"]);
                             } else {
                                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong!!"]);
                             }
                        } else {
                            return response()->json(["code" => 500, "type" => "error", "message" => "Tv already exist"]);
                        }

                    }


                        } else {
                            return response()->json(["code" => 500, "type" => "error", "message" => "No change was made"]);
                      }

                  } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong!!"]);
                  }

              }
        }
    }








}
