<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class WhatsappController extends Controller
{
    //

    protected function index(Request $request) {
        if ($request->ajax()) {

            $validator = Validator::make($request->all(),[
                'number'=>'required|min:11|max:16',
                'link'=>'nullable|max:255',
             ]);

              if ($validator->fails())  {
                    $error = $validator->errors()->first();
                    return response()->json(["code" => 500, "type" => "error", "message" => $error]);
              } else {
                  $app = new AppController();
                  $number = $app->sanitize($request->number);
                  $link = $app->sanitize($request->link);
                  $query = DB::table('whatsapp')->get();
                  if ($query->count() == 0) {
                    $insert = DB::table('whatsapp')->insert([
                        'number' => $number,
                        'link' => $link,
                    ]);
                      if ($insert) {
                        return response()->json(["code" => 200, "type" => "success", "message" => "Whatsapp details successfully saved"]);
                      } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "A critical error ocurred"]);
                      }

                  } else {

                    DB::table('whatsapp')->update([
                        'number' => $number,
                        'link' => $link,
                    ]);
                        return response()->json(["code" => 200, "type" => "success", "message" => "Whatsapp details successfully updated"]);
                }
              }

        } else {
            $query = DB::table('whatsapp')->first();
            return view('whatsapp', ["whatsapp" => $query]);
        }
    }




}
