<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;

class AuthController extends Controller
{
    //

    protected  function register(Request $request) {
        if ($request->ajax()) {
        $validator = Validator::make($request->all(),[
            'username'=>'required|min:2|max:20|regex:/^\S*$/u',
            'email' => 'required|email|min:2|max:50',
            'password' => 'required|min:8|max:30',
         ]);

          if ($validator->fails())  {
                $error = $validator->errors()->first();
          } else {

            $app = new AppController();
            $username = $app->sanitize($request->username);
            $email = $app->sanitize($request->email);
            $password = $request->password;
              if ($username !== $password) {
            $admin =  DB::table('admin')->where(['username' => $username])->orWhere(['email' => $email])->get();
            if ($admin->count() == 0) {
              $milliseconds = round(microtime(true) * 1000);
              $token = Str::random(150).$milliseconds;
              $password = Hash::make($password);
              $query = DB::table('admin')->insert(
                [
                  'token' => $token,
                  'email' => $email,
                  'username' => $username,
                  'password' => $password,
                  'role' => 'super-admin',
                  'permission' => 'all',
                  'status' => 'active',
                  'created_at' => now(),
                ]
              );

              if ($query) {

                  session()->flash('message', 'Your account has been created successfully.');
                  return response()->json([
                    'code' => 200,
                    'message' => null,
                ]);
              }


              } else {
                $error = "Username or email already exist";
              }

              } else {
                $error = "Please choose a more secure password";
              }

          }

          // Display message
          if (!empty($error)) {
            return response()->json([
                'code' => 100,
                'message' => $error,
            ]);
            }
        }
      }







        protected  function login(Request $request) {
            if ($request->ajax()) {
            $validator = Validator::make($request->all(),[
                'username'=>'required|min:2|max:20',
                'password'=>'required|min:8|max:30'
             ]);

              if ($validator->fails())  {
                    $error = $validator->errors()->first();
              } else {
                $app = new AppController();
                $username = $app->sanitize($request->username);
                $password = $app->sanitize($request->password);
                $admin =  DB::table('admin')->select('token', 'password')->where(['username' => $username, 'status' => 'active'])->get();
                if ($admin->count() == 1) {
                  if (Hash::check($password,  $admin[0]->password)) {
                          session(['token' => $admin[0]->token]);
                          return response()->json([
                              'code' => 200,
                              'message' => null,
                          ]);
                    } else {
                      $error = "Incorrect username or password";
                    }
                } else {
                  $error = "Incorrect username or password";
                }


              }

              // Display message
              if (!empty($error)) {
                  return response()->json([
                      'code' => 100,
                      'message' => $error,
                  ]);
                  }
            }
          }





}
