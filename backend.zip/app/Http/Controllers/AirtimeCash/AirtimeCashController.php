<?php

namespace App\Http\Controllers\AirtimeCash;

use App\Http\Controllers\Controller;
use App\Models\AirtimeCash\AirtimeCash;
use Illuminate\Http\Request;

use App\Models\Network\Networks;
use App\Models\Category\Category;
use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\AppController;
use App\Models\AirtimeCash\AirtimeCashList;

class AirtimeCashController extends Controller
{
    //


    protected function index(Request $request) {
        if ($request->ajax()) {
        $query =  AirtimeCash::all();
        $table =  "<table id='table' class='table table-striped table-bordered' style='width:100%'>
        <thead>
            <tr>
            <th><div class='custom-control custom-switch'>
            <input class='form-check-input' id='allCheck' type='checkbox' value=''>
            </div></th>
                <th>S/N</th>
                <th>Network</th>
                <th>Phone Number(s)</th>
                <th>Status</th>
                <th style='padding-right: 50px;'>Action</th>
            </tr>
        </thead>
        <tbody>";
        $init = 1;
        foreach ($query as $airtimeCash)  {
        $serialNumber = $init++;
        if ($airtimeCash->status == "available") {
            $checked = "checked";
        } else {
            $checked = "";
        }
         $table .=  "<tr>
            <td><div class='custom-control custom-switch'>
            <input class='form-check-input checkbox' type='checkbox' name='checkbox[]' data-id=". $airtimeCash->id ." value=''>
            </div>
            </td>
                <td>{$serialNumber}</td>
                <td>{$airtimeCash->network}</td>
                <td>{$airtimeCash->phone_number}</td>
                <td>

                <div class='custom-control custom-switch'>
                <input type='checkbox' class='custom-control-input toggleSwitch' data-id=". $airtimeCash->id ." id='customSwitches$serialNumber' $checked>
                <label class='custom-control-label' for='customSwitches$serialNumber'></label>
              </div>

                </td>
                <td>
                <button class='btn btn-success btn-sm' data-toggle='tooltip'  id='edit' data-id=". $airtimeCash->id ." style='background-color: #2dbe60; padding: 8px; margin-right: 8px'> <i class='fas fa-edit action_icon' style='font-size: 10px;'></i> </button>
                <button class='btn btn-danger btn-sm' data-toggle='tooltip' id='delete' data-id=". $airtimeCash->id ." style='padding: 8px'> <i class='fas fa-trash action_icon' style='font-size: 10px;'></i> </button>
            </td>
            </tr>";
        }

        $table .= "</tbody>
    </table>";

        return $table;


        } else {
            return view('airtime-cash.airtime-cash', ["networks" => Networks::select('name')->get()]);
        }
    }

/*******************************************************************************************************/

    private function airtimeCashList($id, $key, $network, $network_id, $phoneNumber, $status, $category) {
        $airtimeCash = new AirtimeCashList();
        $airtimeCash->key = $key;
        $airtimeCash->airtime_cash_id = $id;
        $airtimeCash->network = $network;
        $airtimeCash->network_id = $network_id;
        $airtimeCash->phone_number = $phoneNumber;
        $airtimeCash->category = $category;
        $airtimeCash->rate = "";
        $airtimeCash->status = $status;
        if ($airtimeCash->save()) {
            return true;
        }
    }





    protected function statusUpdate(Request $request) {
        if ($request->ajax()) {
            if (!empty($request)) {
                if (!empty($request->id) && !empty($request->status)) {
                    $app = new AppController();
                    $id = $app->sanitize($request->id);
                    $status = $app->sanitize($request->status);
                    $query = AirtimeCash::where(['id' => $id])->get();
                    if ($query->count() == 1) {
                        $query = AirtimeCash::where(['id' => $id])->update(['status' => $status]);
                                AirtimeCashList::where(['airtime_cash_id' => $id])->update(['status' => $status]);
                    if($query) {
                        return response()->json(["code" => 200, "status" => $status, "message" => "Status successfully set ".$status]);
                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                    }

                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                    }
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            }
        }
    }

/*******************************************************************************************************/

    protected function create(Request $request) {
        if ($request->ajax()) {
            $validator = Validator::make($request->all(),[
                'network'=>'required',
                'phoneNumber' => 'required',
                'status'=>'required',
             ]);

              if ($validator->fails())  {
                    $error = $validator->errors()->first();
                    return response()->json(["code" => 500, "type" => "error", "message" => $error]);
              } else {
                  $app = new AppController();
                  $network = $app->sanitize($request->network);
                  $phoneNumber = $app->sanitize($request->phoneNumber);
                  $status = $app->sanitize($request->status);
                  $query = AirtimeCash::where(["network" => $network]);
                  $count = AirtimeCash::all()->count();
                  $networkQuery = Networks::where('name', $network)->get();
                  if ($query->count() == 0) {
                    $network_id = $networkQuery[0]->id;
                    $key = $count + 1;
                      $airtimeCash = new AirtimeCash();
                      $airtimeCash->key = $key;
                      $airtimeCash->network = $network;
                      $airtimeCash->network_id = $network_id;
                      $airtimeCash->phone_number = $phoneNumber;
                      $airtimeCash->status = $status;
                     if ($airtimeCash->save()){
                        $query = Category::all();
                        foreach ($query as $category) {
                            $this->airtimeCashList($airtimeCash->id, $key, $network, $network_id, $phoneNumber, $status, $category->name);
                        }
                        return response()->json(["code" => 200, "type" => "success", "message" => "$network Airtime Cash successfully saved"]);
                     } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "A critical error occured"]);
                     }


                  } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "$network Airtime To Cash already exist"]);
                  }



              }
        }
    }

/*******************************************************************************************************/

    protected function delete(Request $request) {
        if ($request->ajax()) {
            if (!empty($request)) {
                if (!empty($request->id)) {
                    $id = $request->id;
                    $query = AirtimeCash::where(['id' => $id])->get();
                    if ($query->count() == 1) {
                        $query = AirtimeCash::where(['id' => $id])->delete();
                        AirtimeCashList::where(['airtime_cash_id' => $id])->delete();
                    if($query) {
                        return response()->json(["code" => 200, "message" => "Airtime to cash successfully deleted"]);
                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                    }

                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                    }
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            }
        }
    }

/*******************************************************************************************************/

protected function action(Request $request) {
    if ($request->ajax()) {
        if (!empty($request)) {
            if (!empty($request->arr) && !empty($request->action)) {
                foreach ($request->arr as $arr) {
                    if ($request->action == "delete") {
                     $query = AirtimeCash::where(['id' => $arr])->delete();
                              AirtimeCashList::where(['airtime_cash_id' => $arr])->delete();
                    } else  {
                     $query = AirtimeCash::where(['id' => $arr])->update(['status' => $request->action]);
                              AirtimeCashList::where(['airtime_cash_id' => $arr])->update(['status' => $request->action]);
                    }
                }
                if($query) {
                    return response()->json(["code" => 200, "message" => "Action successfully processed"]);
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
            }
        }
    }
}



protected function edit(Request $request) {
    if ($request->ajax()) {
        if (!empty($request)) {
            if (!empty($request->id)) {
                $id = $request->id;
                $query = AirtimeCash::where(['id' => $id])->get();
                if ($query->count() == 1) {
                    $query = $query->first();
                    return response()->json(["code" => 200, "data" => [
                        'id' => $query->id,
                        'network' => $query->network,
                        'phone_number' => $query->phone_number,
                        'status' => $query->status,
                    ]]);
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
            }
        }
    }
}






private function updateAirtimeCash($id, $network, $phoneNumber, $status) {
    $query = AirtimeCash::where(['id' => $id])->update(['network' => $network, 'phone_number' => $phoneNumber, 'status' => $status]);
    AirtimeCashList::where(['airtime_cash_id' => $id])->update(['network' => $network, 'phone_number' => $phoneNumber, 'status' => $status]);
    if ($query) {
        return true;
    } else {
        return false;
    }
}


/*******************************************************************************************************/

    protected function update(Request $request) {
        if ($request->ajax()) {
            $validator = Validator::make($request->all(),[
                'id'=>'required',
                'number'=>'required',
                'network'=>'required',
                'status'=>'required',
             ]);

              if ($validator->fails())  {
                    $error = $validator->errors()->first();
                    return response()->json(["code" => 500, "type" => "error", "message" => $error]);
              } else {
                  $app = new AppController();
                  $id = $app->sanitize($request->id);
                  $phoneNumber = strtoupper($app->sanitize($request->number));
                  $network = strtoupper($app->sanitize($request->network));
                  $status = $app->sanitize($request->status);
                  $query = AirtimeCash::where(["id" => $id]);
                  $row = Networks::where('name', $network)->get();
                  if ($query->count() == 1) {
                        if ($row->count() == 1) {
                    $query = $query->first();
                    if ($phoneNumber !== $query->name || $network !== $query->network || $status !== $query->status) {
                        if ($network == $query->network) {
                     if ($this->updateAirtimeCash($id, $network, $phoneNumber, $status)){
                        return response()->json(["code" => 200, "type" => "success", "message" => "Airtime to cash successfully updated"]);
                     } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong!!"]);
                     }

                    } else {
                        $query = AirtimeCash::where(['network' => $network])->get();
                        if ($query->count() == 0) {
                            if ($this->updateAirtimeCash($id, $network, $phoneNumber, $status)){
                                return response()->json(["code" => 200, "type" => "success", "message" => "Airtime to cash successfully updated"]);
                             } else {
                                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong!!"]);
                             }
                        } else {
                            return response()->json(["code" => 500, "type" => "error", "message" => "Network already exist"]);
                        }

                    }


                        } else {
                            return response()->json(["code" => 500, "type" => "error", "message" => "No change was made"]);
                      }

                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Invalid Network"]);
                      }

                  } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong!!"]);
                  }

              }
        }
    }
















}
