<?php

namespace App\Http\Controllers\Spectranet;

use App\Http\Controllers\AppController;
use App\Http\Controllers\Controller;
use App\Models\Spectranet\Spectranet;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class SpectranetController extends Controller
{

    //

    protected function index(Request $request) {
        if ($request->ajax()) {
            $query =  Spectranet::all();
        $table =  "<table id='table' class='table table-striped table-bordered' style='width:100%'>
        <thead>
            <tr>
            <th><div class='custom-control custom-switch'>
            <input class='form-check-input' id='allCheck' type='checkbox' value=''>
            </div></th>
                <th>S/N</th>
                <th>Plan</th>
                <th>Plan Code</th>
                <th>Amount(&#8358;)</th>
                <th>Status</th>
                <th style='padding-right: 50px;'>Action</th>
            </tr>
        </thead>
        <tbody>";
        $init = 1;
        foreach ($query as $plan)  {
        $serialNumber = $init++;
        if ($plan->status == "available") {
            $checked = "checked";
        } else {
            $checked = "";
        }
         $table .=  "<tr>
                <td><div class='custom-control custom-switch'>
                <input class='form-check-input checkbox' type='checkbox' name='checkbox[]' data-id=". $plan->id ." value=''>
                </div>
                </td>
                <td>{$serialNumber}</td>
                <td>{$plan->plan}</td>
                <td>{$plan->plan_code}</td>
                <td>{$plan->amount}</td>
                <td>
                <div class='custom-control custom-switch'>
                <input type='checkbox' class='custom-control-input toggleSwitch' data-id=". $plan->id ." id='customSwitches$serialNumber' $checked>
                <label class='custom-control-label' for='customSwitches$serialNumber'></label>
              </div>
                </td>
                <td>
                <button class='btn btn-success btn-sm' data-toggle='tooltip'  id='edit' data-id=". $plan->id ." style='background-color: #2dbe60; padding: 8px; margin-right: 8px'> <i class='fas fa-edit action_icon' style='font-size: 10px;'></i> </button>
                <button class='btn btn-danger btn-sm' data-toggle='tooltip' id='delete' data-id=". $plan->id ." style='padding: 8px'> <i class='fas fa-trash action_icon' style='font-size: 10px;'></i> </button>
            </td>
            </tr>";
        }

        $table .= "</tbody>
    </table>";

        return $table;

        } else {
            return view('spectranet.spectranet');
        }
    }



/*******************************************************************************************************/


    protected function create(Request $request) {
        if ($request->ajax()) {
            $validator = Validator::make($request->all(),[
                'plan' => 'required',
                'plan_code' => 'required',
                'amount' => 'required',
                'status'=>'required',
             ]);

              if ($validator->fails())  {
                    $error = $validator->errors()->first();
                    return response()->json(["code" => 500, "type" => "error", "message" => $error]);
              } else {
                  $app = new AppController();
                  $plan = $app->sanitize($request->plan);
                  $plan_code = $app->sanitize($request->plan_code);
                  $amount = $app->sanitize($request->amount);
                  $status = $app->sanitize($request->status);
                  $query = Spectranet::where(["plan" => $plan]);
                  if ($query->count() == 0) {
                      $spectranet = new Spectranet();
                      $spectranet->plan = $plan;
                      $spectranet->plan_code = $plan_code;
                      $spectranet->amount = $amount;
                      $spectranet->status = $status;
                     if ($spectranet->save()) {
                        return response()->json(["code" => 200, "type" => "success", "message" => "Plan successfully saved"]);
                     } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                     }

                  } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "plan already exist"]);
                  }


              }
        }
    }


/*******************************************************************************************************/


protected function action(Request $request) {
    if ($request->ajax()) {
        if (!empty($request)) {
            if (!empty($request->arr) && !empty($request->action)) {
                foreach ($request->arr as $arr) {
                    if ($request->action == "delete") {
                     $query = Spectranet::where(['id' => $arr])->delete();
                    } else  {
                     $query = Spectranet::where(['id' => $arr])->update(['status' => $request->action]);
                    }
                }
                if($query) {
                    return response()->json(["code" => 200, "message" => "Action successfully processed"]);
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
            }
        }
    }
}


/*******************************************************************************************************/


protected function statusUpdate(Request $request) {
    if ($request->ajax()) {
        if (!empty($request)) {
            if (!empty($request->id) && !empty($request->status)) {
                $app = new AppController();
                $id = $app->sanitize($request->id);
                $status = $app->sanitize($request->status);
                $query = Spectranet::where(['id' => $id])->get();
                if ($query->count() == 1) {
                    $query = Spectranet::where(['id' => $id])->update(['status' => $status]);
                if($query) {
                    return response()->json(["code" => 200, "status" => $status, "message" => "Status successfully set ".$status]);
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }

                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
            }
        }
    }
}



/*******************************************************************************************************/


protected function delete(Request $request) {
    if ($request->ajax()) {
        if (!empty($request)) {
            if (!empty($request->id)) {
                $id = $request->id;
                $query = Spectranet::where(['id' => $id])->get();
                if ($query->count() == 1) {
                    $query =  Spectranet::where(['id' => $id])->delete();
                if($query) {
                    return response()->json(["code" => 200, "message" => "Plan successfully deleted"]);
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }

                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
            }
        }
    }
}


/*******************************************************************************************************/

protected function edit(Request $request) {
    if ($request->ajax()) {
        if (!empty($request)) {
            if (!empty($request->id)) {
                $id = $request->id;
                $query = Spectranet::where(['id' => $id])->get();
                if ($query->count() == 1) {
                    $query = $query->first();
                    return response()->json(["code" => 200, "data" => [
                        'id' => $query->id,
                        'plan' => $query->plan,
                        'plan_code' => $query->plan_code,
                        'amount' => $query->amount,
                        'status' => $query->status,
                    ]]);

                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
            }
        }
    }
}





/*******************************************************************************************************/

protected function update(Request $request) {
    if ($request->ajax()) {
        $validator = Validator::make($request->all(),[
            'id'=>'required',
            'plan' => 'required',
            'plan_code' => 'required',
            'amount' => 'required',
            'status'=>'required',
         ]);

          if ($validator->fails())  {
                $error = $validator->errors()->first();
                return response()->json(["code" => 500, "type" => "error", "message" => $error]);
          } else {
              $app = new AppController();
              $id = $app->sanitize($request->id);
              $plan = $app->sanitize($request->plan);
              $plan_code = $app->sanitize($request->plan_code);
              $amount = $app->sanitize($request->amount);
              $status = $app->sanitize($request->status);
              $query = Spectranet::where(["id" => $id]);
              if ($query->count() == 1) {
                $query = $query->first();
                if ($plan !== $query->plan || $plan_code !== $query->plan_code || $amount !== $query->amount || $status !== $query->status) {
                    $query =  Spectranet::where(['id' => $id])->update(['plan' => $plan, 'plan_code' => $plan_code, 'amount' => $amount, 'status' => $status]);
                    if ($query){
                    return response()->json(["code" => 200, "type" => "success", "message" => "Plan successfully updated"]);
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong!!"]);
                }

                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "No change was made"]);
                  }

              } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong!!"]);
              }

          }
    }
}







}
