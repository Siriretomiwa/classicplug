<?php

namespace App\Http\Controllers;

use App\Models\Transaction\Transaction;
use App\Models\User\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    //

    private function tranxStatusCount($status) {
        $query = Transaction::where('status', $status)->get();
        return $query->count();
    }

    public function index() {
        // $transaction = Transaction::all();
        $user = User::all();
        return view('home', [
            'transactions' => [
                "data" => DB::table('transactions')->limit(3)->orderBy('id', 'desc')->get(),
                "all" => DB::table('transactions')->count(),
                "success" => Transaction::where('status', 'success')->count(),
                "pending" => $this->tranxStatusCount("pending"),
                "reversed" => $this->tranxStatusCount("reversed"),
                "cancelled" => $this->tranxStatusCount("cancel"),
            ],
            'user' => $user->count(),
            'wallet' => $user->sum('wallet'),
            'commission' => $user->sum('commission'),
        ]);
    }



}
