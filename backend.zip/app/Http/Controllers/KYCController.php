<?php

namespace App\Http\Controllers;

use App\Models\User\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class KYCController extends Controller
{
    //


    protected function index(Request $request) {
        if ($request->ajax()) {
        $entries = $request->entries;
        $search = $request->search;
        $query =  DB::table('kyc')->orderBy('id', 'desc')->where('username', 'like', '%'.$search.'%')->paginate($entries);
        if ($query->count() > 0) {
        $table =  "<div class='row'>";
        $i = ($query->perPage() * ($query->currentPage() - 1)) + 1;
        foreach ($query as $kyc)  {
        $serialNumber = $i++;
            $user = User::select('verification')->where('username', $query[0]->username)->get();
            $status = null;
        switch($user[0]->verification) {
            case 'true': $status = "<span class='badge badge-success'> Verified </spa>";
                break;
            case '': $status = "<span class='badge badge-warning'> Not verified </spa>";
                break;
            default: $status = "<span class='badge badge-warning'> Not verified </spa>";;
        }

        $nin_status = $kyc->nin_slip !== '' ? 'Uploaded' : 'Not uploaded';
        $nin_view_btn = $kyc->nin_slip !== '' ?
                        "<a href=". $kyc->nin_slip ." target='blank'><button class='btn btn-sm text-white' style='background-color: blue; padding: 5px 7px; margin-right: 5px; font-size: 10px; font-weight: 700'>
                            <i class='fas fa-eye'></i> View
                        </button></a>" : '';


         $table .=  "<div class='col-md-6 col-xl-4'>
         <div class='card-box tilebox-one' style='line-height: 25px;'>

         <div>

            <div class='border-top list_padding' style='justify-content: space-between; display: flex;
            border-top: 1px solid white !important; padding-top: 2px;'>
            <span style='font-family: Ibarra Real Nova, serif !important; font-size: 17px;'> ". $serialNumber ." </span>
             <h6 class='mt-0 mb-0' style='font-family: Ibarra Real Nova, serif !important; font-size: 17px;'>". $kyc->username ."</h6>
             <h6 class='mt-0 mb-0' style='font-family: Ibarra Real Nova, serif !important; font-size: 17px;'>
                ". $status ."
             </h6>

             </div>


             <p class='mt-0 mb-0 border-top list_padding' style='background: #0000000d; box-shadow: rgb(149 157 165 / 7%) 0px 8px 24px;'>
                Account Number:<b> ". $kyc->account_number ."</b></p>

             <div class='border-top list_padding'>
                Account Name: <span style='word-break: break-all;'><b>". $kyc->account_name ."</b></span></div>

            <!-- Card hidden item list -->
             <div>
             <p style='background: #0000000d; box-shadow: rgb(149 157 165 / 7%) 0px 8px 24px;' class='mt-0 mb-0 border-top list_padding'>Bank Name: <b>". $kyc->bank_name ."</b></p>

             <div class='list_padding border-top'>
                Address: <b>". $kyc->address ."</b></div>

            <div class='list_padding border-top' style='background: #0000000d; box-shadow: rgb(149 157 165 / 7%) 0px 8px 24px; word-break: break-all;'>
            NIN: <b>". $kyc->nin ."</b></div>


            <div class='list_padding border-top'>
            NIN SLIP: <b>". $nin_status .' '. $nin_view_btn ."</b>

            </div>

             <div class='list_padding border-top' style='background: #0000000d; box-shadow: rgb(149 157 165 / 7%) 0px 8px 24px; word-break: break-all;'>BVN: <b>".
                $kyc->bvn  ."</b></div>
             </div>


             <div class='list_padding border-top' style='background: #0000000d; box-shadow: rgb(149 157 165 / 7%) 0px 8px 24px; word-break: break-all;'>
             BVN Remark: <b>". $kyc->remark ."</b></div>


             <!-- Card action list -->
             <div class='mt-3'>
                <button class='btn btn-sm text-white' id='action-status' data-status='approve' data-id=". $kyc->id ." style='background-color: green; padding: 5px 7px; margin-right: 5px; font-size: 10px; font-weight: 700'>
                    <i class='fas fa-check-circle action_icon'></i> Approve
                </button>
                <button class='btn btn-sm text-white' id='action-status' data-status='bvn' data-id=". $kyc->id ." style='background-color: red; padding: 5px 7px; margin-right: 5px; font-size: 10px; font-weight: 700'>
                <i class='fas fa-times-circle action_icon'></i> BVN
                </button>
                <button class='btn btn-sm text-white' id='action-status' data-status='nin' data-id=". $kyc->id ." style='background-color: red; padding: 5px 7px; margin-right: 5px; font-size: 10px; font-weight: 700'>
                    <i class='fas fa-times-circle action_icon'></i> NIN
                </button>

                <button class='btn btn-sm text-white' id='action-status' data-status='bank' data-id=". $kyc->id ." style='background-color: red; padding: 5px 7px; margin-right: 0px; font-size: 10px; font-weight: 700'>
                    <i class='fas fa-times-circle action_icon'></i> BANK
                </button>
            </div>
            <!-- Card action list end-->


            </div>
         </div>
     </div>";
        }

        $table .= "</div>
      <div class='card-box'>
    <div class='float-start'> Showing ". $query->firstItem() ." to ". $query->lastItem() ." of ". $query->total() ." entries</div>
    <div class='float-end mt-4 mb-2'>". $query->links('pagination::simple-tailwind') ."</div></div>";
        return $table;

    } else {
        $notFound = "<div class='card-box text-center'>
             <img src='/images/no-result-found.png' width='200px' />
        </div>";
        return $notFound;
     }

        } else {
             return view('kyc.verification');
        }
    }


        //  KYC action
        protected function action(Request $request) {
            if ($request->ajax()) {
                $validator = Validator::make($request->all(),[
                    'id'=>'required|int',
                    'status'=>'nullable',
                 ]);

                  if ($validator->fails())  {
                        $error = $validator->errors()->first();
                        return response()->json(["code" => 500, "type" => "error", "message" => $error]);
                  } else {
                      $app = new AppController();
                      $id = $app->sanitize($request->id);
                      $status = $app->sanitize($request->status);
                      $query = DB::table('kyc')->where('id', $id)->get();
                      if ($query->count() == 1) {
                        if ($status == "approve") {
                            $user_verification = ['verification' => 'true'];
                            $update_arr = [];
                        } else if ($status == "nin") {
                            $user_verification = ['verification' => 'false'];
                            $update_arr = [
                                'address' => '',
                                'nin' => '',
                                'nin_slip' => '',
                            ];
                        } else if ($status == "bank") {
                            $user_verification = ['verification' => 'false'];
                            $update_arr = [
                                'account_number' => '',
                                'account_name' => '',
                                'bank_name' => '',
                            ];
                        } else if ($status == "bvn") {
                            $user_verification = ['verification' => 'false'];
                            $update_arr = [
                                'bvn' => '',
                                'remark' => '',
                            ];
                        }

                        if (count($update_arr) !== 0) {
                            DB::table('kyc')->where('id', $id)->update($update_arr);
                        }

                        User::where('username', $query[0]->username)->update($user_verification);

                        $message = "";
                        switch($status) {
                            case "nin" : $message = "Your NIN upload was rejected, please re-upload";
                            break;
                            case "bvn": $message = "Your Bank veriification number (BVN) was rejected, please re-upload";
                            break;
                            case "bank" : $message = "Your bank account details was rejected, please re-upload";
                            break;
                            case "approve" : $message = "Your KYC veriification is successful, you now have access to all features on our platform.";
                            break;
                            default: $message = "KYC verification is currently in progress";
                        }

                        DB::table('messages')->insert([
                            'username' => $query[0]->username,
                            'topic' => 'KYC Verification',
                            'message' => $message,
                            'date_time' => now(),
                            'status' => 'unread'
                        ]);

                        return response()->json([
                            "code" => 200,
                            "type" => "success",
                            "status" => $status,
                            "message" => "KYC action successfully processed"]);

                      } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "KYC ID not found"]);
                    }
                  }

            }
        }








    // BVN Charge

    protected function BVNCharge(Request $request) {
        if ($request->ajax()) {
            $validator = Validator::make($request->all(),[
                'charge'=>'required|int',
             ]);

              if ($validator->fails())  {
                    $error = $validator->errors()->first();
                    return response()->json(["code" => 500, "type" => "error", "message" => $error]);
              } else {
                  $app = new AppController();
                  $charge = $app->sanitize($request->charge);
                  $query = DB::table('kyc_charge')->get();
                  if ($query->count() == 0) {
                    $insert = DB::table('kyc_charge')->insert([
                        'charge' => $charge,
                    ]);
                      if ($insert) {
                        return response()->json(["code" => 200, "type" => "success", "message" => "BVN Charge successfully saved"]);
                      } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "A critical error ocurred"]);
                      }

                  } else {

                    DB::table('kyc_charge')->update([
                        'charge' => $charge,
                    ]);
                        return response()->json(["code" => 200, "type" => "success", "message" => "Settings successfully saved"]);
                }
              }

        } else {
            $query = DB::table('kyc_charge')->first();
            return view("kyc.bvn-charge", ["charge" => $query]);
        }
    }




    // BVN Charge

    protected function bypass(Request $request) {
        if ($request->ajax()) {
            $validator = Validator::make($request->all(),[
                'usernameEmail'=>'required|string|max:250',
             ]);

              if ($validator->fails())  {
                    $error = $validator->errors()->first();
                    return response()->json(["code" => 500, "type" => "error", "message" => $error]);
              } else {
                  $app = new AppController();
                  $usernameEmail = $app->sanitize($request->usernameEmail);
                  $query = User::where("username", $usernameEmail)->orWhere("email", $usernameEmail)->get();
                  if ($query->count() == 1) {
                        User::where("username", $query[0]->username)->update([
                            "verification" => "true"
                        ]);
                        return response()->json(["code" => 200, "type" => "success", "message" => "Verification Successfully Bypassed"]);

                  } else {

                    return response()->json(["code" => 500, "type" => "error", "message" => "User not found"]);
                }
              }

        } else {
            $query = DB::table('kyc_charge')->first();
            return view("kyc.bypass", ["charge" => $query]);
        }
    }





}
