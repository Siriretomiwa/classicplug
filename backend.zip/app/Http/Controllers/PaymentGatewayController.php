<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Http;


class PaymentGatewayController extends Controller
{
    protected $username = "YOUR_USERNAME";
    protected $password = "YOUR_PASSWORD";


    protected function paystack(Request $request) {
        if ($request->ajax()) {

            $validator = Validator::make($request->all(),[
                'secret_key'=>'required',
                'charge'=>'required|numeric',
                'status'=>'required',
             ]);

              if ($validator->fails())  {
                    $error = $validator->errors()->first();
                    return response()->json(["code" => 500, "type" => "error", "message" => $error]);
              } else {
                  $app = new AppController();
                  $secret_key = $app->sanitize($request->secret_key);
                  $public_key = $app->sanitize($request->public_key);
                  $charge = $app->sanitize($request->charge);
                  $status = $app->sanitize($request->status);
                  $query = DB::table('paystack')->get();
                  if ($query->count() == 0) {
                    $insert = DB::table('paystack')->insert([
                        'secret_key' => $secret_key,
                        'public_key' => $public_key,
                        'charge' => $charge,
                        'status' => $status,
                    ]);
                      if ($insert) {
                        return response()->json(["code" => 200, "type" => "success", "message" => "Settings successfully added"]);
                      } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "A critical error ocurred"]);
                      }

                  } else {

                    DB::table('paystack')->update([
                        'secret_key' => $secret_key,
                        'public_key' => $public_key,
                        'charge' => $charge,
                        'status' => $status,
                    ]);
                        return response()->json(["code" => 200, "type" => "success", "message" => "Settings successfully updated"]);
                }
              }

        } else {
            $query = DB::table('paystack')->first();
            return view('gateway.paystack', ["paystack" => $query]);
        }
    }


public function vpay(Request $request)
{

// Login endpoint
$response = Http::withHeaders([
    'Content-Type' => 'application/json',
    'publicKey' => env('PUBLIC_KEY')
])->post(env('BASE_URL') . '/api/service/v1/query/merchant/login', [
    'username' => 'merchant@example.com',
    'password' => 'password123'
]);

// Get access token from response
$accessToken = $response->json()['access_token'] ?? '';


// Bank list endpoint
$response = Http::withHeaders([
    'Content-Type' => 'application/json',
    'publicKey' => env('PUBLIC_KEY'),
    'b-access-token' => $accessToken
])->get(env('BASE_URL') . '/api/service/v1/query/bank/list/show');

// Nuban lookup endpoint
$response = Http::withHeaders([
    'Content-Type' => 'application/json',
    'publicKey' => env('PUBLIC_KEY'),
    'b-access-token' => $accessToken
])->post(env('BASE_URL') . '/api/service/v1/query/lookup/nuban?virtualaccount=0123456789', [
    'bank_code' => '044'
]);


// Outbound transfer endpoint
$response = Http::withHeaders([
    'Content-Type' => 'application/json',
    'publicKey' => env('PUBLIC_KEY'),
    'accessToken' => $accessToken
])->post(env('BASE_URL') . '/api/service/v1/query/transfer/outbound', [
    'nuban' => '0123456789',
    'bank_code' => '044',
    'amount' => 1000,
    'remark' => 'Transfer from merchant',
    'transaction_ref' => 'MERCHANT1234-ABCD'
]);
// get wallet balance
$response = Http::withHeaders([
    'Content-Type' => 'application/json',
    'publicKey' => env('PUBLIC_KEY'),
    'b-access-token' => env('ACCESS_TOKEN'),
])->get(env('BASE_URL') . '/api/service/v1/query/merchant/wallet/balance');

if ($response->successful()) {
    $responseData = $response->json();
$balance = isset($responseData['balance']) ? $responseData['balance'] : null;
}

// get wallet statement
$response = Http::withHeaders([
    'Content-Type' => 'application/json',
    'publicKey' => env('PUBLIC_KEY'),
    'b-access-token' => env('ACCESS_TOKEN'),
])->post(env('BASE_URL') . '/api/service/v1/query/merchant/wallet/statement', [
    'startdate' => '2022-01-01',
    'enddate' => '2022-12-31',
]);

if ($response->successful()) {
    $statement = $response->json()['statement'];
}

$customerId = null;
// create virtual account/customer
$response = Http::withHeaders([
    'Content-Type' => 'application/json',
    'publicKey' => env('PUBLIC_KEY'),
    'b-access-token' => env('ACCESS_TOKEN'),
])->post(env('BASE_URL') . '/api/service/v1/query/customer/add', [
    'email' => 'customer@example.com',
    'phone' => '+1234567890',
    'contactfirstname' => 'John',
    'contactlastname' => 'Doe',
]);

if ($response->successful()) {
    $jsonResponse = $response->json();
    if(isset($jsonResponse['customerid'])){
        $customerId = $jsonResponse['customerid'];
    } else {
        //handle error when 'customerid' key not found
        $customerId = null;
    }
}

// check if customerId is null before making the next request
if ($customerId !== null) {
    $response = Http::withHeaders([
        'Content-Type' => 'application/json',
        'publicKey' => env('PUBLIC_KEY'),
        'b-access-token' => env('ACCESS_TOKEN'),
    ])->get(env('BASE_URL') . '/api/service/v1/query/customer/' . $customerId . '/show');
    
    if ($response->successful()) {
        $customer = $response->json()['customer'];
    }
}
// get customer
$response = Http::withHeaders([
    'Content-Type' => 'application/json',
    'publicKey' => env('PUBLIC_KEY'),
    'b-access-token' => env('ACCESS_TOKEN'),
])->get(env('BASE_URL') . '/api/service/v1/query/customer/' . $customerId . '/show');

if ($response->successful()) {
    $responseData = $response->json();
    if (isset($responseData['customer'])) {
        $customer = $responseData['customer'];
    } else {
        // handle the error here, e.g. log it or return an error response
    }
} else {
    // handle the error here, e.g. log it or return an error response
}

// get all customers
$response = Http::withHeaders([
    'Content-Type' => 'application/json',
    'publicKey' => env('PUBLIC_KEY'),
    'b-access-token' => env('ACCESS_TOKEN'),
])->get(env('BASE_URL') . '/api/service/v1/query/customer/all');

if ($response->successful()) {
    $responseData = $response->json();
    if (isset($responseData['customers'])) {
        $customers = $responseData['customers'];
    } else {
        // handle the error here, e.g. log it or return an error response
    }
} else {
    // handle the error here, e.g. log it or return an error response
}

// get customer by email
$response = Http::withHeaders([
    'Content-Type' => 'application/json',
    'publicKey' => env('PUBLIC_KEY'),
    'b-access-token' => env('ACCESS_TOKEN'),
])->get(env('BASE_URL') . '/api/service/v1/query/customer/showByEmail', [
    'email' => 'customer@example.com',
]);

if ($response->successful()) {
    $responseData = $response->json();
    if (isset($responseData['customers'])) {
        $customers = $responseData['customers'];
    } else {
        // handle the error here, e.g. log it or return an error response
    }
} else {
    // handle the error here, e.g. log it or return an error response
}

// Get transaction by reference number
$response = Http::withHeaders([
    'Content-Type' => 'application/json',
    'publicKey' => env('PUBLIC_KEY'),
    'b-access-token' => env('ACCESS_TOKEN'),
])->get(env('BASE_URL') . '/api/service/v1/query/merchant/wallet/transaction/{transaction_reference}');

// Re-query transaction by reference number
$response = Http::withHeaders([
    'Content-Type' => 'application/json',
    'publicKey' => env('PUBLIC_KEY'),
    'b-access-token' => env('ACCESS_TOKEN'),
])->get(env('BASE_URL') . '/api/service/v1/query/merchant/wallet/requery/transaction/{transaction_reference}');

// Check customer status
$response = Http::withHeaders([
    'Content-Type' => 'application/json',
    'publicKey' => env('PUBLIC_KEY'),
    'b-access-token' => env('ACCESS_TOKEN'),
])->get(env('BASE_URL') . '/api/service/v1/query/customer/check', [
    'virtualaccount' => '{NUBAN}',
]);

// Remove customer
$response = Http::withHeaders([
'Content-Type' => 'application/json',
'publicKey' => env('PUBLIC_KEY'),
'b-access-token' => env('ACCESS_TOKEN'),
])->get('{{baseUrl}}/api/service/v1/query/customer/delete?virtualaccount={{NUBAN}}');

if ($response->successful() && $response['status']) {
return response()->json(['message' => 'Successfully Deleted.'], 200);
} elseif ($response->successful() && !$response['status']) {
return response()->json(['message' => $response['message']], 422);
} else {
return response()->json(['message' => 'Failed to remove customer.'], 500);
   }
    }



  protected function monnify(Request $request) {
        if ($request->ajax()) {

            $validator = Validator::make($request->all(),[
                'secret_key'=>'required',
                'api_key'=>'required',
             ]);

              if ($validator->fails())  {
                    $error = $validator->errors()->first();
                    return response()->json(["code" => 500, "type" => "error", "message" => $error]);
              } else {
                  $app = new AppController();
                  $secret_key = $app->sanitize($request->secret_key);
                  $api_key = $app->sanitize($request->api_key);
                  $contract = $app->sanitize($request->contract);
                  $name = $app->sanitize($request->name);
                  $type = $app->sanitize($request->type);
                  $transfer_charge = $app->sanitize($request->transfer_charge);
                  $card_charge = $app->sanitize($request->card_charge);
                  $bank_code = $app->sanitize($request->bank_code);
                  $status = $app->sanitize($request->status);
                  $query = DB::table('monnify')->get();
                  if ($query->count() == 0) {
                    $insert = DB::table('monnify')->insert([
                        'secret_key' => $secret_key,
                        'api_key' => $api_key,
                        'contract' => $contract,
                        'name' => $name,
                        'type' => $type,
                        'transfer_charge' => $transfer_charge,
                        'card_charge' => $card_charge,
                        'bank_code' => $bank_code,
                        'status' => $status,
                    ]);
                      if ($insert) {
                        return response()->json(["code" => 200, "type" => "success", "message" => "Settings successfully added"]);
                      } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "A critical error ocurred"]);
                      }

                  } else {

                    DB::table('monnify')->update([
                        'secret_key' => $secret_key,
                        'api_key' => $api_key,
                        'contract' => $contract,
                        'name' => $name,
                        'type' => $type,
                        'transfer_charge' => $transfer_charge,
                        'card_charge' => $card_charge,
                        'bank_code' => $bank_code,
                        'status' => $status,
                    ]);
                        return response()->json(["code" => 200, "type" => "success", "message" => "Settings successfully updated"]);
                }
              }

        } else {
            $query = DB::table('monnify')->first();
            return view('gateway.monnify', ["monnify" => $query]);
        }
    }






    protected function virtualAccounts(Request $request) {
        if ($request->ajax()) {
            $entries = $request->entries;
            $search = $request->search;
            $query =  DB::table('virtual_accounts')->orderBy('id', 'desc')->where('bank_name', 'like', '%'.$search.'%')->paginate($entries);
            if ($query->count() > 0) {
        $table =  "<table id='table' class='table table-striped table-bordered' style='width:100%'>
        <thead>
            <tr>
                <th>S/N</th>
                <th>Username</th>
                <th>Name</th>
                <th>Bank</th>
                <td> Code </td>
                <th>Number</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>";
        $init = 1;
        foreach ($query as $va)  {
            $status = null;
         switch($va->status) {
            case 'available': $status = "<span class='badge badge-success'> available </span>";
            break;
            case 'unavailable': $status = "<span class='badge badge-danger'> unavailable </span>";
            break;
         }

        $serialNumber = $init++;
         $table .=  "<tr>
                <td>{$serialNumber}</td>
                <td>{$va->username}</td>
                <td>{$va->account_name}</td>
                <td>{$va->bank_name}</td>
                <td> {$va->bank_code} </td>
                <td>{$va->account_number}</td>
                <td> $status </td>
                <td>
                <button class='btn btn-danger btn-sm' data-toggle='tooltip' id='delete' data-id=". $va->id ." style='padding: 8px'> <i class='fas fa-trash action_icon' style='font-size: 10px;'></i> </button>
                </td>
            </tr>";
        }

        $table .= "</tbody>
    </table>
    <div class='float-start'> Showing ". $query->firstItem() ." to ". $query->lastItem() ." of ". $query->total() ." entries</div>
    <div class='float-end mt-4 mb-2'>". $query->links('pagination::bootstrap-4') ."</div>";

        return $table;
    } else {
        $notFound = "<div class='mt-3 text-center'>
        <img src='/images/no-result-found.png' width='200px' />
        </div>";
        return $notFound;
    }

        } else {
            $query = DB::table('monnify')->select('bank_code')->get();
            return view('gateway.virtual-account', [
                'bank_code' => $query->count() == 1 ? explode(',', $query[0]->bank_code) : null]);
        }
}





public function apply(Request $request) {
    if ($request->ajax()) {
        $validator = Validator::make($request->all(),[
            'bank'=>'required',
            'action'=>'required',
         ]);

          if ($validator->fails())  {
                $error = $validator->errors()->first();
                return response()->json(["code" => 500, "type" => "error", "message" => $error]);
          } else {
              $app = new AppController();
              $bank = $app->sanitize($request->bank);
              $action = $app->sanitize($request->action);
              if ($action == "delete") {
                DB::table('virtual_accounts')->where(['bank_code' => $bank])->delete();
            } else {
                DB::table('virtual_accounts')->where(['bank_code' => $bank])->update([
                    'status' => $action,
            ]);
            }
                return response()->json(["code" => 200, "type" => "success", "message" => "Action successfully processed"]);


          }
   }
}







}
