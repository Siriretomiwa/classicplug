<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;

class AdminController extends Controller
{
    //

    protected function index(Request $request) {
        if ($request->ajax()) {
            $query =  DB::table('admin')->get();
        $table =  "<table id='table' class='table table-striped table-bordered' style='width:100%'>
        <thead>
            <tr>
                <th>S/N</th>
                <th>Username</th>
                <th>Email</th>
                <th>Role</th>
                <th style='padding-right: 50px;'>Action</th>
            </tr>
        </thead>
        <tbody>";
        $init = 1;
        foreach ($query as $admin)  {
        $serialNumber = $init++;

         $table .=  "<tr>
                <td>{$serialNumber}</td>
                <td>{$admin->username}</td>
                <td>{$admin->email}</td>
                <td>{$admin->role}</td>

                <td>
                <button class='btn btn-danger btn-sm' data-toggle='tooltip' id='delete' data-id=". $admin->id ." style='padding: 8px'> <i class='fas fa-trash action_icon' style='font-size: 10px;'></i> </button>
            </td>
            </tr>";
        }

        $table .= "</tbody>
    </table>";

        return $table;

        } else {
            return view('admin.home');
        }
    }








protected function create(Request $request) {
    if ($request->ajax()) {
        $validator = Validator::make($request->all(),[
            'username'=>'required|min:5|max:30',
            'email' => 'required|email',
            'password' => 'required|min:8|max:30',
            'confirm_password' => 'required|same:password',
            'modify_service' => 'required',
            'allow_funding' => 'required',
            'modify_transaction' => 'required',
            'modify_user' => 'required',
         ]);

          if ($validator->fails())  {
                $error = $validator->errors()->first();
                return response()->json(["code" => 500, "type" => "error", "message" => $error]);
          } else {
              $app = new AppController();
              $username = $app->sanitize($request->username);
              $email = $app->sanitize($request->email);
              $password = $app->sanitize($request->password);
              $modify_service = $app->sanitize($request->modify_service);
              $allow_funding = $app->sanitize($request->modify_service);
              $modify_tranx = $app->sanitize($request->modify_service);
              $modify_user = $app->sanitize($request->modify_service);

              $query = DB::table('admin')->where(["username" => $username])->orWhere(["email" => $email])->get();

              if ($query->count() == 0) {
                $permission = [
                    "modify_service" => $modify_service,
                    "allow_funding" => $allow_funding,
                    "modify_tranx" => $modify_tranx,
                    "modify_user" => $modify_user,
                ];

                // return $permission;

                $query = DB::table('admin')->insert([
                    "token" => Str::random(150).uniqid(),
                    "username" => $username,
                    "email" => $email,
                    "password" => Hash::make($password),
                    "role" => "sub-admin",
                    "permission" => json_encode($permission),
                    "status" => "active"
                ]);
                if ($query) {
                    return response()->json(["code" => 200, "type" => "success", "message" => "Admin successfully registered"]);
                 } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                 }

              } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Username or email already exist"]);
              }


          }
    }
}





protected function delete(Request $request) {
    if ($request->ajax()) {
        if (!empty($request)) {
            if (!empty($request->id)) {
                $id = $request->id;
                $query = DB::table('admin')->where(['id' => $id])->get();
                if ($query->count() == 1) {
                    if ($query[0]->role !== "super-admin") {
                    $query = DB::table('admin')->where(['id' => $id])->delete();
                    if($query) {
                        return response()->json(["code" => 200, "message" => "Admin successfully deleted"]);
                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                    }

                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Action revoked"]);
                    }

                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
            }
        }
    }
}






}
