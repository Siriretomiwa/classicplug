<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;

class ResetPasswordController extends Controller
{
    //

    protected function index(Request $request) {
        if ($request->ajax()) {

            $validator = Validator::make($request->all(),[
                'password'=>'required|min:8|max:30',
                'confirm_password'=>'required|max:30|same:password',
             ]);

              if ($validator->fails())  {
                    $error = $validator->errors()->first();
                    return response()->json(["code" => 500, "type" => "error", "message" => $error]);
              } else {
                    $app = new AppController();
                    $password = $app->sanitize($request->password);
                    $token = Session::get('token');
                    $update = DB::table('admin')->where('token', $token)->update([
                        'password' => Hash::make($password),
                    ]);

                      if ($update) {
                        Session::forget('token');
                        return response()->json(["code" => 200, "type" => "success", "message" => "Password successfully reset"]);
                      } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "A critical error ocurred"]);
                      }

              }

        } else {
            return view('reset-password',);
        }
    }




}
