<?php

namespace App\Http\Controllers\Network;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\Network\Networks;
use App\Models\Category\Category;
use App\Models\Recharge\Charge;
use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\AppController;

class NetworkController extends Controller
{
    //

    protected function index(Request $request) {
        if ($request->ajax()) {
            $query =  Networks::all();
        $table =  "<table id='table' class='table table-striped table-bordered' style='width:100%'>
        <thead>
            <tr>

                <th>S/N</th>
                <th>Network</th>
                <th>Status</th>
                <th style='padding-right: 50px;'>Action</th>
            </tr>
        </thead>
        <tbody>";
        $init = 1;
        foreach ($query as $network)  {
        $serialNumber = $init++;
        if ($network->status == "available") {
            $checked = "checked";
        } else {
            $checked = "";
        }
         $table .=  "<tr>

                <td>{$serialNumber}</td>
                <td>{$network->name}</td>
                <td>

                <div class='custom-control custom-switch'>
                <input type='checkbox' class='custom-control-input toggleSwitch' data-id=". $network->id ." id='customSwitches$serialNumber' $checked>
                <label class='custom-control-label' for='customSwitches$serialNumber'></label>
              </div>

                </td>
                <td>
                <button class='btn btn-success btn-sm' data-toggle='tooltip'  id='edit' data-id=". $network->id ." style='background-color: #2dbe60; padding: 8px; margin-right: 8px'> <i class='fas fa-edit action_icon' style='font-size: 10px;'></i> </button>
                <button class='btn btn-danger btn-sm' data-toggle='tooltip' id='delete' data-id=". $network->id ." style='padding: 8px'> <i class='fas fa-trash action_icon' style='font-size: 10px;'></i> </button>
            </td>
            </tr>";
        }

        $table .= "</tbody>
    </table>";

        return $table;


        } else {
            return view('network.network');
        }
    }



    private function rechargeCharge($key, $network, $status, $category, $id) {
        $recharge = new Charge();
        $recharge->key = $key;
        $recharge->network_id = $id;
        $recharge->network = $network;
        $recharge->category = $category;
        $recharge->charge = "";
        $recharge->charge_type = "";
        $recharge->status = $status;
        if ($recharge->save()) {
            return true;
        }
    }


    protected function create(Request $request) {
        if ($request->ajax()) {
            $validator = Validator::make($request->all(),[
                'network'=>'required|regex:/^\S*$/u',
                'status'=>'required',
             ]);

              if ($validator->fails())  {
                    $error = $validator->errors()->first();
                    return response()->json(["code" => 500, "type" => "error", "message" => $error]);
              } else {
                  $app = new AppController();
                  $name = $app->sanitize($request->network);
                  $status = $app->sanitize($request->status);
                  $query = Networks::where(["name" => $name]);
                  $count = Networks::all()->count();
                  if ($query->count() == 0) {
                    $key = $count + 1;
                      $network = new Networks();
                      $network->key = $key;
                      $network->name = strtoupper($name);
                      $network->status = $status;
                     if ($network->save()){
                        $query = Category::all();
                        foreach ($query as $category) {
                            $this->rechargeCharge($key, $name, $status, $category->name, $network->id);
                        }
                        return response()->json(["code" => 200, "type" => "success", "message" => "$name successfully added"]);
                     } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                     }


                  } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "$name already exist"]);
                  }



              }
        }
    }



    protected function statusUpdate(Request $request) {
        if ($request->ajax()) {
            if (!empty($request)) {
                if (!empty($request->id) && !empty($request->status)) {
                    $app = new AppController();
                    $id = $app->sanitize($request->id);
                    $status = $app->sanitize($request->status);
                    $query = Networks::where(['id' => $id])->get();
                    if ($query->count() == 1) {
                        $query = Networks::where(['id' => $id])->update(['status' => $status]);
                        Charge::where(['network_id' => $id])->update(['status' => $status]);
                    if($query) {
                        return response()->json(["code" => 200, "status" => $status, "message" => "Status successfully set ".$status]);
                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                    }

                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                    }
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            }
        }
    }



/*******************************************************************************************************/

protected function delete(Request $request) {
    if ($request->ajax()) {
        if (!empty($request)) {
            if (!empty($request->id)) {
                $id = $request->id;
                $query = Networks::where(['id' => $id])->get();
                if ($query->count() == 1) {
                    $query = Networks::where(['id' => $id])->delete();
                    Charge::where(['network_id' => $id])->delete();
                if($query) {
                    return response()->json(["code" => 200, "message" => "Network successfully deleted"]);
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }

                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
            }
        }
    }
}




protected function edit(Request $request) {
    if ($request->ajax()) {
        if (!empty($request)) {
            if (!empty($request->id)) {
                $id = $request->id;
                $query = Networks::where(['id' => $id])->get();
                if ($query->count() == 1) {
                    $query = $query->first();
                    return response()->json(["code" => 200, "data" => [
                        'id' => $query->id,
                        'name' => $query->name,
                        'status' => $query->status,
                    ]]);

                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
            }
        }
    }
}





protected function update(Request $request) {
    if ($request->ajax()) {
        $validator = Validator::make($request->all(),[
            'id'=>'required',
            'network' => 'required',
            'status'=>'required',
         ]);

          if ($validator->fails())  {
                $error = $validator->errors()->first();
                return response()->json(["code" => 500, "type" => "error", "message" => $error]);
          } else {
              $app = new AppController();
              $id = $app->sanitize($request->id);
              $network = $app->sanitize($request->network);
              $status = $app->sanitize($request->status);
              $query = Networks::where(["id" => $id]);
              if ($query->count() == 1) {
                $query = $query->first();
                if ($network !== $query->name || $status !== $query->status) {
                    $networkCheck = Networks::where('name', $network)->get();
                    if ($networkCheck->count() == 0) {
                    $query = Networks::where(['id' => $id])->update(['name' => $network, 'status' => $status]);;
                    Charge::where('network_id', $id)->update(["network" => $network, "status" => $status]);
                    if ($query){
                        return response()->json(["code" => 200, "type" => "success", "message" => "Network successfully updated"]);
                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong!!"]);
                    }

                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Network already exist"]);
                    }

                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "No change was made"]);
                  }

              } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong!!"]);
              }

          }
    }
}





}

