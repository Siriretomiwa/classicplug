<?php

namespace App\Http\Controllers\Network;

use App\Http\Controllers\AppController;
use App\Http\Controllers\Controller;
use App\Models\Network\NetworkPrefix;
use Illuminate\Http\Request;

use App\Models\Network\Networks;
use Illuminate\Support\Facades\Validator;

class NetworkPrefixController extends Controller
{


    //
    protected function index(Request $request) {
        if ($request->ajax()) {
            $query =  NetworkPrefix::all();
        $table =  "<table id='table' class='table table-striped table-bordered' style='width:100%'>
        <thead>
            <tr>
            <th><div class='custom-control custom-switch'>
            <input class='form-check-input' id='allCheck' type='checkbox' value=''>
            </div></th>
                <th>S/N</th>
                <th>Network</th>
                <th>Prefix</th>
                <th style='padding-right: 50px;'>Action</th>
            </tr>
        </thead>
        <tbody>";
        $init = 1;
        foreach ($query as $prefix)  {
        $serialNumber = $init++;

         $table .=  "<tr>
                <td><div class='custom-control custom-switch'>
                <input class='form-check-input checkbox' type='checkbox' name='checkbox[]' data-id=". $prefix->id ." value=''>
                </div>
                </td>

                <td>{$serialNumber}</td>
                <td>{$prefix->network}</td>
                <td>{$prefix->prefix}</td>
                <td>
                <button class='btn btn-success btn-sm' data-toggle='tooltip'  id='edit' data-id=". $prefix->id ." style='background-color: #2dbe60; padding: 8px; margin-right: 8px'> <i class='fas fa-edit action_icon' style='font-size: 10px;'></i> </button>
                <button class='btn btn-danger btn-sm' data-toggle='tooltip' id='delete' data-id=". $prefix->id ." style='padding: 8px'> <i class='fas fa-trash action_icon' style='font-size: 10px;'></i> </button>
            </td>
            </tr>";
        }

        $table .= "</tbody>
    </table>";

        return $table;


        } else {
            return view('network.network-prefix', ["networks" => Networks::select('name')->get()]);
        }
    }





    protected function create(Request $request) {
        if ($request->ajax()) {
            $validator = Validator::make($request->all(),[
                'network'=>'required',
                'prefix'=>'required',
             ]);
              if ($validator->fails())  {
                    $error = $validator->errors()->first();
                    return response()->json(["code" => 500, "type" => "error", "message" => $error]);
              } else {
                  $app = new AppController();
                  $network = $app->sanitize($request->network);
                  $prefix = $app->sanitize($request->prefix);
                  $count = Networks::where(['name' => $network])->count();
                  $query = NetworkPrefix::where(["network" => $network, "prefix" => $prefix]);
                  $prefixes = explode(',', $prefix);
                  if ($count == 1) {
                      if (count($prefixes) == 1) {
                   if ($query->count() == 0) {
                      $networkPrefix = new NetworkPrefix();
                      $networkPrefix->network = $network;
                      $networkPrefix->prefix = $prefix;
                     if ($networkPrefix->save()){
                        return response()->json(["code" => 200, "type" => "success", "message" => "$network prefix successfully added"]);
                     } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                     }
                  } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Prefix already exist under the selected network"]);
                  }

                } else {

                    foreach ($prefixes as $prefix) {
                        $query = NetworkPrefix::where(["network" => $network, "prefix" => $prefix]);
                        if ($query->count() == 0) {
                        $networkPrefix = new NetworkPrefix();
                        $networkPrefix->network = $network;
                        $networkPrefix->prefix = $prefix;
                        $networkPrefix->save();
                        }
                    }

                    return response()->json(["code" => 200, "type" => "success", "message" => "$network prefix successfully added"]);
                }

                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Invalid Network"]);
                  }

              }
        }
    }





/*******************************************************************************************************/

protected function delete(Request $request) {
    if ($request->ajax()) {
        if (!empty($request)) {
            if (!empty($request->id)) {
                $id = $request->id;
                $query = NetworkPrefix::where(['id' => $id])->get();
                if ($query->count() == 1) {
                    $query = NetworkPrefix::where(['id' => $id])->delete();
                if($query) {
                    return response()->json(["code" => 200, "message" => "Prefix successfully deleted"]);
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }

                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
            }
        }
    }
}



/*******************************************************************************************************/

protected function action(Request $request) {
if ($request->ajax()) {
    if (!empty($request)) {
        if (!empty($request->arr) && !empty($request->action)) {
            foreach ($request->arr as $arr) {
                if ($request->action == "delete") {
                 $query = NetworkPrefix::where(['id' => $arr])->delete();
                }
            }
            if($query) {
                return response()->json(["code" => 200, "message" => "Action successfully processed"]);
            } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
            }
        } else {
            return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
        }
    }
}
}

/*******************************************************************************************************/



protected function edit(Request $request) {
    if ($request->ajax()) {
        if (!empty($request)) {
            if (!empty($request->id)) {
                $id = $request->id;
                $query = NetworkPrefix::where(['id' => $id])->get();
                if ($query->count() == 1) {
                    $query = $query->first();
                    return response()->json(["code" => 200, "data" => [
                        'id' => $query->id,
                        'network' => $query->network,
                        'prefix' => $query->prefix,
                    ]]);
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
            }
        }
    }
}





protected function update(Request $request) {
    if ($request->ajax()) {
        $validator = Validator::make($request->all(),[
            'id'=>'required',
            'network'=>'required',
            'prefix'=>'required',
         ]);

          if ($validator->fails())  {
                $error = $validator->errors()->first();
                return response()->json(["code" => 500, "type" => "error", "message" => $error]);
          } else {
              $app = new AppController();
              $id = $app->sanitize($request->id);
              $network = $app->sanitize($request->network);
              $prefix = $app->sanitize($request->prefix);
              $query = NetworkPrefix::where(["id" => $id]);
              $row = Networks::where(["name" => $network,])->get();
              $prefixCheck = NetworkPrefix::where(["network" => $network, 'prefix' => $prefix])->get();
              if ($query->count() == 1) {
                  if ($row->count() == 1) {
                        $query = $query->first();
                      if ($network !== $query->network || $prefix !== $query->prefix) {
                            if ($prefixCheck->count() == 0) {
                             $query = NetworkPrefix::where(['id' => $id])->update(['prefix' => $prefix, 'network' => $network,]);
                             if ($query) {
                                return response()->json(["code" => 200, "type" => "success", "message" => "Prefix successfully updated"]);
                            } else {
                                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong!!"]);
                            }

                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Prefix already exist"]);
                  }

                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "No change was made"]);
              }

                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Invalid Network"]);
                  }

              } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong!!"]);
              }

          }
    }
}





}
