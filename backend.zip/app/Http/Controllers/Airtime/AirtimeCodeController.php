<?php

namespace App\Http\Controllers\Airtime;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Http\Controllers\AppController;
use App\Models\Airtime\AirtimeCode;
use App\Models\Host\Host;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class AirtimeCodeController extends Controller
{
    //


    public function index(Request $request) {
        $app = new AppController();
        $host = $app->sanitize($request->host);
        if ($request->ajax()) {
            if (!empty($host)) {
            $list = AirtimeCode::where(["provider" => $host])->get();
                if ($list->count() !== 0) {
                $table =  "<table id='table' class='table table-striped table-bordered' style='width:100%'>
                <thead>
                    <tr>
                        <th>S/N</th>
                        <th>Network</th>
                        <th>Type</th>
                        <th>Code</th>
                    </tr>
                </thead>
                <tbody>";
                $init = 1;
                foreach ($list as $airtime)  {
                $serialNumber = $init++;
                $table .=  "<tr>
                        <td>{$serialNumber}</td>
                        <td>{$airtime->network}</td>
                        <td>{$airtime->type}</td>
                        <td><input type='text' data-id='$airtime->id' name='code[]' class='form-control form-white' value='$airtime->code' style='width: 160px'/></td>

                    </tr>";
                }

            $table .= "</tbody>
        </table>
        <br/>
        <button type='button' class='btn btn-block btn-secondary waves-effect waves-light' id='proceed' style='padding-top: 10px;'> <span id='btn-spinner'></span> <span id='btn-txt'> Save <i class='fas fa-save'></i></span></button>";

            return $table;

                } else {
                    echo "<script> alert('Provider not found');</script>";
                }
            } else {
                echo "<script> alert('Provider not found');</script>";
            }
        } else {
            return view("airtime.code", ['hosts' => Host::all()]);
        }

}




protected function update(Request $request) {
    if (!empty($request)) {
        if (!empty($request->code)) {
            foreach ($request->code as $code) {
                $id = $code["id"];
                if ($code["value"] == ""){
                    $code = "";
                } else {
                    $code = $code["value"];
                }
                $query = AirtimeCode::where(["id" => $id])->update(["code" => $code]);
            }
            if($query) {
                return response()->json(["code" => 200, "message" => "Code successfully saved"]);
            }
        }
    }
}



protected function merge(Request $request) {
    if ($request->ajax()) {
        $validator = Validator::make($request->all(),[
            'host_1'=>'required',
            'host_2' => 'required',
         ]);
          if ($validator->fails())  {
                $error = $validator->errors()->first();
                return response()->json(["code" => 500, "type" => "error", "message" => $error]);
          } else {
            $app = new AppController();
            $host_1 = $app->sanitize($request->host_1);
            $host_2 = $app->sanitize($request->host_2);
            if ($app->getHost($host_1)->count() == 1 && $app->getHost($host_2)->count() == 1) {
                $query = AirtimeCode::where('provider', $host_1)->get();
                foreach ($query as $row) {
                    AirtimeCode::where(['airtime_id' => $row->airtime_id, 'provider' => $host_2])->update([
                        'code' => $row->code,
                    ]);
                }
                return response()->json(["code" => 200, "type" => "success", "message" => "Merging successfully done"]);
            } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "An invalid host received"]);
            }
          }
    }
}




}
