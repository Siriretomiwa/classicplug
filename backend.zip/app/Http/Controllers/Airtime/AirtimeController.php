<?php

namespace App\Http\Controllers\Airtime;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\AppController;
use App\Models\Airtime\Airtime;
use App\Models\Airtime\AirtimeList;
use App\Models\Airtime\AirtimeCode;
use App\Models\Category\Category;
use App\Models\Host\Host;
use App\Models\Network\Networks;

class AirtimeController extends Controller
{
    //

    protected function index(Request $request) {
        if ($request->ajax()) {
            $query =  Airtime::all();
        $table =  "<table id='table' class='table table-striped table-bordered' style='width:100%'>
        <thead>
            <tr>
                <th><div class='custom-control custom-switch'>
                <input class='form-check-input' id='allCheck' type='checkbox' value=''>
                </div></th>
                <th>S/N</th>
                <th>Network</th>
                <th>Type</th>
                <th>Status</th>
                <th style='padding-right: 50px;'>Action</th>
            </tr>
        </thead>
        <tbody>";
        $init = 1;
        foreach ($query as $airtime)  {
        $serialNumber = $init++;
        if ($airtime->status == "available") {
            $checked = "checked";
        } else {
            $checked = "";
        }
         $table .=  "<tr>
                <td><div class='custom-control custom-switch'>
                <input class='form-check-input checkbox' type='checkbox' name='checkbox[]' data-id=". $airtime->id ." value=''>
                </div>
                </td>
                <td>{$serialNumber}</td>
                <td>{$airtime->network}</td>
                <td>{$airtime->type}</td>
                <td>

                <div class='custom-control custom-switch'>
                <input type='checkbox' class='custom-control-input toggleSwitch' data-id=". $airtime->id ." id='customSwitches$serialNumber' $checked>
                <label class='custom-control-label' for='customSwitches$serialNumber'></label>
              </div>

                </td>
                <td>
                <button class='btn btn-success btn-sm' data-toggle='tooltip'  id='edit' data-id=". $airtime->id ." style='background-color: #2dbe60; padding: 8px; margin-right: 8px'> <i class='fas fa-edit action_icon' style='font-size: 10px;'></i> </button>
                <button class='btn btn-danger btn-sm' data-toggle='tooltip' id='delete' data-id=". $airtime->id ." style='padding: 8px'> <i class='fas fa-trash action_icon' style='font-size: 10px;'></i> </button>
            </td>
            </tr>";
        }

        $table .= "</tbody>
    </table>";

        return $table;


        } else {
            return view('airtime.airtime', ["networks" => Networks::select('name')->get()]);
        }
    }


/*******************************************************************************************************/

    private function airtimeList($id, $key, $network, $network_key, $type, $status, $category) {
        $airtime = new AirtimeList();
        $airtime->key = $key;
        $airtime->airtime_id = $id;
        $airtime->network = $network;
        $airtime->network_id = $network_key;
        $airtime->type = strtoupper($type);
        $airtime->category = $category;
        $airtime->discount = "";
        $airtime->status = $status;
        if ($airtime->save()) {
            return true;
        }
    }

/*******************************************************************************************************/

    private function airtimeCode($id, $key, $network, $network_key, $type, $status, $provider) {
        $airtime = new AirtimeCode();
        $airtime->key = $key;
        $airtime->airtime_id =  $id;
        $airtime->network = $network;
        $airtime->network_id = $network_key;
        $airtime->type = strtoupper($type);
        $airtime->provider = $provider;
        $airtime->code = "";
        $airtime->status = $status;
        if ($airtime->save()) {
            return true;
        }
    }

  /*******************************************************************************************************/

protected function create(Request $request) {
        if ($request->ajax()) {
            $validator = Validator::make($request->all(),[
                'network'=>'required',
                'type' => 'required',
                'status'=>'required',
             ]);
              if ($validator->fails())  {
                    $error = $validator->errors()->first();
                    return response()->json(["code" => 500, "type" => "error", "message" => $error]);
              } else {
                  $app = new AppController();
                  $network = $app->sanitize($request->network);
                  $type = $app->sanitize($request->type);
                  $status = $app->sanitize($request->status);
                  $row = Networks::where('name', $network)->get();
                  if ($row->count() == 1) {
                  $query = Airtime::where(["network" => $network, "type" => $type]);
                  $count = Airtime::all()->count();
                    if ($query->count() == 0) {
                        $row = $row->first();
                        $network_id = $row->id;
                        $key = $count + 1;
                        $airtime = new Airtime();
                        $airtime->key = $key;
                        $airtime->network = $network;
                        $airtime->network_id = $network_id;
                        $airtime->type = strtoupper($type);
                        $airtime->status = $status;
                        if ($airtime->save()){
                            $query = Category::all();
                            foreach ($query as $category) {
                                $this->airtimeList($airtime->id, $key, $network, $network_id, $type, $status, $category->name);
                            }
                            $query = Host::all();
                            foreach ($query as $host) {
                                $this->airtimeCode($airtime->id, $key, $network, $network_id, $type, $status, $host->name);
                            }
                            return response()->json(["code" => 200, "type" => "success", "message" => "Airtime successfully saved"]);
                        } else {
                            return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong!!"]);
                        }

                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Airtime already exist"]);
                    }

                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Invalid network"]);
                  }

              }
        }
    }


/*******************************************************************************************************/


protected function action(Request $request) {
    if ($request->ajax()) {
        if (!empty($request)) {
            if (!empty($request->arr) && !empty($request->action)) {
                foreach ($request->arr as $arr) {
                    if ($request->action == "delete") {
                     $query = Airtime::where(['id' => $arr])->delete();
                              AirtimeCode::where(['airtime_id' => $arr])->delete();
                              AirtimeList::where(['airtime_id' => $arr])->delete();
                    } else  {
                     $query = Airtime::where(['id' => $arr])->update(['status' => $request->action]);
                                AirtimeCode::where(['airtime_id' => $arr])->update(['status' => $request->action]);
                                AirtimeList::where(['airtime_id' => $arr])->update(['status' => $request->action]);
                    }
                }
                if($query) {
                    return response()->json(["code" => 200, "message" => "Action successfully processed"]);
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
            }
        }
    }
}


/*******************************************************************************************************/

protected function delete(Request $request) {
    if ($request->ajax()) {
        if (!empty($request)) {
            if (!empty($request->id)) {
                $id = $request->id;
                $query = Airtime::where(['id' => $id])->get();
                if ($query->count() == 1) {
                    $query = Airtime::where(['id' => $id])->delete();
                    AirtimeCode::where(['airtime_id' => $id])->delete();
                    AirtimeList::where(['airtime_id' => $id])->delete();
                if($query) {
                    return response()->json(["code" => 200, "message" => "Airtime successfully deleted"]);
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }

                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
            }
        }
    }
}

/*******************************************************************************************************/

protected function edit(Request $request) {
    if ($request->ajax()) {
        if (!empty($request)) {
            if (!empty($request->id)) {
                $id = $request->id;
                $query = Airtime::where(['id' => $id])->get();
                if ($query->count() == 1) {
                    $query = $query->first();
                    return response()->json(["code" => 200, "data" => [
                        'id' => $query->id,
                        'network' => $query->network,
                        'type' => $query->type,
                        'status' => $query->status,
                    ]]);

                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
            }
        }
    }
}


/*******************************************************************************************************/

protected function statusUpdate(Request $request) {
    if ($request->ajax()) {
        if (!empty($request)) {
            if (!empty($request->id) && !empty($request->status)) {
                $app = new AppController();
                $id = $app->sanitize($request->id);
                $status = $app->sanitize($request->status);
                $query = Airtime::where(['id' => $id])->get();
                if ($query->count() == 1) {
                    $query = Airtime::where(['id' => $id])->update(['status' => $status]);
                    AirtimeCode::where(['airtime_id' => $id])->update(['status' => $status]);
                    AirtimeList::where(['airtime_id' => $id])->update(['status' => $status]);
                if($query) {
                    return response()->json(["code" => 200, "status" => $status, "message" => "Status successfully set ".$status]);
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }

                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
            }
        }
    }
}


/*******************************************************************************************************/

private function updateQuery($id, $network_id, $network, $type, $status) {
    Airtime::where(['id' => $id])->update(['network' => $network, 'network_id' => $network_id, 'type' => $type, 'status' => $status]);
    AirtimeCode::where(['airtime_id' => $id])->update(['network' => $network, 'network_id' => $network_id, 'type' => $type, 'status' => $status]);
    AirtimeList::where(['airtime_id' => $id])->update(['network' => $network, 'network_id' => $network_id, 'type' => $type, 'status' => $status]);
    return true;
}


protected function update(Request $request) {
    if ($request->ajax()) {
        $validator = Validator::make($request->all(),[
            'id'=>'required',
            'network'=>'required',
            'type' => 'required',
            'status'=>'required',
         ]);

          if ($validator->fails())  {
                $error = $validator->errors()->first();
                return response()->json(["code" => 500, "type" => "error", "message" => $error]);
          } else {
              $app = new AppController();
              $id = $app->sanitize($request->id);
              $network = $app->sanitize($request->network);
              $type = $app->sanitize($request->type);
              $status = $app->sanitize($request->status);
              $query = Airtime::where(["id" => $id]);
              $row = Networks::where('name', $network)->get();
              if ($query->count() == 1) {
                  if ($row->count() == 1) {
                $query = $query->first();
                if ($network !== $query->network || $type !== $query->type || $status !== $query->status) {

                if ($network == $query->network && $type == $query->type) {
                    $query = $this->updateQuery($id, $row[0]->id, $network, $type, $status);
                 if ($query){
                    return response()->json(["code" => 200, "type" => "success", "message" => "Airtime successfully updated"]);
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong!!"]);
                }

            } else {
                $query = Airtime::where(['network' => $network, 'type' => $type])->get();
                if ($query->count() == 0) {
                    $query = $this->updateQuery($id, $row[0]->id, $network, $type, $status);
                    if ($query){
                        return response()->json(["code" => 200, "type" => "success", "message" => "Airtime successfully updated"]);
                     } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong!!"]);
                     }
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Airtime already exist"]);
                }

            }

                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "No change was made"]);
                  }

                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Invalid Network"]);
                  }

              } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong!!"]);
              }

          }
    }
}

/*******************************************************************************************************/











}
