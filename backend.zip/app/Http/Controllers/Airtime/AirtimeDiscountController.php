<?php

namespace App\Http\Controllers\Airtime;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Http\Controllers\AppController;
use App\Models\Airtime\AirtimeList;
use App\Models\Category\Category;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class AirtimeDiscountController extends Controller
{
    //


    public function index(Request $request) {
        $app = new AppController();
        $category = $app->sanitize($request->category);
        if ($request->ajax()) {
            if (!empty($category)) {
            $list = AirtimeList::where(["category" => $category])->get();
                if ($list->count() !== 0) {
                $table =  "<table id='table' class='table table-striped table-bordered' style='width:100%'>
                <thead>
                    <tr>
                        <th>S/N</th>
                        <th>Network</th>
                        <th>Type</th>
                        <th>Discount(%)</th>
                    </tr>
                </thead>
                <tbody>";
                $init = 1;
                foreach ($list as $airtime)  {
                $serialNumber = $init++;
                $table .=  "<tr>
                        <td>{$serialNumber}</td>
                        <td>{$airtime->network}</td>
                        <td>{$airtime->type}</td>
                        <td><input type='number' data-id='$airtime->id' name='discount[]' class='form-control form-white' value='$airtime->discount' style='width: 100px'/></td>

                    </tr>";
                }

            $table .= "</tbody>
        </table>
        <br/>
        <button type='button' class='btn btn-block btn-secondary waves-effect waves-light' id='proceed' style='padding-top: 10px;'> <span id='btn-spinner'></span> <span id='btn-txt'> Save <i class='fas fa-save'></i></span></button>";

            return $table;

                } else {
                    echo "<script> alert('No result found for this category');</script>";
                }
            } else {
                echo "<script> alert('No result found for this category');</script>";
            }
        } else {
            return view("airtime.discount", ['categories' => Category::all()]);
        }

}



protected function update(Request $request) {
    if (!empty($request)) {
        if (!empty($request->discount)) {
            foreach ($request->discount as $discount) {
                $id = $discount["id"];
                if ($discount["value"] == ""){
                    $discount = "";
                } else {
                    $discount = $discount["value"];
                }
                if (is_numeric($discount) || $discount == '') {
                    $query = AirtimeList::where(["id" => $id])->update(["discount" => $discount]);
                }
            }
            if($query) {
                return response()->json(["code" => 200, "message" => "Discount successfully saved"]);
            }
        }
    }
}




protected function merge(Request $request) {
    if ($request->ajax()) {
        $validator = Validator::make($request->all(),[
            'category_1'=>'required',
            'category_2' => 'required',
         ]);
          if ($validator->fails())  {
                $error = $validator->errors()->first();
                return response()->json(["code" => 500, "type" => "error", "message" => $error]);
          } else {
            $app = new AppController();
            $category_1 = $app->sanitize($request->category_1);
            $category_2 = $app->sanitize($request->category_2);
            if ($app->getCategory($category_1)->count() == 1 && $app->getCategory($category_1)->count() == 1) {
                $query = AirtimeList::where('category', $category_1)->get();
                foreach ($query as $row) {
                    AirtimeList::where(['airtime_id' => $row->airtime_id, 'category' => $category_2])->update([
                        'discount' => $row->discount,
                    ]);
                }
                return response()->json(["code" => 200, "type" => "success", "message" => "Merging successfully done"]);
            } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "An invalid host received"]);
            }
          }
    }
}






}
