<?php

namespace App\Http\Controllers\Notification;

use App\Http\Controllers\Controller;
use App\Models\Category\Category;
use App\Models\User\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Log;

class EmailController extends Controller
{
    //

    public function email(Request $request) {
        if ($request->ajax()) {
            $emails = $request->recipient == "all" ? User::pluck('email') : User::where('category', $request->recipient)->pluck('email');
            // return $emails;
            if ($emails->count() > 0) {
            $details = [
                "message" => $request->message,
            ];

                foreach($emails as $email) {
                    try {
                        Mail::to($email)->send(new \App\Mail\WebMail($details, $request->title));
                        // return response()->json(["code" => 200, "type" => "success", "message" => "Notification has successfully been delivered to recipient"]);
                    } catch (\Exception $e) {
                        // return $e;
                        Log::info($e);
                        // return response()->json(["code" => 500, "type" => "error", "message" => "An error occured while sending mail"]);
                    }
                }

                return response()->json(["code" => 200, "type" => "success", "message" => "Notification has successfully been delivered to recipient"]);

            } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "No user found"]);
            }

        } else {
            return view('email.notification', ['categories' => Category::all()]);
        }

    }


}
