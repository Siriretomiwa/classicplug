<?php

namespace App\Http\Controllers\Notification;

use App\Http\Controllers\AppController;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\Category\Category;
use App\Models\User\User;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class NotificationController extends Controller
{
    //

    public function dashboard (Request $request) {
        if ($request->ajax()) {
                $validator = Validator::make($request->all(),[
                    'message'=>'required',
                    'visibility' => 'required|max:1000',
                 ]);

                  if ($validator->fails())  {
                        $error = $validator->errors()->first();
                        return response()->json(["code" => 500, "type" => "error", "message" => $error]);
                  } else {
                      $app = new AppController();
                      $message = $app->sanitize($request->message);
                      $visibility = $app->sanitize($request->visibility);
                      $query = DB::table('notification')->get();
                      if ($query->count() == 0) {
                        return  DB::table('notification')->insert([
                              'message' => $message,
                              'visibility' => $visibility,
                              'date' => Carbon::now(),
                        ]) ? response()->json(["code" => 200, "type" => "success", "message" => "Notification successfully updated"])
                            : response()->json(["code" => 500, "type" => "error", "message" => "Oops an error occured please retry"]);

                      } else {
                        return  DB::table('notification')->update([
                                'message' => $message,
                                'visibility' => $visibility,
                                'date' => Carbon::now(),
                        ]) ? response()->json(["code" => 200, "type" => "success", "message" => "Notification successfully updated"])
                            : response()->json(["code" => 500, "type" => "error", "message" => "Oops an error occured please retry"]);

                      }
                  }

        } else {
            return view('notification.dashboard', ['message' => DB::table('notification')->first()]);
        }
    }


    public function sms(Request $request) {
        if ($request->ajax()) {
            $numbers = $request->recipient == "all" ? User::pluck('phone_number') : User::where('category', $request->recipient)->pluck('phone_number');
            // return $numbers;
            if ($numbers->count() > 0) {
                $query = DB::table('bulk_sms')->get();
                $token = $query->count() == 1 ? $query[0]->key : null;
                $message = $request->message;
                $senderid = $request->sender;
                $receipients = json_encode($numbers); //each of the numbers are separated with a comma
                $baseurl = 'https://smartsmssolutions.com/api/json.php?';
                $sms_array = array
                    (
                        'sender' => $senderid,
                        'to' => $receipients,
                        'message' => $message,
                        'type' => '0',
                        'routing' => 3,
                        'token' => $token,
                    );
                $params = http_build_query($sms_array);
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL,$baseurl);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
                $output=curl_exec($ch);
                curl_close($ch);
                $json = json_decode($output);
                // return $json;
                if (isset($json->code) && $json->code == 1000) {
                    return response()->json(["code" => 200, "type" => "success", "message" => "Message has successfully been sent to recipient"]);
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "An error occured while sending SMS"]);
                }

            } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "No user found"]);
            }

        } else {
            return view('notification.sms', ['categories' => Category::all()]);
        }

    }



}
