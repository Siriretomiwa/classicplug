<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;

class AppController extends Controller
{
    //

    public $date;

    public function __construct() {
        $this->date = Carbon::now('Africa/Lagos');
    }


    public function admin() {
        $token = Session::get('token');
        $query = DB::table('admin')->where('token', $token)->get();
        if ($query->count() == 1) {
            return [
                "role" => $query[0]->role,
                "permission" => json_decode($query[0]->permission)
            ];
        }
    }


    public function sanitize($input) {
        $input = strip_tags($input);
        $input = htmlspecialchars($input);
        $input = trim($input);
        return $input;
      }

      public function reference() {
        $number = "";
        for ($i = 0;$i < 3;$i++) {
            $min = ($i == 0) ? 1 : 0;
            $number.= mt_rand($min, 3);
        }
        $ref = $number . round(microtime(true));
        return $ref . date("Ymdhis");
    }

    public function getHost($host) {
        return DB::table('host')->where([
            'name' => $host,
        ])->get();
    }


    public function getCategory($category) {
        return DB::table('category')->where([
            'name' => $category,
        ])->get();
    }




}
