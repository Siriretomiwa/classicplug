<?php

namespace App\Http\Controllers\Category;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;


use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\AppController;
use App\Models\Category\Category;
// Data
use App\Models\Data\Data;
use App\Models\Data\DataList;
// Airtime
use App\Models\Airtime\Airtime;
use App\Models\Airtime\AirtimeList;
// Bills
use App\Models\Bills\Bills;
use App\Models\Bills\BillsList;
// Cable
use App\Models\Cable\Cable;
use App\Models\Cable\CableList;
// Recharge
use App\Models\Recharge\Range;
use App\Models\Recharge\Charge;
// Exam
use App\Models\Exam\Exam;
use App\Models\Exam\ExamList;
// Airtime to cash
use App\Models\AirtimeCash\AirtimeCash;
use App\Models\AirtimeCash\AirtimeCashList;
// Smile Bundle
use App\Models\Smile\Bundle;
use App\Models\Smile\BundleList;
use App\Models\User\User;

class CategoryController extends Controller
{
    //

    protected function index(Request $request) {
        if ($request->ajax()) {
            $query =  Category::all();
        $table =  "<table id='table' class='table table-striped table-bordered' style='width:100%'>
        <thead>
            <tr>
                <th>S/N</th>
                <th>Package</th>
                <th>Price</th>
                <th>Permission</th>
                <th>Status</th>
                <th style='padding-right: 50px;'>Action</th>
            </tr>
        </thead>
        <tbody>";
        $init = 1;
        foreach ($query as $category)  {
        $serialNumber = $init++;
        if ($category->status == "available") {
            $checked = "checked";
        } else {
            $checked = "";
        }
         $table .=  "<tr>
                <td>{$serialNumber}</td>
                <td>{$category->name}</td>";
                if($category->price == 0) {
                    $table .= "<td>free</td>";
                } else {
                    $table .= "<td>&#8358;{$category->price}</td>";
                }

                if($category->permission == "all") {
                    $table .= "<td>Everyone</td>";
                } else {
                    $table .= "<td>{$category->permission}</td>";
                }


                $table .= "<td>
                <div class='custom-control custom-switch'>
                <input type='checkbox' class='custom-control-input toggleSwitch' data-id=". $category->id ." id='customSwitches$serialNumber' $checked>
                <label class='custom-control-label' for='customSwitches$serialNumber'></label>
              </div>
                </td>
                <td>
                <button class='btn btn-success btn-sm' data-toggle='tooltip'  id='edit' data-id=". $category->id ." style='background-color: #2dbe60; padding: 8px; margin-right: 8px'> <i class='fas fa-edit action_icon' style='font-size: 10px;'></i> </button>
                <button class='btn btn-danger btn-sm' data-toggle='tooltip' id='delete' data-id=". $category->id ." style='padding: 8px'> <i class='fas fa-trash action_icon' style='font-size: 10px;'></i> </button>
                </td>
            </tr>";
        }



        $table .= "</tbody>
    </table>";

        return $table;


        } else {
            return view('category.category',  ['categories' => Category::all()]);
        }
    }



protected function createCategory($key, $name, $price, $level, $permission, $apply_charge, $status) {
        $category = new Category();
        $category->key = $key;
        $category->name = $name;
        $category->price = $price;
        $category->level = $level;
        $category->permission = $permission;
        $category->apply_charge = $apply_charge;
        $category->status = $status;
       if ($category->save()){
          return true;
       } else {
          return false;
    }
}



        protected function create(Request $request) {
            if ($request->ajax()) {
                $validator = Validator::make($request->all(),[
                    'name' => 'required',
                    'permission' => 'required',
                    'apply_charge' => 'required',
                    'status' => 'required',
                 ]);

                  if ($validator->fails())  {
                        $error = $validator->errors()->first();
                        return response()->json(["code" => 500, "type" => "error", "message" => $error]);
                  } else {
                      $app = new AppController();
                      $name = $app->sanitize($request->name);
                      $name = ucwords($name);
                      $price = $app->sanitize($request->price);
                      $permission = $app->sanitize($request->permission);
                      $apply_charge = $app->sanitize($request->apply_charge);
                      $level = $app->sanitize($request->level);
                      $status = $app->sanitize($request->status);
                      $query = Category::where(["name" => $name])->get();
                      $count = $query->count();
                      $category_count = Category::all()->count();
                      if ($category_count == 0 && $name == "Default" || $category_count > 0) {
                      if ($price == "" || $apply_charge == "no") {
                          $price = 0;
                      }
                      if ($level == "") {
                          $level = "none";
                      }
                      if ($query->count() == 0) {
                          $key = $count + 1;
                        $query =  $this->createCategory($key, $name, $price, $level, $permission, $apply_charge, $status);
                         if ($query){
                            $this->data($name);
                            $this->airtime($name);
                            $this->bills($name);
                            $this->cable($name);
                            $this->recharge($name);
                            $this->exam($name);
                            $this->airtimeToCash($name);
                            $this->smileBundle($name);
                            return response()->json(["code" => 200, "type" => "success", "message" => "$name successfully added"]);
                         } else {
                            return response()->json(["code" => 500, "type" => "error", "message" => "A critical error occured"]);
                         }

                        } else {
                            return response()->json(["code" => 500, "type" => "error", "message" => "$request->name category already exist"]);
                          }

                      } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Please create a category with the name Default to begin"]);
                      }


                  }
            }
        }


/*-------------------------------------------------------------------------------*/

private function data($name) {
    $plans =  Data::all();
    foreach($plans as $plan) {
        $data = new DataList();
        $data->key = $plan->key;
        $data->data_id = $plan->id;
        $data->network = $plan->network;
        $data->network_id = $plan->network_id;
        $data->type = strtoupper($plan->type);
        $data->plan = $plan->plan;
        $data->size = $plan->size;
        $data->category = $name;
        $data->amount = "";
        $data->status = $plan->status;
        $data->save();
    }
    return true;
}




private function airtime($name) {
    $airtimes =  Airtime::all();
    foreach($airtimes as $airtime) {
        $airtimeList= new AirtimeList();
        $airtimeList->key = $airtime->key;
        $airtimeList->airtime_id = $airtime->id;
        $airtimeList->network = $airtime->network;
        $airtimeList->network_id = $airtime->network_id;
        $airtimeList->type = strtoupper($airtime->type);
        $airtimeList->category = $name;
        $airtimeList->discount = "";
        $airtimeList->status = $airtime->status;
        $airtimeList->save();
    }
    return true;
}



private function bills($name) {
    $electricity =  Bills::all();
    foreach($electricity as $disco) {
        $bills = new BillsList();
        $bills->key = $disco->key;
        $bills->bills_id = $disco->id;
        $bills->name = $disco->name;
        $bills->disco = $disco->disco;
        $bills->category = $name;
        $bills->charge = "";
        $bills->charge_type = "";
        $bills->status = $disco->status;
        $bills->save();
    }
    return true;
}




private function cable($name) {
    $cables =  Cable::all();
    foreach($cables as $tv) {
        $cable = new CableList();
        $cable->key = $tv->key;
        $cable->cable_id = $tv->id;
        $cable->cable = $tv->cable;
        $cable->category = $name;
        $cable->charge = "";
        $cable->charge_type = "";
        $cable->status = $tv->status;
        $cable->save();
    }
    return true;
}


private function checkNetwork($network, $name) {
    return Charge::where(['network' => $network, 'category' => $name])->get();
}

private function recharge($name) {
    $pinRange =  Range::all();
    foreach($pinRange as $pinCharge) {
        if ($this->checkNetwork($pinCharge->network, $name)->count() == 0) {
            $Charge = new Charge();
            $Charge->key = $pinCharge->key;
            $Charge->network = $pinCharge->network;
            $Charge->network_id = $pinCharge->network_id;
            $Charge->charge = "";
            $Charge->charge_type = "";
            $Charge->category = $name;
            $Charge->status = $pinCharge->status;
            $Charge->save();
        }
    }
    return true;
}



private function exam($name) {
    $exams =  Exam::all();
    foreach($exams as $exam) {
        $resultChecker = new ExamList();
        $resultChecker->key = $exam->key;
        $resultChecker->exam_id = $exam->id;
        $resultChecker->name = $exam->name;
        $resultChecker->exam = $exam->exam;
        $resultChecker->category = $name;
        $resultChecker->amount = "";
        $resultChecker->status = $exam->status;
        $resultChecker->save();
    }
    return true;
}



private function airtimeToCash($name) {
    $airtimeToCash =  AirtimeCash::all();
    foreach($airtimeToCash as $airtime_to_cash) {
        $airtimeCash = new AirtimeCashList();
        $airtimeCash->key = $airtime_to_cash->key;
        $airtimeCash->airtime_cash_id = $airtime_to_cash->id;
        $airtimeCash->network = $airtime_to_cash->network;
        $airtimeCash->network_id = $airtime_to_cash->network_id;
        $airtimeCash->phone_number = $airtime_to_cash->phone_number;
        $airtimeCash->category = $name;
        $airtimeCash->rate = "";
        $airtimeCash->status = $airtime_to_cash->status;
        $airtimeCash->save();
    }
    return true;
}




private function smileBundle($name) {
    $smileBundle =  Bundle::all();
    foreach($smileBundle as $smile) {
        $data = new BundleList();
        $data->key = $smile->key;
        $data->bundle_id = $smile->id;
        $data->plan = $smile->plan;
        $data->category = $name;
        $data->amount = "";
        $data->status = $smile->status;
        $data->save();
    }
    return true;
}






/*******************************************************************************************************/


protected function statusUpdate(Request $request) {
    if ($request->ajax()) {
        if (!empty($request)) {
            if (!empty($request->id) && !empty($request->status)) {
                $app = new AppController();
                $id = $app->sanitize($request->id);
                $status = $app->sanitize($request->status);
                $query = Category::where(['id' => $id])->get();
                if ($query->count() == 1) {
                    $query = Category::where(['id' => $id])->update(['status' => $status]);
                if($query) {
                    return response()->json(["code" => 200, "status" => $status, "message" => "Status successfully set ".$status]);
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }

                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
            }
        }
    }
}



/*******************************************************************************************************/


protected function edit(Request $request) {
    if ($request->ajax()) {
        if (!empty($request)) {
            if (!empty($request->id)) {
                $id = $request->id;
                $query = Category::where(['id' => $id])->get();
                if ($query->count() == 1) {
                    $query = $query->first();
                    return response()->json(["code" => 200, "data" => [
                        'id' => $query->id,
                        'name' => $query->name,
                        'level' => $query->level,
                        'permission' => $query->permission,
                        'apply_charge' => $query->apply_charge,
                        'price' => $query->price,
                        'status' => $query->status,
                    ]]);

                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
            }
        }
    }
}



/*******************************************************************************************************/



protected function delete(Request $request) {
    if ($request->ajax()) {
        if (!empty($request)) {
            if (!empty($request->id)) {
                $id = $request->id;
                $query_ = Category::where(['id' => $id])->get();
                if ($query_->count() == 1) {
                    $name = $query_[0]->name;
                    if($name !== "Default") {
                    $query = Category::where(['id' => $id])->delete();
                    if($query) {
                        $this->deleteData($name);
                        $this->deleteAirtime($name);
                        $this->deleteBills($name);
                        $this->deleteCable($name);
                        $this->deleteRecharge($name);
                        $this->deleteExam($name);
                        $this->deleteAirtimeToCash($name);
                        $this->deleteSmileBundle($name);
                        User::where('category', $name)->update([
                            'category' => 'default',
                        ]);
                        return response()->json(["code" => 200, "message" => "Category successfully deleted"]);
                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                    }
                } else {
                    
                }

                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
            }
        }
    }
}





/*----------------------Delete---------------------------------------------------------*/

private function deleteData($name) {
    $query =  DataList::where(['category' => $name])->delete();
    if ($query) {
        return true;
    }
}


private function deleteAirtime($name) {
    $query =  AirtimeList::where(['category' => $name])->delete();
    if ($query) {
        return true;
    }
}


private function deleteBills($name) {
    $query =  BillsList::where(['category' => $name])->delete();
    if ($query) {
        return true;
    }
}


private function deleteCable($name) {
    $query =  CableList::where(['category' => $name])->delete();
    if ($query) {
        return true;
    }
}


private function deleteRecharge($name) {
    $query =  Charge::where(['category' => $name])->delete();
    if ($query) {
        return true;
    }
}



private function deleteExam($name) {
    $query =  ExamList::where(['category' => $name])->delete();
    if ($query) {
        return true;
    }
}



private function deleteAirtimeToCash($name) {
    $query =  AirtimeCashList::where(['category' => $name])->delete();
    if ($query) {
        return true;
    }
}


private function deleteSmileBundle($name) {
    $query =  BundleList::where(['category' => $name])->delete();
    if ($query) {
        return true;
    }
}




/*******************************************************************************************************/

private function updateQuery($id, $name, $permission, $apply_charge, $level, $price, $status) {
   $query = Category::where(['id' => $id])->update(['name' => $name, 'permission' => $permission, 'apply_charge' => $apply_charge, 'level' => $level, 'price' => $price, 'status' => $status]);
   if ($query) {
        return true;
   }
}


protected function update(Request $request) {
    if ($request->ajax()) {
        $validator = Validator::make($request->all(),[
            'id'=>'required',
            'name' => 'required',
            'permission' => 'required',
            'apply_charge' => 'required',
            'status' => 'required',
         ]);

          if ($validator->fails())  {
                $error = $validator->errors()->first();
                return response()->json(["code" => 500, "type" => "error", "message" => $error]);
          } else {
              $app = new AppController();
              $id = $app->sanitize($request->id);
              $name = $app->sanitize($request->name);
              $price = $app->sanitize($request->price);
              $permission = $app->sanitize($request->permission);
              $apply_charge = $app->sanitize($request->apply_charge);
              $level = $app->sanitize($request->level);
              $status = $app->sanitize($request->status);
              $query = Category::where(["id" => $id]);

              if ($price == "" || $apply_charge == "no") {
                  $price = 0;
              }
              if ($level == "") {
                  $level = "none";
              }
              if ($query->count() == 1) {
                $query = $query->first();
                if ($name !== $query->name || $permission !== $query->permission || $apply_charge !== $query->apply_charge || $level !== $query->level || $price !== $query->price || $status !== $query->status) {
                    if ($name !== $level) {
                    $old_category = $query->name;
                    if ($name !== $old_category) {
                        $query_ = Category::where(["name" => $name])->get();
                        if ($query_->count() == 0) {
                            $query = $this->updateQuery($id, $name, $permission, $apply_charge, $level, $price, $status);
                            // Update level name
                            Category::where(['level' => $old_category])->update(['level' => $name]);
                            if ($query){
                                $this->updateData($name, $old_category);
                                $this->updateAirtime($name, $old_category);
                                $this->updateBills($name, $old_category);
                                $this->updateCable($name, $old_category);
                                $this->updateRecharge($name, $old_category);
                                $this->updateExam($name, $old_category);
                                $this->updateAirtimeToCash($name, $old_category);
                                $this->updateSmileBundle($name, $old_category);
                                 return response()->json(["code" => 200, "type" => "success", "message" => "Category successfully updated"]);
                             } else {
                                 return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong!!"]);
                             }
                        } else {
                            return response()->json(["code" => 500, "type" => "error", "message" => "Category already exist"]);
                        }

                            } else {
                            $query = $this->updateQuery($id, $name, $permission, $apply_charge, $level, $price, $status);
                            if ($query){
                                    return response()->json(["code" => 200, "type" => "success", "message" => "Category successfully updated"]);
                                } else {
                                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong!!"]);
                                }
                            }


                        } else {
                            return response()->json(["code" => 500, "type" => "error", "message" => "Update failed: users can't upgrade to the same category"]);
                    }

                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "No change was made"]);
                  }


              } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong!!"]);
              }

          }
    }
}




/*----------------------Update---------------------------------------------------------*/

private function updateData($name, $old_category) {
    $query =  DataList::where(['category' => $old_category])->update(['category' => $name]);
    if ($query) {
        return true;
    }
}


private function updateAirtime($name, $old_category) {
    $query =  AirtimeList::where(['category' => $old_category])->update(['category' => $name]);
    if ($query) {
        return true;
    }
}


private function updateBills($name, $old_category) {
    $query =  BillsList::where(['category' => $old_category])->update(['category' => $name]);
    if ($query) {
        return true;
    }
}


private function updateCable($name, $old_category) {
    $query =  CableList::where(['category' => $old_category])->update(['category' => $name]);
    if ($query) {
        return true;
    }
}


private function updateRecharge($name, $old_category) {
    $query =  Charge::where(['category' => $old_category])->update(['category' => $name]);
    if ($query) {
        return true;
    }
}



private function updateExam($name, $old_category) {
    $query =  ExamList::where(['category' => $old_category])->update(['category' => $name]);
    if ($query) {
        return true;
    }
}


private function updateAirtimeToCash($name, $old_category) {
    $query =  AirtimeCashList::where(['category' => $old_category])->update(['category' => $name]);
    if ($query) {
        return true;
    }
}


private function updateSmileBundle($name, $old_category) {
    $query =  BundleList::where(['category' => $old_category])->update(['category' => $name]);
    if ($query) {
        return true;
    }
}

}
