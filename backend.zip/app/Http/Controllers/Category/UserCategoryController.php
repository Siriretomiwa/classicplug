<?php

namespace App\Http\Controllers\Category;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\Category\Category;
use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\AppController;
use App\Http\Controllers\Transaction\TransactionController;
use App\Models\User\User;

class UserCategoryController extends Controller
{
    //
    private $service = "Account Upgrade";

    protected function index() {
            return view('category.user-category', ['categories' => Category::all()]);
    }

    protected function save(Request $request) {
        if ($request->ajax()) {
            $validator = Validator::make($request->all(),[
                'category' => 'required',
                'username' => 'required',
                'charge' => 'required',
             ]);

              if ($validator->fails())  {
                    $error = $validator->errors()->first();
                    return response()->json(["code" => 500, "type" => "error", "message" => $error]);
              } else {
                  $app = new AppController();
                  $transaction = new TransactionController();
                  $username = $app->sanitize($request->username);
                  $category = $app->sanitize($request->category);
                  $charge = $app->sanitize($request->charge);
                  $username_array = explode(',', $username);
                  $usernames = [];
                  $invalid_username = [];

                  foreach ($username_array as $user) {
                    if ($user !== "") {
                        array_push($usernames, $user);
                    }
                 }

                  $categoryQuery = Category::where('name', $category)->get();
                  if ($categoryQuery->count() == 1) {
                      if (count($usernames) == 1) {
                        $query = User::where(['username' => $usernames[0]])->get();
                        if ($query->count() == 1) {
                            if ($query[0]->category !== $category) {
                                if ($charge == "yes") {
                                    $balance = $query[0]->wallet - $categoryQuery[0]->price;
                                    User::where(['username' => $usernames[0]])->update(['wallet' => $balance]);
                                    // Add to transaction
                                    $description = "Account Upgarde to ".$categoryQuery[0]->name;
                                    $transaction->save($query[0]->username, $query[0]->email, $this->service, "System", $description, $query[0]->phone_number, $categoryQuery[0]->price, "Debit", $query[0]->wallet, $balance, $app->reference(), $categoryQuery[0]->name, "null", $categoryQuery[0]->id, "null", "null", "null", 'success', $app->date);
                                }

                                User::where(['username' => $usernames[0]])->update(['category' => $category]);

                            }  else {
                                return response()->json(["code" => 500, "type" => "error", "message" => "Request rejected user already in this category"]);
                            }

                        } else {
                            return response()->json(["code" => 500, "type" => "error", "message" => "User not found"]);
                        }
                      } else {
                        foreach ($usernames as $username) {
                            $query = User::where(['username' => $username])->get();
                            if ($query->count() == 1) {
                                if ($query[0]->category !== $category) {
                                    if ($charge == "yes") {
                                        $balance = $query[0]->wallet - $categoryQuery[0]->price;
                                        User::where(['username' => $username])->update(['wallet' => $balance]);
                                        // Add to transaction
                                        $description = "Account Upgarde to ".$categoryQuery[0]->name;
                                        $transaction->save($query[0]->username, $query[0]->email, $this->service, "System", $description, $query[0]->phone_number, $categoryQuery[0]->price, "Debit", $query[0]->wallet, $balance, $app->reference(), $categoryQuery[0]->name, "null", $categoryQuery[0]->id, "null", "null", "null", 'success', $app->date);
                                    }
                                    User::where(['username' => $username])->update(['category' => $category]);
                                }
                            } else {
                                array_push($invalid_username, $username);
                            }
                }

                  }

                  if (count($usernames) > 1) {
                    return response()->json(["code" => 200, "type" => "success", "message" => "Action successfully processed, ".count($invalid_username)." invalid username ignored "]);
                  } else {
                    return response()->json(["code" => 200, "type" => "success", "message" => "Action successfully processed"]);
                  }

                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Category does not exist"]);
                }
        }
    }
}





}
