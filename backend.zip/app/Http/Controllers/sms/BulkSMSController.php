<?php

namespace App\Http\Controllers\sms;

use App\Http\Controllers\AppController;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class BulkSMSController extends Controller
{
    //

    // Transaction limit

    protected function index(Request $request) {
        if ($request->ajax()) {
            $validator = Validator::make($request->all(),[
                'charge'=>'required|numeric',
                'key' => 'required|max:200',
                'key_' => 'nullable|max:200',
                'status'=>'required',
             ]);

              if ($validator->fails())  {
                    $error = $validator->errors()->first();
                    return response()->json(["code" => 500, "type" => "error", "message" => $error]);
              } else {
                  $app = new AppController();
                  $charge = $app->sanitize($request->charge);
                  $key = $app->sanitize($request->key);
                  $key_ = $app->sanitize($request->key_);
                  $status = $app->sanitize($request->status);
                  $query = DB::table('bulk_sms')->get();
                  if ($query->count() == 0) {
                    $insert = DB::table('bulk_sms')->insert([
                        'charge' => $charge,
                        'key' => $key,
                        'key_' => $key_,
                        'status' => $status,
                    ]);
                      if ($insert) {
                        return response()->json(["code" => 200, "type" => "success", "message" => "Charge successfully saved"]);
                      } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "A critical error ocurred"]);
                      }

                  } else {

                    DB::table('bulk_sms')->update([
                        'charge' => $charge,
                        'key' => $key,
                        'key_' => $key_,
                        'status' => $status,
                    ]);
                        return response()->json(["code" => 200, "type" => "success", "message" => "Charge successfully added"]);
                }
              }

        } else {
            $query = DB::table('bulk_sms')->first();
            return view("sms.bulk-sms", ["charge" => $query]);
        }
    }






}
