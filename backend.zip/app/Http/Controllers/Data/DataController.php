<?php

namespace App\Http\Controllers\Data;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\AppController;
use App\Models\Data\Data;
use App\Models\Category\Category;
use App\Models\Network\Networks;
use App\Models\Data\DataList;
use App\Models\Data\DataCode;
use App\Models\Host\Host;

class DataController extends Controller
{
    //

    protected function index(Request $request) {
        if ($request->ajax()) {
            $query =  Data::orderBy('key', 'asc')->get();
        $table =  "<table id='table' class='table table-striped table-bordered' style='width:100%'>
        <thead>
            <tr>
            <th><div class='custom-control custom-switch'>
            <input class='form-check-input' id='allCheck' type='checkbox' value=''>
            </div></th>
                <th>S/N</th>
                <th>Network</th>
                <th>Plan</th>
                <th>Type</th>
                <th>Size</th>
                <th>Status</th>
                <th style='padding-right: 50px;'>Action</th>
            </tr>
        </thead>
        <tbody>";
        $init = 1;
        foreach ($query as $plan)  {
        $serialNumber = $init++;
        if ($plan->status == "available") {
            $checked = "checked";
        } else {
            $checked = "";
        }
         $table .=  "<tr>
                <td><div class='custom-control custom-switch'>
                <input class='form-check-input checkbox' type='checkbox' name='checkbox[]' data-id=". $plan->id ." value=''>
                </div>
                </td>
                <td>{$serialNumber}</td>
                <td>{$plan->network}</td>
                <td>{$plan->plan}</td>
                <td>{$plan->type}</td>
                <td>{$plan->size}</td>
                <td>
                <div class='custom-control custom-switch'>
                <input type='checkbox' class='custom-control-input toggleSwitch' data-id=". $plan->id ." id='customSwitches$serialNumber' $checked>
                <label class='custom-control-label' for='customSwitches$serialNumber'></label>
              </div>
                </td>
                <td>
                <button class='btn btn-success btn-sm' data-toggle='tooltip'  id='edit' data-id=". $plan->id ." style='background-color: #2dbe60; padding: 8px; margin-right: 8px'> <i class='fas fa-edit action_icon' style='font-size: 10px;'></i> </button>
                <button class='btn btn-danger btn-sm' data-toggle='tooltip' id='delete' data-id=". $plan->id ." style='padding: 8px'> <i class='fas fa-trash action_icon' style='font-size: 10px;'></i> </button>
            </td>
            </tr>";
        }

        $table .= "</tbody>
    </table>";

        return $table;

        } else {
            return view('data.data', ["networks" => Networks::select('name')->get()]);
        }
    }

/*******************************************************************************************************/

    private function dataList($id, $key, $network, $network_id, $type, $plan, $size, $status, $category) {
        $data = new DataList();
        $data->key = $key;
        $data->data_id = $id;
        $data->network = $network;
        $data->network_id = $network_id;
        $data->type = strtoupper($type);
        $data->plan = $plan;
        $data->size = $size;
        $data->category = $category;
        $data->amount = "";
        $data->status = $status;
        if ($data->save()) {
            return true;
        }
    }

/*******************************************************************************************************/

    private function dataCode($id, $key, $network, $network_id, $type, $plan, $size, $status, $host) {
        $data = new DataCode();
        $data->key = $key;
        $data->data_id = $id;
        $data->network = $network;
        $data->network_id = $network_id;
        $data->type = strtoupper($type);
        $data->plan = $plan;
        $data->size = $size;
        $data->code = "";
        $data->provider = $host;
        $data->status = $status;
        if ($data->save()) {
            return true;
        }
    }


/*******************************************************************************************************/

    protected function create(Request $request) {
        if ($request->ajax()) {
            $validator = Validator::make($request->all(),[
                'network'=>'required',
                'type' => 'required',
                'plan' => 'required',
                'size' => 'required',
                'status'=>'required',
             ]);

              if ($validator->fails())  {
                    $error = $validator->errors()->first();
                    return response()->json(["code" => 500, "type" => "error", "message" => $error]);
              } else {
                  $app = new AppController();
                  $network = $app->sanitize($request->network);
                  $type = $app->sanitize($request->type);
                  $plan = $app->sanitize($request->plan);
                  $size = $app->sanitize($request->size);
                  $status = $app->sanitize($request->status);
                  $query = Data::where(["network" => $network, "type" => $type, "plan" => $plan]);
                  $count = Data::all()->count();
                  $row = Networks::where('name', $network)->get();
                  if ($query->count() == 0) {
                      if ($row->count() == 1) {
                    $row = $row->first();
                    $network_id = $row->id;
                    $key = $count + 1;
                      $data = new Data();
                      $data->key = $key;
                      $data->network = $network;
                      $data->network_id = $network_id;
                      $data->type = strtoupper($type);
                      $data->plan = $plan;
                      $data->size = $size;
                      $data->status = $status;
                     if ($data->save()){
                        $query = Category::all();
                        foreach ($query as $category) {
                            $this->dataList($data->id, $key, $network, $network_id, $type, $plan, $size, $status, $category->name);
                        }
                        $query = Host::all();
                        foreach ($query as $host) {
                            $this->dataCode($data->id, $key, $network, $network_id, $type, $plan, $size, $status, $host->name);
                        }
                        return response()->json(["code" => 200, "type" => "success", "message" => "Plan successfully saved"]);
                     } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                     }

                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Invalid network"]);
                      }

                  } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "plan already exist"]);
                  }


              }
        }
    }

/*******************************************************************************************************/

protected function statusUpdate(Request $request) {
    if ($request->ajax()) {
        if (!empty($request)) {
            if (!empty($request->id) && !empty($request->status)) {
                $app = new AppController();
                $id = $app->sanitize($request->id);
                $status = $app->sanitize($request->status);
                $query = Data::where(['id' => $id])->get();
                if ($query->count() == 1) {
                    $query = Data::where(['id' => $id])->update(['status' => $status]);
                    DataCode::where(['data_id' => $id])->update(['status' => $status]);
                    DataList::where(['data_id' => $id])->update(['status' => $status]);
                if($query) {
                    return response()->json(["code" => 200, "status" => $status, "message" => "Status successfully set ".$status]);
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }

                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
            }
        }
    }
}


/*******************************************************************************************************/

protected function action(Request $request) {
    if ($request->ajax()) {
        if (!empty($request)) {
            if (!empty($request->arr) && !empty($request->action)) {
                foreach ($request->arr as $arr) {
                    if ($request->action == "delete") {
                     $query = Data::where(['id' => $arr])->delete();
                              DataCode::where(['data_id' => $arr])->delete();
                              DataList::where(['data_id' => $arr])->delete();
                    } else  {
                     $query = Data::where(['id' => $arr])->update(['status' => $request->action]);
                                DataCode::where(['data_id' => $arr])->update(['status' => $request->action]);
                                DataList::where(['data_id' => $arr])->update(['status' => $request->action]);
                    }
                }
                if($query) {
                    return response()->json(["code" => 200, "message" => "Action successfully processed"]);
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
            }
        }
    }
}



/*******************************************************************************************************/

protected function delete(Request $request) {
    if ($request->ajax()) {
        if (!empty($request)) {
            if (!empty($request->id)) {
                $id = $request->id;
                $query = Data::where(['id' => $id])->get();
                if ($query->count() == 1) {
                    $query = Data::where(['id' => $id])->delete();
                    DataCode::where(['data_id' => $id])->delete();
                    DataList::where(['data_id' => $id])->delete();
                if($query) {
                    return response()->json(["code" => 200, "message" => "Plan successfully deleted"]);
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }

                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
            }
        }
    }
}

/*******************************************************************************************************/

protected function edit(Request $request) {
    if ($request->ajax()) {
        if (!empty($request)) {
            if (!empty($request->id)) {
                $id = $request->id;
                $query = Data::where(['id' => $id])->get();
                if ($query->count() == 1) {
                    $query = $query->first();
                    return response()->json(["code" => 200, "data" => [
                        'id' => $query->id,
                        'network' => $query->network,
                        'size' => $query->size,
                        'plan' => $query->plan,
                        'type' => $query->type,
                        'status' => $query->status,
                    ]]);

                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
            }
        }
    }
}


private function updateQuery($id, $network, $network_id, $type, $size, $plan, $status) {
    Data::where(['id' => $id])->update(['network' => $network, 'network_id' => $network_id, 'type' => $type, 'size' => $size, 'plan' => $plan, 'status' => $status]);
    DataCode::where(['data_id' => $id])->update(['network' => $network, 'network_id' => $network_id, 'type' => $type, 'size' => $size, 'plan' => $plan, 'status' => $status]);
    DataList::where(['data_id' => $id])->update(['network' => $network, 'network_id' => $network_id, 'type' => $type, 'size' => $size, 'plan' => $plan, 'status' => $status]);
    return true;
}

/*******************************************************************************************************/

protected function update(Request $request) {
    if ($request->ajax()) {
        $validator = Validator::make($request->all(),[
            'id'=>'required',
            'network'=>'required',
            'type' => 'required',
            'plan' => 'required',
            'size' => 'required',
            'status'=>'required',
         ]);

          if ($validator->fails())  {
                $error = $validator->errors()->first();
                return response()->json(["code" => 500, "type" => "error", "message" => $error]);
          } else {
              $app = new AppController();
              $id = $app->sanitize($request->id);
              $network = $app->sanitize($request->network);
              $type = $app->sanitize($request->type);
              $plan = $app->sanitize($request->plan);
              $size = $app->sanitize($request->size);
              $status = $app->sanitize($request->status);
              $query = Data::where(["id" => $id]);
              $row = Networks::where('name', $network)->get();
              if ($query->count() == 1) {
                  if ($row->count() == 1) {
                $query = $query->first();
                if ($network !== $query->network || $type !== $query->type || $size !== $query->size || $plan !== $query->plan || $status !== $query->status) {

                 if ($network == $query->network && $type == $query->type && $plan == $query->plan) {
                    $query = $this->updateQuery($id, $network, $row[0]->id, $type, $size, $plan, $status);
                 if ($query){
                return response()->json(["code" => 200, "type" => "success", "message" => "Plan successfully updated"]);
             } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong!!"]);
             }

            } else {
                $query = Data::where(['network' => $network, 'type' => $type, 'plan' => $plan])->get();
                if ($query->count() == 0) {
                    $query = $this->updateQuery($id, $network, $row[0]->id, $type, $size, $plan, $status);
                     if ($query){
                        return response()->json(["code" => 200, "type" => "success", "message" => "Plan successfully updated"]);
                     } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong!!"]);
                     }
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Plan already exist"]);
                }

            }



                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "No change was made"]);
                  }

                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Invalid Network"]);
                  }

              } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong!!"]);
              }

          }
    }
}







}
