<?php

namespace App\Http\Controllers\Data;

use App\Http\Controllers\AppController;
use App\Http\Controllers\Controller;
use App\Models\Data\Data;
use App\Models\Data\DataCode;
use App\Models\Data\DataList;
use Illuminate\Http\Request;

class DataOrderingController extends Controller
{
    //

    public function index(Request $request) {
        $app = new AppController();
        if ($request->ajax()) {
            $list = Data::orderBy('key', 'asc')->get();
                if ($list->count() !== 0) {
                $table =  "<table id='table' class='table table-striped table-bordered' style='width:100%'>
                <thead>
                    <tr>
                        <th>S/N</th>
                        <th>Network</th>
                        <th>Plan</th>
                        <th>Type</th>
                        <th>Number</th>
                    </tr>
                </thead>
                <tbody>";
                $init = 1;
                foreach ($list as $plan)  {
                $serialNumber = $init++;
                $table .=  "<tr>
                        <td>{$serialNumber}</td>
                        <td>{$plan->network}</td>
                        <td>{$plan->plan}</td>
                        <td>{$plan->type}</td>
                        <td><input type='text' data-id='$plan->id' name='code[]' class='form-control form-white' value='$plan->key' style='width: 170px'/></td>

                    </tr>";
                }

            $table .= "</tbody>
        </table>
        <br/>
        <button type='button' class='btn btn-block btn-secondary waves-effect waves-light' id='proceed' style='padding-top: 10px;'> <span id='btn-spinner'></span> <span id='btn-txt'> Save <i class='fas fa-save'></i></span></button>";

            return $table;

                } else {
                    echo "<script> alert('Provider not found');</script>";
                }

        } else {
            return view("data.ordering");
        }

}






protected function update(Request $request) {
    if (!empty($request)) {
        if (!empty($request->key)) {
            foreach ($request->key as $key) {
                $id = $key["id"];
                if (empty($key["value"])){
                    $key = "";
                } else {
                    $key = $key["value"];
                }
                $query = Data::where(["id" => $id])->update(["key" => $key]);
                    DataCode::where(["data_id" => $id])->update(["key" => $key]);
                     DataList::where(["data_id" => $id])->update(["key" => $key]);
            }
            if($query) {
                return response()->json(["code" => 200, "message" => "Ordering successfully saved"]);
            }
        }
    }
}






}
