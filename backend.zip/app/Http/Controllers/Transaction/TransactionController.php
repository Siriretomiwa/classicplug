<?php

namespace App\Http\Controllers\Transaction;

use App\Http\Controllers\AppController;
use App\Http\Controllers\Controller;
use App\Models\Transaction\Transaction;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class TransactionController extends Controller
{
    //

    protected function index(Request $request) {
        if ($request->ajax()) {
        $entries = $request->entries;
        $search = $request->search;
        $filter = $request->filter;
        if ($filter == "All" || $filter == ""){
            $query =  Transaction::orderBy('id', 'desc')->where('description', 'like', '%'.$search.'%')
            ->orWhere('phone_number', 'like', '%'.$search.'%')
            ->orWhere('username', 'like', '%'.$search.'%')
            ->orWhere('email', 'like', '%'.$search.'%')
            ->orWhere('reference', 'like', '%'.$search.'%')->paginate($entries);
        } else if ($filter == "Debit" || $filter == "Credit") {
            $query =  Transaction::orderBy('id', 'desc')->where('type', $filter)->paginate($entries);
        } else if($filter == "success" || $filter == "pending" || $filter == "reversed" || $filter == "cancel" || $filter == "processing") {
            $query =  Transaction::orderBy('id', 'desc')->where('status', $filter)->paginate($entries);
        } else {
            $query =  Transaction::orderBy('id', 'desc')->where('service', $filter)->paginate($entries);
        }

        if ($query->count() > 0) {

        $table =  "<div class='row'>";
        $i = ($query->perPage() * ($query->currentPage() - 1)) + 1;
        foreach ($query as $transaction) {
        $serialNumber = $i++;

        $status = "null";
        switch($transaction->status) {
            case 'success': $status = "<span class='badge badge-success' id=badge-status-".$transaction->id.">". $transaction->status ."</spa>";
                break;
            case 'pending': $status = "<span class='badge badge-warning' id=badge-status-".$transaction->id.">". $transaction->status ."</spa>";
                break;
            case 'initiated': $status = "<span class='badge badge-warning' id=badge-status-".$transaction->id.">". $transaction->status ."</spa>";
                break;
            case 'cancel': $status = "<span class='badge badge-danger' id=badge-status-".$transaction->id.">". $transaction->status ."</spa>";
                break;
            case 'reversed': $status = "<span class='badge badge-danger' id=badge-status-".$transaction->id.">". $transaction->status ."</spa>";
                break;
                default: $status = "<span class='badge badge-warning' id=badge-status-".$transaction->id.">". $transaction->status ."</spa>";
        }


        // image
        $provider = $transaction->provider;
        $service = $transaction->service;
        if ($provider == "MTN") {
            $imgPath = "/images/mtn.png";
        } else if ($provider == "GLO") {
            $imgPath = "/images/glo.png";
        } else if ($provider == "AIRTEL") {
            $imgPath = "/images/airtel.png";
        } else if ($provider == "9MOBILE") {
            $imgPath = "/images/9mobile.png";
        } else if ($provider == "SMILE") {
            $imgPath = "/images/smile.png";
        } else if ($service == "Cable Subscription") {
            $imgPath = "/images/Multichoice.webp";
        } else if ($service == "Bills Payment") {
            $imgPath = "/images/electricity-power-line.jpg";
        } else if ($service == "Spectranet") {
            $imgPath = "/images/spectranet-device.png";
        } else if ($service == "Wallet Funding") {
            $imgPath = "/images/wallet-icon.png";
        } else if ($service == "Result Checker") {
            $imgPath = "/images/graduation-cap-congratulation.png";
        } else {
            $imgPath = "/images/shopping-cart.png";
        }


        $tranx_date = Carbon::parse($transaction->date);
         $table .=  "<div class='col-md-6 col-xl-4'>
         <div class='card-box tilebox-one' style='line-height: 25px;'>

         <div>

            <div class='border-top list_padding' style='justify-content: space-between; display: flex;
            border-top: 1px solid white !important; padding-top: 2px;'>
            <span style='font-family: Ibarra Real Nova, serif !important; font-size: 17px;'> ". $serialNumber ." </span>
             <h6 class='mt-0 mb-0' style='font-family: Ibarra Real Nova, serif !important; font-size: 17px; font-weight: 500'>". $transaction->service ."</h6>
             <h6 class='mt-0 mb-0' style='font-family: Ibarra Real Nova, serif !important; font-size: 17px;'>
                $status
             </h6>

             </div>


             <p class='mt-0 mb-0 border-top list_padding' style='background: #0000000d; box-shadow: rgb(149 157 165 / 7%) 0px 8px 24px;'>
                Username:<span id='username_txt_".$transaction->id ."'> ". $transaction->username ."</span></p>

             <div class='mt-0 mb-0' style='display: flex; justify-content: space-between; align-items: center;'>
             <span class='list_padding' style='border-right: 1px solid #e9ecef''> Amount: &#8358;". $transaction->amount ." </span>
             <span class='list_padding'> <img src='$imgPath' width='35' height='35' style='border-radius: 50%;'/> </span>
             <span class='list_padding' style='font-weight: 500; border-left: 1px solid #e9ecef'>".
                $tranx_date->diffForHumans() ." </span>
            </div>


             <div class='border-top list_padding' style='background: #0000000d; box-shadow: rgb(149 157 165 / 7%) 0px 8px 24px;'>
                Description: <span id='desc_txt_".$transaction->id ."' style='font-family: Roboto Slab, serif; word-break: break-all;'>". $transaction->description ." </span></div>

            <!-- Card hidden item list -->
             <div class='tranx_view' id='view-item-".$transaction->id."' hidden>
             <p class='mt-0 mb-0 border-top list_padding' style='word-break: break-all'>Email: ". $transaction->email ."</p>

             <div class='list_padding border-top' style='background: #0000000d; box-shadow: rgb(149 157 165 / 7%) 0px 8px 24px;'>
                Ref: ". $transaction->reference ."</div>

            <div class='mt-0 mb-0 border-top' style='display: flex; justify-content: space-between; align-items: center;'>
                <span class='list_padding' style='border-right: 1px solid #e9ecef'>IP: ". $transaction->ip ." </span>
                <span class='list_padding'>". $transaction->type ."</span>
                <span class='list_padding' style='border-left: 1px solid #e9ecef'> Route: ". $transaction->channel ." </span>
            </div>


            <div class='mt-0 mb-0 border-top' style='background: #0000000d; box-shadow: rgb(149 157 165 / 7%) 0px 8px 24px; display: flex; justify-content: space-between; align-items: center;'>
                <span class='list_padding' style='border-right: 1px solid #ffffffd9; word-break: break-all;'> Bal. Before/After </span>
                <span class='list_padding'>₦". round($transaction->balance_before, 2) ."</span>
                <span class='list_padding' style='border-left: 1px solid #ffffffd9'>₦". round($transaction->balance_after, 2) ." </span>
            </div>

            <div class='list_padding border-top' style='word-break: break-all;'>
            Origin: ". $transaction->origin ."</div>

             <div class='list_padding border-top' style='background: #0000000d; box-shadow: rgb(149 157 165 / 7%) 0px 8px 24px;'>Date/Time: ".
                $tranx_date->isoFormat('MMMM Do YYYY, h:mm:ss a')  ."</div>


             <div class='list_padding border-top' style='word-break: break-all;'>
                Remark: ". $transaction->remark ."</div>


                </div>

             <!-- Card action list -->
             <div class='mt-3 tranx_action' id='action-btn-div-".$transaction->id."' hidden>
                <button class='btn btn-sm text-white' id='action-status' data-status='success' data-id=". $transaction->id ." style='background-color: green; padding: 5px 7px; margin-right: 5px; font-size: 10px; font-weight: 700'>
                    <i class='fas fa-check-circle action_icon'></i> Approve
                </button>
                <button class='btn btn-sm text-white' id='action-status' data-status='reversed' data-id=". $transaction->id ." style='background-color: #3f51b5; padding: 5px 7px; margin-right: 5px; font-size: 10px; font-weight: 700'>
                <i class='fas fa-plus-circle action_icon'></i> Reverse
                </button>
                <button class='btn btn-sm text-white' id='action-status' data-status='cancel' data-id=". $transaction->id ." style='background-color: red; padding: 5px 7px; margin-right: 5px; font-size: 10px; font-weight: 700'>
                    <i class='fas fa-times-circle action_icon'></i> Cancel
                </button>

                <button class='btn btn-sm text-white' id='action-status' data-status='pending' data-id=". $transaction->id ." style='background-color: #ff9800; padding: 5px 7px; margin-right: 0px; font-size: 10px; font-weight: 700'>
                    <i class='fas fa-exclamation-triangle action_icon'></i> Pending
                </button>
            </div>
            <!-- Card action list end-->


            <!-- Card footer list -->
             <div class='mt-3' style='display: flex; justify-content: space-between;'>
                <span class='text-muted' id='viewMore' style='cursor: context-menu; font-weight: 500' data-id=". $transaction->id .">View</span>
                <span class='text-muted' id='edit' style='cursor: context-menu; font-weight: 500' data-id=". $transaction->id ."> Edit </span>
                <span class='text-muted' id='delete' style='cursor: context-menu; font-weight: 500' data-id=". $transaction->id ."> Delete </span>
                <span id='actions' class='text-muted' style='cursor: context-menu; font-weight: 500' data-id=". $transaction->id .">Actions</span>
                <div> <input class='form-check-input checkbox' type='checkbox' name='checkbox[]' data-id=". $transaction->id ." value=''> </div>
            </div>


            </div>
         </div>
     </div>";
        }

        $table .= "</div>
      <div class='card-box mt-3'>
    <div class='text-center'> Showing ". $query->firstItem() ." to ". $query->lastItem() ." of ". $query->total() ." entries</div>
    <div class='text-center mt-4 mb-2'>".
        // $query->links('pagination::bootstrap-4')
        $query->links('pagination::simple-tailwind')
    ."</div></div>";
        return $table;

    } else {
       $notFound = "<div class='card-box text-center'>
            <img src='/images/no-result-found.png' width='200px' />
       </div>";
       return $notFound;
    }

        } else {
             return view('transaction.transaction');
        }
    }



    protected function delete(Request $request) {
        if ($request->ajax()) {
            if (!empty($request)) {
                if (!empty($request->id)) {
                    $id = $request->id;
                    $query = DB::table('transactions')->where(['id' => $id])->get();
                    if ($query->count() == 1) {
                        $app = new AppController();
                        if ($app->admin()["role"] == "super-admin") {

                        $query =  DB::table('transactions')->where(['id' => $id])->delete();
                    if($query) {
                        return response()->json(["code" => 200, "message" => "Transaction successfully deleted"]);
                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                    }

                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Action revoked. you're not allowed to do this"]);
                    }

                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                    }
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            }
        }
    }



/*******************************************************************************************************/

protected function edit(Request $request) {
    if ($request->ajax()) {
        if (!empty($request)) {
            if (!empty($request->id)) {
                $id = $request->id;
                $query = DB::table('transactions')->where(['id' => $id])->get();
                if ($query->count() == 1) {
                    $query = $query->first();
                    return response()->json(["code" => 200, "data" => [
                        'id' => $query->id,
                        'email' => $query->email,
                        'username' => $query->username,
                        'service' => $query->service,
                        'provider' => $query->provider,
                        'description' => $query->description,
                        'reference' => $query->reference,
                        'channel' => $query->channel,
                        'type' => $query->type,
                        'amount' => $query->amount,
                        'status' => $query->status,
                    ]]);

                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
            }
        }
    }
}



    //  Transaction action
    protected function action(Request $request) {
        if ($request->ajax()) {
            $validator = Validator::make($request->all(),[
                'id'=>'required|int',
                'status'=>'nullable',
             ]);

              if ($validator->fails())  {
                    $error = $validator->errors()->first();
                    return response()->json(["code" => 500, "type" => "error", "message" => $error]);
              } else {
                  $app = new AppController();
                  $id = $app->sanitize($request->id);
                  $status = $app->sanitize($request->status);
                  $query = DB::table('transactions')->where('id', $id)->get();
                  if ($query->count() == 1) {
                    $balance_before = $query[0]->balance_before;
                    $balance_after = $query[0]->balance_after;
                    if ($status == "reversed") {
                        if ($balance_before !== $balance_after){
                            $user = DB::table('users')->where(['username' => $query[0]->username])->get();
                            if ($user->count() == 1) {
                                $service = $query[0]->service;
                                if ($service == "Airtime Topup") {
                                    $refund = (float) $query[0]->amount;
                                } else if ($service == "Recharge Pin") {
                                    $refund = (float) $query[0]->record;
                                } else if ($service == "Wallet Funding") {
                                    $refund = (float) $balance_after - (float) $balance_before;
                                } else {
                                    $refund = (float) $balance_before - (float) $balance_after;
                                }
                                $wallet = (float) $user[0]->wallet;
                                $balance = $service == "Wallet Funding" ? $wallet - $refund : $wallet + $refund;
                                DB::table('users')->where(["username" => $query[0]->username])->update([
                                    "wallet" => $balance
                                ]);
                            }
                            // Re-declare balance after
                            $balance_after = $balance_before;

                        } else {
                            // return response()->json(["code" => 500, "type" => "error", "message" => "Reversal declined"]);
                        }
                    }

                    // Auto approve airtime to cash
                 if ($query[0]->service == "Airtime To Cash" && $status == "success") {
                    if ($balance_before == $balance_after){
                        $user = DB::table('users')->where(['username' => $query[0]->username])->get();
                        if ($user->count() == 1) {
                            $fund = $query[0]->record;
                            $balance = floatval($user[0]->wallet) + floatval($fund);
                            DB::table('users')->where(["username" => $query[0]->username])->update([
                                "wallet" => $balance
                            ]);
                            // Re-declare balance after
                            $balance_after = $balance;
                        }
                    }
                 }

                $update_arr = $status == "reversed" ? [
                    "status" => $status,
                    "balance_after" => $balance_after
                    ] : [
                        'balance_after' => $balance_after,
                        'status' => $status,
                    ];

                    DB::table('transactions')->where('id', $id)->update($update_arr);

                    return response()->json([
                        "code" => 200,
                        "type" => "success",
                        "status" => $status,
                        "message" => ucfirst($query[0]->username) ." - ". $query[0]->description ." Transaction has been successfully updated to ".$status]);

                  } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Transaction ID not found"]);
                }
              }

        }
    }



    protected function update(Request $request) {
        if ($request->ajax()) {
            $validator = Validator::make($request->all(),[
                'id'=>'required|string',
                'type' => 'required|max:50|string',
                'reference' => 'required|max:200|string',
                'description' => 'required|max:200|string',
                'provider' => 'required|max:200|string',
                'amount'=>'required|numeric',
             ]);

              if ($validator->fails())  {
                    $error = $validator->errors()->first();
                    return response()->json(["code" => 500, "type" => "error", "message" => $error]);
              } else {
                  $app = new AppController();
                  $id = $app->sanitize($request->id);
                  $type = $app->sanitize($request->type);
                  $reference = $app->sanitize($request->reference);
                  $description = $app->sanitize($request->description);
                  $provider = $app->sanitize($request->provider);
                  $amount = $app->sanitize($request->amount);
                  $query = DB::table('transactions')->where(["id" => $id]);
                  if ($query->count() == 1) {
                    if ($app->admin()["role"] == "super-admin") {
                    $query = $query->first();
                    if ($type !== $query->type || $reference !== $query->reference || $description !== $query->description || $provider !== $query->provider || $amount !== $query->amount) {
                        $query =  DB::table('transactions')->where(['id' => $id])->update(['type' => $type, 'reference' => $reference, 'description' => $description, 'provider' => $provider, 'amount' => $amount]);
                        if ($query){
                            return response()->json(["code" => 200, "type" => "success", "message" => "Transaction successfully updated"]);
                            } else {
                                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong!!"]);
                            }

                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "No change was made"]);
                    }

                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Action revoked. you're not allowed to do this"]);
                    }

                  } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong!!"]);
                  }

              }
        }
    }





    protected function bulkAction(Request $request) {
        if ($request->ajax()) {
            if (!empty($request)) {
                if (!empty($request->arr) && !empty($request->action)) {
                    foreach ($request->arr as $arr) {
                        if ($request->action == "delete") {
                            $query = Transaction::where(['id' => $arr])->delete();
                        } else if ($request->action == "reversed") {
                            $query = Transaction::where('id', $arr)->get();
                            if ($query->count() == 1) {
                            $balance_before = $query[0]->balance_before;
                            $balance_after = $query[0]->balance_after;
                            if ($balance_before !== $balance_after && $balance_before > $balance_after){
                                $user = DB::table('users')->where(['username' => $query[0]->username])->get();
                                if ($user->count() == 1) {
                                    $refund = $balance_before - $balance_after;
                                    $balance = $user[0]->wallet + $refund;
                                    DB::table('users')->where(["username" => $query[0]->username])->update([
                                        "wallet" => $balance
                                    ]);
                                    $query = Transaction::where('id', $arr)->update([
                                            "status" => "reversed",
                                            "balance_after" => $balance_before
                                            ]);
                                }
                            }

                        }

                        } else  {
                            $query = Transaction::where(['id' => $arr])->update([
                                "status" => $request->action
                            ]);
                        }
                    }
                    if($query) {
                        return response()->json(["code" => 200, "message" => "Action successfully processed"]);
                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                    }
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            }
        }
    }






    // Transaction limit

    protected function limit(Request $request) {
        if ($request->ajax()) {
            $validator = Validator::make($request->all(),[
                'unverified'=>'required|int',
                'verified'=>'nullable',
             ]);

              if ($validator->fails())  {
                    $error = $validator->errors()->first();
                    return response()->json(["code" => 500, "type" => "error", "message" => $error]);
              } else {
                  $app = new AppController();
                  $unverified = $app->sanitize($request->unverified);
                  $verified = $app->sanitize($request->verified);
                  $query = DB::table('limit')->get();
                  if ($query->count() == 0) {
                    $insert = DB::table('limit')->insert([
                        'unverified' => $unverified,
                        'verified' => $verified,
                    ]);
                      if ($insert) {
                        return response()->json(["code" => 200, "type" => "success", "message" => "Limit successfully saved"]);
                      } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "A critical error ocurred"]);
                      }

                  } else {

                    DB::table('limit')->update([
                        'unverified' => $unverified,
                        'verified' => $verified,
                    ]);
                        return response()->json(["code" => 200, "type" => "success", "message" => "Limit successfully updated"]);
                }
              }

        } else {
            $query = DB::table('limit')->first();
            return view("transaction.limit", ["limits" => $query]);
        }
    }


    private function querySUM($query, $service, $provider) {
        return $query->where('provider', $provider)->where('service', $service)->sum('amount');
    }

    private function dataQuantity($query, $network) {
       $size = $query->where('service', 'Data Topup')->where('provider', $network)->sum('record');
       if($size > 999) {
		$plan_size =	$size/1000;
			if (is_float($plan_size)) {
				return floor($size / 1000).'GB '.fmod($size, 1000).'MB';
			} else {
				return floor($size / 1000).'GB';
			}

		} else {
		return $size.'MB';
		}
    }


    //  Transaction statistics
    protected function statistics(Request $request) {
        if ($request->ajax()) {
            $validator = Validator::make($request->all(),[
                'from_date' => 'required|date',
                'to_date' => 'required|date',
                'username'=>'nullable',
             ]);

              if ($validator->fails())  {
                    $error = $validator->errors()->first();
                    return response()->json(["code" => 500, "type" => "error", "message" => $error]);
              } else {
                  $app = new AppController();
                  $start_date = $app->sanitize($request->from_date);
                  $end_date = $app->sanitize($request->to_date);
                  $username = $app->sanitize($request->username);
                  $query = $start_date !== $end_date ? DB::table('transactions')->whereBetween('date', [$start_date, $end_date])->get()
                            : DB::table('transactions')->whereDate('date', '=', $start_date)->get();
                $query = $username !== "" ? $query->where('username', $username) : $query;
                            // return $query;

                  if ($query->count() > 0) {
                        return response()->json([
                            'code' => 200,
                            'status' => 'success',
                            'data' => [
                                'data' => [
                                    'mtn' => $this->querySUM($query, "Data Topup", "MTN"),
                                    'glo' => $this->querySUM($query, "Data Topup", "GLO"),
                                    'airtel' => $this->querySUM($query, "Data Topup", "AIRTEL"),
                                    '_9mobile' => $this->querySUM($query, "Data Topup", "9MOBILE"),
                                ],
                                "data_stat" => [
                                    'mtn' => $this->dataQuantity($query, "MTN"),
                                    'glo' => $this->dataQuantity($query, "GLO"),
                                    'airtel' => $this->dataQuantity($query, "AIRTEL"),
                                    '_9mobile' => $this->dataQuantity($query, "9MOBILE"),
                                ],
                                'airtime' => [
                                    'mtn' => $this->querySUM($query, "Airtime Topup", "MTN"),
                                    'glo' => $this->querySUM($query, "Airtime Topup", "GLO"),
                                    'airtel' => $this->querySUM($query, "Airtime Topup", "AIRTEL"),
                                    '_9mobile' => $this->querySUM($query, "Airtime Topup", "9MOBILE"),
                                ],
                                "cable" => [
                                    'gotv' => $this->querySUM($query, "Cable Subscription", "GOTV"),
                                    'dstv' => $this->querySUM($query, "Cable Subscription", "DSTV"),
                                    'startimes' => $this->querySUM($query, "Cable Subscription", "STARTIMES"),
                                ],
                                "bills" => [
                                    'ibedc' => $this->querySUM($query, "Bills Payment", "IBEDC"),
                                    'ikedc' => $this->querySUM($query, "Bills Payment", "IKEDC"),
                                    'ekedc' => $this->querySUM($query, "Bills Payment", "EKEDC"),
                                    'eedc' => $this->querySUM($query, "Bills Payment", "EEDC"),
                                    'kaedc' => $this->querySUM($query, "Bills Payment", "KAEDC"),
                                    'phedc' => $this->querySUM($query, "Bills Payment", "PHEDC"),
                                    'kedc' => $this->querySUM($query, "Bills Payment", "KEDC"),
                                    'jedc' => $this->querySUM($query, "Bills Payment", "JEDC"),
                                ]
                            ]
                                ]);

                  } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "No result found"]);
                }
              }

        } else {
            return view("transaction.statistics");
        }
    }




    public function save($username, $email, $service, $network, $description, $phone_number, $amount, $type, $wallet, $balance, $reference, $record, $response, $product_id, $request_id, $remark, $host, $status, $date) {
        $history = new Transaction();
        $history->username = $username;
        $history->email = $email;
        $history->service = $service;
        $history->provider = $network;
        $history->description = $description;
        $history->phone_number = $phone_number;
        $history->amount = $amount;
        $history->type = $type;
        $history->balance_before = $wallet;
        $history->balance_after = $balance;
        $history->reference = $reference;
        $history->record = $record;
        $history->remark = $remark;
        $history->response = $response;
        $history->product_id = $product_id;
        $history->request_id = $request_id;
        $history->ip = request()->ip();
        $history->channel = 'web';
        $history->origin = request()->headers->get('origin');
        $history->host = $host;
        $history->status = $status;
        $history->date = $date;
        if ($history->save()) {
            return $history;
        } else {
            return false;
        }

    }



    protected function log(Request $request) {
        if ($request->ajax()) {
            $validator = Validator::make($request->all(),[
                'reference'=>'required',
             ]);

              if ($validator->fails())  {
                    $error = $validator->errors()->first();
                    return response()->json(["code" => 500, "type" => "error", "message" => $error]);
              } else {
                  $app = new AppController();
                  $reference = $app->sanitize($request->reference);
                  $query = DB::table('transactions')->where('reference', $reference)->get();
                  if ($query->count() == 1) {
                    return response()->json(["code" => 200, "type" => "success", "message" => "Log fetched", "log" => $query[0]->response]);
                  } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Transaction not found"]);
                }
              }

        } else {
            return view("transaction.log");
        }
    }






}
