<?php

namespace App\Http\Controllers\Recharge;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\Network\Networks;
use App\Models\Recharge\RechargePin;
use App\Http\Controllers\AppController;
use App\Models\Recharge\Range;
use Illuminate\Support\Facades\Validator;

class RechargePinController extends Controller
{
    //


    protected function index(Request $request) {
        if ($request->ajax()) {
            $query =  RechargePin::orderBy('status')->paginate(100);
        if ($query->count() > 0) {
        $table =  "<table id='table' class='table table-striped table-bordered' style='width:100%'>
        <thead>
            <tr>
            <th><div class='custom-control custom-switch'>
            <input class='form-check-input' id='allCheck' type='checkbox' value=''>
            </div></th>
                <th>S/N</th>
                <th>Network</th>
                <th>Range</th>
                <th>Pin</th>
                <th>Status</th>
                <th style='padding-right: 50px;'>Action</th>
            </tr>
        </thead>
        <tbody>";
        $i = ($query->perPage() * ($query->currentPage() - 1)) + 1;
        foreach ($query as $recharge)  {
        $serialNumber = $i++;
        if ($recharge->status == "available") {
            $checked = "checked";
        } else {
            $checked = "";
        }
         $table .=  "<tr>
         <td><div class='custom-control custom-switch'>
         <input class='form-check-input checkbox' type='checkbox' name='checkbox[]' data-id=". $recharge->id ." value=''>
         </div>
         </td>
                <td>{$serialNumber}</td>
                <td>{$recharge->network}</td>
                <td>{$recharge->range}</td>
                <td>{$recharge->pin}</td>
                <td>

                <div class='custom-control custom-switch'>
                <input type='checkbox' class='custom-control-input toggleSwitch' data-id=". $recharge->id ." id='customSwitches$serialNumber' $checked>
                <label class='custom-control-label' for='customSwitches$serialNumber'></label>
              </div>

                </td>
                <td>
                <button class='btn btn-success btn-sm' data-toggle='tooltip'  id='edit' data-id=". $recharge->id ." style='background-color: #2dbe60; padding: 8px; margin-right: 8px'> <i class='fas fa-edit action_icon' style='font-size: 10px;'></i> </button>
                <button class='btn btn-danger btn-sm' data-toggle='tooltip' id='delete' data-id=". $recharge->id ." style='padding: 8px'> <i class='fas fa-trash action_icon' style='font-size: 10px;'></i> </button>
            </td>
            </tr>";
        }


        $table .= "</tbody>
            </table>
        </div>
        <div class='mt-3'>
      <div class='text-center'> Showing ". $query->firstItem() ." to ". $query->lastItem() ." of ". $query->total() ." entries</div>
      <div class='text-center mt-4 mb-2'>".
          // $query->links('pagination::bootstrap-4')
          $query->links('pagination::simple-tailwind')
      ."</div></div>";
          return $table;

      } else {
         $notFound = "<div class='text-center'>
              <img src='/images/no-result-found.png' width='200px' />
         </div>";
         return $notFound;
      }



        } else {
            $stat = [];
            $networks = Networks::all();
            if ($networks->count() > 0) {
                foreach($networks as $network) {
                    $available = $this->countPIN($network->name, 'available');
                    $unavailable = $this->countPIN($network->name, 'unavailable');
                    $arr = [
                            "network" => $network->name,
                            "available" => $available,
                            "unavailable" => $unavailable,
                    ];
                    array_push($stat, $arr);
                }
            }

            return view('recharge.pin',['networks' => Networks::all(), 'range' => Range::all(), 'stat' => $stat]);
        }
    }


    private function countPIN($network, $status) {
        $count = RechargePin::where(['network' => $network, 'status' => $status])->count();
        return $count;
    }


/*******************************************************************************************************/


protected function statusUpdate(Request $request) {
    if ($request->ajax()) {
        if (!empty($request)) {
            if (!empty($request->id) && !empty($request->status)) {
                $app = new AppController();
                $id = $app->sanitize($request->id);
                $status = $app->sanitize($request->status);
                $query = RechargePin::where(['id' => $id])->get();
                if ($query->count() == 1) {
                    $query = RechargePin::where(['id' => $id])->update(['status' => $status]);
                if($query) {
                    return response()->json(["code" => 200, "status" => $status, "message" => "Status successfully set ".$status]);
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }

                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
            }
        }
    }
}



/*******************************************************************************************************/



    protected function create(Request $request) {
        if ($request->ajax()) {
            $validator = Validator::make($request->all(),[
                'network'=>'required',
                'pin' => 'required',
                'range' => 'required',
                'serialNumber' => 'required',
                'status'=>'required',
             ]);

              if ($validator->fails())  {
                    $error = $validator->errors()->first();
                    return response()->json(["code" => 500, "type" => "error", "message" => $error]);
              } else {
                  $app = new AppController();
                  $network = $app->sanitize($request->network);
                  $range = $app->sanitize($request->range);
                  $pin = $app->sanitize($request->pin);
                  $serialNumber = $app->sanitize($request->serialNumber);
                  $status = $app->sanitize($request->status);
                  $query = Range::where(["network" => $network, 'range' => $range])->get();
                  $row = Networks::where('name', $network)->get();
                  if ($row->count() == 1) {
                  if ($query->count() == 1) {
                  $query = RechargePin::where(["network" => $network, 'range' => $range, "pin" => $pin]);
                  $count = RechargePin::all()->count();
                  if ($query->count() == 0) {
                      $pins = explode(',', $pin);
                      foreach ($pins as $pin) {
                        if ($pin !== "") {
                            $pin_ref = strtoupper(uniqid().'.'.rand(1, 100000).'-'.rand(1,100));
                            $key = $count + 1;
                            $recharge = new RechargePin();
                            $recharge->key = $key;
                            $recharge->network = $network;
                            $recharge->network_id = $row[0]->id;
                            $recharge->serial_number = $serialNumber;
                            $recharge->range = $range;
                            $recharge->pin = $pin;
                            $recharge->pin_ref = $pin_ref;
                            $recharge->user = "";
                            $recharge->ussd = "";
                            $recharge->name = "";
                            $recharge->ref = "";
                            $recharge->status = $status;
                            $recharge->save();
                        }
                      }
                     if ($recharge){
                        return response()->json(["code" => 200, "type" => "success", "message" => "PIN successfully saved"]);
                     } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "A critical error occured"]);
                     }


                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Pin already exist"]);
                      }


                  } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Invalid network | range"]);
                  }

                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Invalid network"]);
                  }

              }
        }
    }



/*******************************************************************************************************/

    protected function delete(Request $request) {
        if ($request->ajax()) {
            if (!empty($request)) {
                if (!empty($request->id)) {
                    $id = $request->id;
                    $query = RechargePin::where(['id' => $id])->get();
                    if ($query->count() == 1) {
                        $query = RechargePin::where(['id' => $id])->delete();
                    if($query) {
                        return response()->json(["code" => 200, "message" => "Recharge pin successfully deleted"]);
                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                    }

                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                    }
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            }
        }
    }



/*******************************************************************************************************/

protected function action(Request $request) {
    if ($request->ajax()) {
        if (!empty($request)) {
            if (!empty($request->arr) && !empty($request->action)) {
                foreach ($request->arr as $arr) {
                    if ($request->action == "delete") {
                     $query = RechargePin::where(['id' => $arr])->delete();
                    } else  {
                     $query = RechargePin::where(['id' => $arr])->update(['status' => $request->action]);
                    }
                }
                if($query) {
                    return response()->json(["code" => 200, "message" => "Action successfully processed"]);
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
            }
        }
    }
}

/*******************************************************************************************************/

protected function edit(Request $request) {
    if ($request->ajax()) {
        if (!empty($request)) {
            if (!empty($request->id)) {
                $id = $request->id;
                $query = RechargePin::where(['id' => $id])->get();
                if ($query->count() == 1) {
                    $query = $query->first();
                    return response()->json(["code" => 200, "data" => [
                        'id' => $query->id,
                        'network' => $query->network,
                        'pin' => $query->pin,
                        'range' => $query->range,
                        'serialNumber' => $query->serial_number,
                        'status' => $query->status,
                    ]]);
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
            }
        }
    }
}




protected function update(Request $request) {
    if ($request->ajax()) {
        $validator = Validator::make($request->all(),[
            'id'=>'required',
            'network'=>'required',
            'range'=>'required',
            'serialNumber'=>'required',
            'pin'=>'required',
            'status'=>'required',
         ]);

          if ($validator->fails())  {
                $error = $validator->errors()->first();
                return response()->json(["code" => 500, "type" => "error", "message" => $error]);
          } else {
              $app = new AppController();
              $id = $app->sanitize($request->id);
              $network = $app->sanitize($request->network);
              $range = $app->sanitize($request->range);
              $pin = $app->sanitize($request->pin);
              $serialNumber = $app->sanitize($request->serialNumber);
              $status = $app->sanitize($request->status);
              $query = RechargePin::where(["id" => $id]);
              $row = Networks::where(["name" => $network,])->get();
              $rangeCheck = Range::where(["network" => $network, 'range' => $range])->get();
              if ($query->count() == 1) {
                  if ($row->count() == 1) {
                    if ($rangeCheck->count() == 1) {
                $query = $query->first();
                if ($network !== $query->network || $pin !== $query->pin || $range !== $query->range || $serialNumber !== $query->serial_number || $status !== $query->status) {
                    $query = RechargePin::where(['id' => $id])->update(['pin' => $pin, 'network' => $network, 'network_id' => $row[0]->id, 'serial_number' => $serialNumber, 'status' => $status]);
                 if ($query) {
                    return response()->json(["code" => 200, "type" => "success", "message" => "Recharge pin successfully updated"]);
                 } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong!!"]);
                 }

                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "No change was made"]);
                  }

                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Invalid price range"]);
                  }

                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Invalid Network"]);
                  }

              } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong!!"]);
              }

          }
    }
}













}
