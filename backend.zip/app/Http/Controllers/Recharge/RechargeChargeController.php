<?php

namespace App\Http\Controllers\Recharge;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\Category\Category;
use App\Models\Recharge\Charge;
use App\Http\Controllers\AppController;
use Illuminate\Support\Facades\Validator;

class RechargeChargeController extends Controller
{
    //

    public function index(Request $request) {
        $app = new AppController();
        $category = $app->sanitize($request->category);
        if ($request->ajax()) {
            if (!empty($category)) {
            $list = Charge::where(["category" => $category])->get();
                if ($list->count() !== 0) {
                $table =  "<table id='table' class='table table-striped table-bordered' style='width:100%'>
                <thead>
                    <tr>
                        <th>S/N</th>
                        <th>Network</th>
                        <th>Charge (&#8358;|%)</th>
                        <th  style='padding-right:130px'>Charge Type</th>
                    </tr>
                </thead>
                <tbody>";
                $init = 1;
                foreach ($list as $charge)  {
                $serialNumber = $init++;
                $table .=  "<tr>
                        <td>{$serialNumber}</td>
                        <td>{$charge->network}</td>
                        <td><input type='number' data-id='$charge->id' name='charge[]' class='form-control form-white' value='$charge->charge' style='width: 120px'/></td>
                        <td>
                        <select name='charge_type[]' data-id='$charge->id' class='form-control form-white'>
                        <option value='discount'>Discount(%)</option>
                        <option value='fee'>Convinient Fee(&#8358;)</option>
                        </select>
                        </td>
                    </tr>";
                }

            $table .= "</tbody>
        </table>
        <br/>
        <button type='button' class='btn btn-block btn-secondary waves-effect waves-light' id='proceed' style='padding-top: 10px;'> <span id='btn-spinner'></span> <span id='btn-txt'> Save <i class='fas fa-save'></i></span></button>";

            return $table;

                } else {
                    echo "<script> alert('No result found for this category');</script>";
                }
            } else {
                echo "<script> alert('No result found for this category');</script>";
            }
        } else {
            return view("recharge.charge", ['categories' => Category::all()]);
        }

}




protected function update(Request $request) {
    if (!empty($request)) {
        if (!empty($request->charge)) {
            foreach ($request->charge as $charge) {
                $id = $charge["id"];
                if (empty($charge["value"])){
                    $charge = "";
                } else {
                    $charge = $charge["value"];
                }
                if (is_numeric($charge) || $charge == '') {
                    Charge::where(["id" => $id])->update(["charge" => $charge]);
                }
            }


            foreach ($request->charge_type as $charge_type) {
                $id = $charge_type["id"];
                if (empty($charge_type["value"])){
                    $charge_type = "";
                } else {
                    $charge_type = $charge_type["value"];
                }
               Charge::where(["id" => $id])->update(["charge_type" => $charge_type]);
            }

                return response()->json(["code" => 200, "message" => "Charge successfully saved"]);
        }
    }
}






protected function merge(Request $request) {
    if ($request->ajax()) {
        $validator = Validator::make($request->all(),[
            'category_1'=>'required',
            'category_2' => 'required',
         ]);
          if ($validator->fails())  {
                $error = $validator->errors()->first();
                return response()->json(["code" => 500, "type" => "error", "message" => $error]);
          } else {
            $app = new AppController();
            $category_1 = $app->sanitize($request->category_1);
            $category_2 = $app->sanitize($request->category_2);
            if ($app->getCategory($category_1)->count() == 1 && $app->getCategory($category_1)->count() == 1) {
                $query = Charge::where('category', $category_1)->get();
                foreach ($query as $row) {
                    Charge::where(['network_id' => $row->network_id, 'category' => $category_2])->update([
                        'charge' => $row->charge,
                        'charge_type' => $row->charge_type,
                    ]);
                }
                return response()->json(["code" => 200, "type" => "success", "message" => "Merging successfully done"]);
            } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "An invalid host received"]);
            }
          }
    }
}






}
