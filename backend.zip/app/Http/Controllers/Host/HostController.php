<?php

namespace App\Http\Controllers\Host;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\AppController;
use App\Models\Host\Host;
// Data
use App\Models\Data\Data;
use App\Models\Data\DataCode;
// Airtime
use App\Models\Airtime\Airtime;
use App\Models\Airtime\AirtimeCode;
// Bills
use App\Models\Bills\Bills;
use App\Models\Bills\BillsCode;
// Cable
use App\Models\Cable\CablePlan;
use App\Models\Cable\CableCode;
// Smile Bundle
use App\Models\Smile\Bundle;
use App\Models\Smile\BundleCode;




class HostController extends Controller
{
    //


    protected function index(Request $request) {
        if ($request->ajax()) {
            $query =  Host::all();
        $table =  "<table id='table' class='table table-striped table-bordered' style='width:100%'>
        <thead>
            <tr>
                <th>S/N</th>
                <th>Host</th>
                <th>Key 1</th>
                <th>Key 2</th>
                <th style='padding-right: 50px;'>Action</th>
            </tr>
        </thead>
        <tbody>";
        $init = 1;
        foreach ($query as $host)  {
        $serialNumber = $init++;
         $table .=  "<tr>
                <td>{$serialNumber}</td>
                <td>{$host->name}</td>
                <td>{$host->key}</td>";
                if($host->key_ == "") {
                    $table .= "<td>null</td>";
                } else {
                    $table .= "<td>{$host->key_}</td>";
                }
                $table .= "<td>
                <button class='btn btn-success btn-sm' data-toggle='tooltip'  id='edit' data-id=". $host->id ." style='background-color: #2dbe60; padding: 8px; margin-right: 8px'> <i class='fas fa-edit action_icon' style='font-size: 10px;'></i> </button>
                <button class='btn btn-danger btn-sm' data-toggle='tooltip' id='delete' data-id=". $host->id ." style='padding: 8px'> <i class='fas fa-trash action_icon' style='font-size: 10px;'></i> </button>
                </td>
            </tr>";
        }

        $table .= "</tbody>
    </table>";

        return $table;


        } else {
            return view('host.host');
        }
    }




    protected function create(Request $request) {
        if ($request->ajax()) {
            $validator = Validator::make($request->all(),[
                'name' => 'required',
                'parameter_1' => 'required',
             ]);

              if ($validator->fails())  {
                    $error = $validator->errors()->first();
                    return response()->json(["code" => 500, "type" => "error", "message" => $error]);
              } else {
                  $app = new AppController();
                  $name = $app->sanitize($request->name);
                  $parameter_1 = $app->sanitize($request->parameter_1);
                  $parameter_2 = $app->sanitize($request->parameter_2);
                  $query = Host::where(["name" => $name]);
                  $name = strtoupper($name);
                  if ($query->count() == 0) {
                      $host = new Host();
                      $host->name = $name;
                      $host->key = $parameter_1;
                      $host->key_ = $parameter_2;
                     if ($host->save()){
                        $this->data($name);
                        $this->airtime($name);
                        $this->bills($name);
                        $this->cable($name);
                        $this->smileBundle($name);
                        return response()->json(["code" => 200, "type" => "success", "message" => "$name successfully added"]);
                     } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "A critical error occured"]);
                     }


                  } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "$name already exist"]);
                  }



              }
        }
    }



/*-------------------------------------------------------------------------------*/

private function data($name) {
    $plans =  Data::all();
    foreach($plans as $plan) {
        $data = new DataCode();
        $data->key = $plan->key;
        $data->data_id = $plan->id;
        $data->network = $plan->network;
        $data->network_id = $plan->network_id;
        $data->type = strtoupper($plan->type);
        $data->plan = $plan->plan;
        $data->size = $plan->size;
        $data->code = "";
        $data->provider = $name;
        $data->status = $plan->status;
        $data->save();
    }
    return true;
}




private function airtime($name) {
    $airtimes =  Airtime::all();
    foreach($airtimes as $airtime) {
        $airtimeCode= new AirtimeCode();
        $airtimeCode->key = $airtime->key;
        $airtimeCode->airtime_id = $airtime->id;
        $airtimeCode->network = $airtime->network;
        $airtimeCode->network_id = $airtime->network_id;
        $airtimeCode->type = strtoupper($airtime->type);
        $airtimeCode->provider = $name;
        $airtimeCode->code = "";
        $airtimeCode->status = $airtime->status;
        $airtimeCode->save();
    }
    return true;
}



private function bills($name) {
    $electricity =  Bills::all();
    foreach($electricity as $disco) {
        $bills = new BillsCode();
        $bills->key = $disco->key;
        $bills->bills_id = $disco->id;
        $bills->name = $disco->name;
        $bills->disco = $disco->disco;
        $bills->provider = $name;
        $bills->code = "";
        $bills->status = $disco->status;
        $bills->save();
    }
    return true;
}




private function cable($name) {
    $plans =  CablePlan::all();
    foreach($plans as $plan) {
        $cable = new CableCode();
        $cable->key = $plan->key;
        $cable->plan_id = $plan->id;
        $cable->cable = $plan->cable;
        $cable->cable_id = $plan->cable_id;
        $cable->plan = $plan->plan;
        $cable->code = "";
        $cable->provider = $name;
        $cable->status = $plan->status;
        $cable->save();
    }
    return true;
}





private function smileBundle($name) {
    $smileBundle =  Bundle::all();
    foreach($smileBundle as $smile) {
        $data = new BundleCode();
        $data->key = $smile->key;
        $data->bundle_id = $smile->id;
        $data->plan = $smile->plan;
        $data->code = "";
        $data->provider = $name;
        $data->status = $smile->status;
        $data->save();
    }
    return true;
}









protected function delete(Request $request) {
    if ($request->ajax()) {
        if (!empty($request)) {
            if (!empty($request->id)) {
                $id = $request->id;
                $query_ = Host::where(['id' => $id])->get();
                if ($query_->count() == 1) {
                    $name = $query_[0]->name;
                    $query = Host::where(['id' => $id])->delete();
                if($query) {
                    $this->deleteData($name);
                    $this->deleteAirtime($name);
                    $this->deleteBills($name);
                    $this->deleteCable($name);
                    $this->deleteSmileBundle($name);
                    return response()->json(["code" => 200, "message" => "Host successfully deleted"]);
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }

                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
            }
        }
    }
}







/*----------------------Delete---------------------------------------------------------*/

private function deleteData($name) {
    $query =  DataCode::where(['provider' => $name])->delete();
    if ($query) {
        return true;
    }
}


private function deleteAirtime($name) {
    $query =  AirtimeCode::where(['provider' => $name])->delete();
    if ($query) {
        return true;
    }
}


private function deleteBills($name) {
    $query =  BillsCode::where(['provider' => $name])->delete();
    if ($query) {
        return true;
    }
}


private function deleteCable($name) {
    $query =  CableCode::where(['provider' => $name])->delete();
    if ($query) {
        return true;
    }
}



private function deleteSmileBundle($name) {
    $query =  BundleCode::where(['provider' => $name])->delete();
    if ($query) {
        return true;
    }
}


/*******************************************************************************************************/

protected function edit(Request $request) {
    if ($request->ajax()) {
        if (!empty($request)) {
            if (!empty($request->id)) {
                $id = $request->id;
                $query = Host::where(['id' => $id])->get();
                if ($query->count() == 1) {
                    $query = $query->first();
                    return response()->json(["code" => 200, "data" => [
                        'id' => $query->id,
                        'name' => $query->name,
                        'key' => $query->key,
                        'key_' => $query->key_,
                    ]]);

                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
            }
        }
    }
}







private function updateQuery($id, $name, $parameter_1, $parameter_2) {
    $query = Host::where(['id' => $id])->update(['name' => $name, 'key' => $parameter_1, 'key_' => $parameter_2]);
    if ($query) {
         return true;
    }
 }


 protected function update(Request $request) {
     if ($request->ajax()) {
         $validator = Validator::make($request->all(),[
             'id'=>'required',
             'name' => 'required',
             'parameter_1' => 'required',
          ]);

           if ($validator->fails())  {
                 $error = $validator->errors()->first();
                 return response()->json(["code" => 500, "type" => "error", "message" => $error]);
           } else {
               $app = new AppController();
               $id = $app->sanitize($request->id);
               $name = $app->sanitize($request->name);
               $parameter_1 = $app->sanitize($request->parameter_1);
               $parameter_2 = $app->sanitize($request->parameter_2);
               $query = Host::where(["id" => $id]);
               $name = strtoupper($name);
               if ($query->count() == 1) {
                 $query = $query->first();
                 if ($name !== $query->name || $parameter_1 !== $query->parameter_1 || $parameter_2 !== $query->parameter_2) {
                    $old_host = $query->name;
                    if ($name !== $query->name) {
                         $query_ = Host::where(["name" => $name])->get();
                         if ($query_->count() == 0) {
                             $query = $this->updateQuery($id, $name, $parameter_1, $parameter_2);
                             if ($query){
                                 $this->updateData($name, $old_host);
                                 $this->updateAirtime($name, $old_host);
                                 $this->updateBills($name, $old_host);
                                 $this->updateCable($name, $old_host);
                                 $this->updateSmileBundle($name, $old_host);
                                  return response()->json(["code" => 200, "type" => "success", "message" => "Host successfully updated"]);
                              } else {
                                  return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong!!"]);
                              }
                         } else {
                             return response()->json(["code" => 500, "type" => "error", "message" => "Host already exist"]);
                         }

                             } else {
                                $query = $this->updateQuery($id, $name, $parameter_1, $parameter_2);
                             if ($query){
                                     return response()->json(["code" => 200, "type" => "success", "message" => "Host successfully updated"]);
                                 } else {
                                     return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong!!"]);
                                 }
                             }

                     } else {
                         return response()->json(["code" => 500, "type" => "error", "message" => "No change was made"]);
                   }


               } else {
                 return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong!!"]);
               }

           }
     }
 }






/*----------------------Update---------------------------------------------------------*/

private function updateData($name, $old_host) {
    $query =  DataCode::where(['provider' => $old_host])->update(['provider' => $name]);
    if ($query) {
        return true;
    }
}


private function updateAirtime($name, $old_host) {
    $query =  AirtimeCode::where(['provider' => $old_host])->update(['provider' => $name]);
    if ($query) {
        return true;
    }
}


private function updateBills($name, $old_host) {
    $query =  BillsCode::where(['provider' => $old_host])->update(['provider' => $name]);
    if ($query) {
        return true;
    }
}


private function updateCable($name, $old_host) {
    $query =  CableCode::where(['provider' => $old_host])->update(['provider' => $name]);
    if ($query) {
        return true;
    }
}



private function updateSmileBundle($name, $old_host) {
    $query =  BundleCode::where(['provider' => $old_host])->update(['provider' => $name]);
    if ($query) {
        return true;
    }
}





}
