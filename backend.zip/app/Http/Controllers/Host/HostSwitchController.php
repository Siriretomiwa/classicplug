<?php

namespace App\Http\Controllers\Host;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

use App\Models\Host\Host;
use App\Models\Network\Networks;
use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\AppController;
use App\Models\Host\HostSwitch;

class HostSwitchController extends Controller
{
    //


    protected function index(Request $request) {
        if ($request->ajax()) {
            $query =  HostSwitch::all();
        $table =  "<table id='table' class='table table-striped table-bordered' style='width:100%'>
        <thead>
            <tr>
                <th>S/N</th>
                <th>Service</th>
                <th>Host</th>
                <th>Network</th>
                <th>Type</th>
                <th>Number</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody>";
        $init = 1;
        foreach ($query as $host)  {
        $serialNumber = $init++;
         $table .=  "<tr>
                <td>{$serialNumber}</td>
                <td>{$host->service}</td>
                <td>{$host->host}</td>";

                if($host->service == "DATA" || $host->service == "AIRTIME") {
                    $table .= "<td> $host->network </td>";
                } else {
                    $table .= "<td></td>";
                }

                if($host->service == "DATA" || $host->service == "AIRTIME") {
                    $table .= "<td> $host->type </td>";
                } else {
                    $table .= "<td></td>";
                }

                if($host->host == "SMS") {
                    $table .= "<td> $host->phone_number </td>";
                } else {
                    $table .= "<td></td>";
                }

                $table .= "<td><button class='btn btn-danger btn-sm' data-toggle='tooltip' id='delete' data-id=". $host->id ." style='padding: 8px'> <i class='fas fa-trash action_icon' style='font-size: 10px;'></i> </button></td>
                </tr>";
        }

        $table .= "</tbody>
    </table>";

        return $table;


        } else {
            return view('host.hostswitch', ['networks' => Networks::all(), 'hosts' => Host::all()]);
        }
    }




    private function insert($service, $host, $type, $network, $number) {
        $hostSwitch = new HostSwitch();
        $hostSwitch->service = $service;
        $hostSwitch->host = $host;
        $hostSwitch->type = $type;
        $hostSwitch->network = $network;
        $hostSwitch->phone_number = $number;
       if ($hostSwitch->save()){
           return true;
       }
    }

    private function update($identity, $service, $host, $type, $network, $number) {
        if ($identity == "data_airtime") {
            $query = HostSwitch::where(["service" => $service, 'type' => $type, 'network' => $network])->update(["service" => $service, "type" => $type, "network" => $network, "phone_number" => $number, 'host' => $host]);
        } else {
            $query = HostSwitch::where(["service" => $service])->update(["service" => $service, "type" => $type, "network" => $network, "phone_number" => $number, "host" => $host]);
        }
        if ($query) {
            return true;
        }
    }


    protected function save(Request $request) {
        if ($request->ajax()) {
            $validator = Validator::make($request->all(),[
                'service' => 'required',
                'host' => 'required',
             ]);

              if ($validator->fails())  {
                    $error = $validator->errors()->first();
                    return response()->json(["code" => 500, "type" => "error", "message" => $error]);
              } else {
                  $app = new AppController();
                  $service = $app->sanitize($request->service);
                  $host = $app->sanitize($request->host);
                  $type = $app->sanitize($request->type);
                  $network = $app->sanitize($request->network);
                  $number = $app->sanitize($request->phone_number);

                  if ($service == "DATA" || $service == "AIRTIME" && $network !== "" && $host !== "") {
                    $query = HostSwitch::where(["service" => $service, 'type' => $type, 'network' => $network]);
                    if ($query->count() == 0) {
                            $query = $this->insert($service, $host, $type, $network, $number);
                            if ($query) {
                                return response()->json(["code" => 200, "type" => "success", "message" => "Settings successfully saved"]);
                            } else {
                                return response()->json(["code" => 500, "type" => "error", "message" => "A critical error occured"]);
                            }
                    } else {
                      $updateQuery = $this->update("data_airtime", $service, $host, $type, $network, $number);
                      if ($query) {
                        return response()->json(["code" => 200, "type" => "success", "message" => "Settings successfully saved"]);
                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "A critical error occured"]);
                    }
                    }
                  } else if ($service == "CABLE" || $service == "ELECTRICITY" || $service == "SMILE" || $service == "SPECTRANET") {
                    $query = HostSwitch::where(["service" => $service]);
                    if ($query->count() == 0) {
                    $query = $this->insert($service, $host, $type, $network, $number);
                    if ($query) {
                        return response()->json(["code" => 200, "type" => "success", "message" => "Settings successfully saved"]);
                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "A critical error occured"]);
                     }
                  } else {
                    $updateQuery = $this->update("null", $service, $host, $type, $network, $number);
                    if ($query) {
                      return response()->json(["code" => 200, "type" => "success", "message" => "Settings successfully saved"]);
                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "A critical error occured"]);
                    }
                  }



              }
        }
    }
}



protected function delete(Request $request) {
    if ($request->ajax()) {
        if (!empty($request)) {
            if (!empty($request->id)) {
                $id = $request->id;
                $query = HostSwitch::where(['id' => $id])->get();
                if ($query->count() == 1) {
                    $query = HostSwitch::where(['id' => $id])->delete();
                if($query) {
                    return response()->json(["code" => 200, "message" => "Action successfully processed"]);
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }

                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
            }
        }
    }
}











}
