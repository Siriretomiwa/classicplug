<?php

namespace App\Http\Controllers\Coupon;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Http\Controllers\AppController;
use App\Models\Category\Category;
use App\Models\Coupon\Voucher;
use Illuminate\Support\Facades\Validator;

class VoucherController extends Controller
{
    //


    protected function index(Request $request) {
        if ($request->ajax()) {
            $query =  Voucher::all();
        $table =  "<table id='table' class='table table-striped table-bordered' style='width:100%'>
        <thead>
            <tr>
                <th><div class='custom-control custom-switch'>
                <input class='form-check-input' id='allCheck' type='checkbox' value=''>
                </div></th>
                <th>S/N</th>
                <th>Coupon</th>
                <th>Deduction</th>
                <th>Service</th>
                <th>Type</th>
                <th>Category</th>
                <th>Status</th>
                <th style='padding-right: 50px;'>Action</th>
            </tr>
        </thead>
        <tbody>";
        $init = 1;
        foreach ($query as $coupon)  {
        $serialNumber = $init++;
        if ($coupon->status == "available") {
            $checked = "checked";
        } else {
            $checked = "";
        }

        if ($coupon->type == "discount") {
            $deduction = $coupon->deduction."%";
        } else {
            $deduction = "&#8358;".$coupon->deduction;
        }

         $table .=  "<tr>
                <td><div class='custom-control custom-switch'>
                <input class='form-check-input checkbox' type='checkbox' name='checkbox[]' data-id=". $coupon->id ." value=''>
                </div>
                </td>
                <td>{$serialNumber}</td>
                <td>{$coupon->code}</td>
                <td>$deduction</td>
                <td>{$coupon->service}</td>
                <td>{$coupon->type}</td>
                <td>{$coupon->category}</td>
                <td>

                <div class='custom-control custom-switch'>
                <input type='checkbox' class='custom-control-input toggleSwitch' data-id=". $coupon->id ." id='customSwitches$serialNumber' $checked>
                <label class='custom-control-label' for='customSwitches$serialNumber'></label>
              </div>

                </td>
                <td>
                <button class='btn btn-success btn-sm' data-toggle='tooltip'  id='edit' data-id=". $coupon->id ." style='background-color: #2dbe60; padding: 8px; margin-right: 8px'> <i class='fas fa-edit action_icon' style='font-size: 10px;'></i> </button>
                <button class='btn btn-danger btn-sm' data-toggle='tooltip' id='delete' data-id=". $coupon->id ." style='padding: 8px'> <i class='fas fa-trash action_icon' style='font-size: 10px;'></i> </button>
            </td>
            </tr>";
        }

        $table .= "</tbody>
    </table>";

        return $table;


        } else {
            return view('coupon.voucher',  ['categories' => Category::all()]);
        }
    }


/*******************************************************************************************************/

    protected function create(Request $request) {
        if ($request->ajax()) {
            $validator = Validator::make($request->all(),[
                'voucher'=>'required',
                'type' => 'required',
                'deduction' => 'required',
                'category' => 'required',
                'service' => 'required',
                'days' => 'required',
                'status'=>'required',
             ]);
              if ($validator->fails())  {
                    $error = $validator->errors()->first();
                    return response()->json(["code" => 500, "type" => "error", "message" => $error]);
              } else {
                  $app = new AppController();
                  $voucher = $app->sanitize($request->voucher);
                  $type = $app->sanitize($request->type);
                  $deduction = $app->sanitize($request->deduction);
                  $category = $app->sanitize($request->category);
                  $service = $app->sanitize($request->service);
                  $days = $app->sanitize($request->days);
                  $status = $app->sanitize($request->status);
                  $query = Voucher::where(["type" => $type, "category" => $category, "service" => $service]);
                    if ($query->count() == 0) {
                        $funding = new Voucher();
                        $funding->code = $voucher;
                        $funding->type = $type;
                        $funding->deduction = $deduction;
                        $funding->category = $category;
                        $funding->service = $service;
                        $funding->days = $days;
                        $funding->status = $status;
                        if ($funding->save()){
                            return response()->json(["code" => 200, "type" => "success", "message" => "Voucher successfully created"]);
                        } else {
                            return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong!!"]);
                        }

                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Voucher already exist"]);
                    }

              }
        }
    }



/*******************************************************************************************************/

protected function statusUpdate(Request $request) {
    if ($request->ajax()) {
        if (!empty($request)) {
            if (!empty($request->id) && !empty($request->status)) {
                $app = new AppController();
                $id = $app->sanitize($request->id);
                $status = $app->sanitize($request->status);
                $query = Voucher::where(['id' => $id])->get();
                if ($query->count() == 1) {
                    $query = Voucher::where(['id' => $id])->update(['status' => $status]);
                if($query) {
                    return response()->json(["code" => 200, "status" => $status, "message" => "Status successfully set ".$status]);
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }

                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
            }
        }
    }
}



/*******************************************************************************************************/

protected function delete(Request $request) {
    if ($request->ajax()) {
        if (!empty($request)) {
            if (!empty($request->id)) {
                $id = $request->id;
                $query = Voucher::where(['id' => $id])->get();
                if ($query->count() == 1) {
                    $query = Voucher::where(['id' => $id])->delete();
                if($query) {
                    return response()->json(["code" => 200, "message" => " Voucher successfully deleted"]);
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }

                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
            }
        }
    }
}


/*******************************************************************************************************/


protected function action(Request $request) {
    if ($request->ajax()) {
        if (!empty($request)) {
            if (!empty($request->arr) && !empty($request->action)) {
                foreach ($request->arr as $arr) {
                    if ($request->action == "delete") {
                     $query = Voucher::where(['id' => $arr])->delete();
                    } else  {
                     $query = Voucher::where(['id' => $arr])->update(['status' => $request->action]);
                    }
                }
                if($query) {
                    return response()->json(["code" => 200, "message" => "Action successfully processed"]);
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
            }
        }
    }
}


/*******************************************************************************************************/

protected function edit(Request $request) {
    if ($request->ajax()) {
        if (!empty($request)) {
            if (!empty($request->id)) {
                $id = $request->id;
                $query = Voucher::where(['id' => $id])->get();
                if ($query->count() == 1) {
                    $query = $query->first();
                    return response()->json(["code" => 200, "data" => [
                        'id' => $query->id,
                        'code' => $query->code,
                        'type' => $query->type,
                        'service' => $query->service,
                        'deduction' => $query->deduction,
                        'category' => $query->category,
                        'days' => $query->days,
                        'status' => $query->status,
                    ]]);

                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
            }
        }
    }
}






protected function update(Request $request) {
    if ($request->ajax()) {
        $validator = Validator::make($request->all(),[
            'id'=>'required',
            'voucher'=>'required',
            'type' => 'required',
            'deduction' => 'required',
            'category' => 'required',
            'service' => 'required',
            'days' => 'required',
            'status'=>'required',
         ]);

          if ($validator->fails())  {
                $error = $validator->errors()->first();
                return response()->json(["code" => 500, "type" => "error", "message" => $error]);
          } else {
              $app = new AppController();
              $id = $app->sanitize($request->id);
              $voucher = $app->sanitize($request->voucher);
              $type = $app->sanitize($request->type);
              $deduction = $app->sanitize($request->deduction);
              $category = $app->sanitize($request->category);
              $service = $app->sanitize($request->service);
              $days = $app->sanitize($request->days);
              $status = $app->sanitize($request->status);
              $query = Voucher::where(["id" => $id]);
              if ($query->count() == 1) {
                $query = $query->first();
                if ($voucher !== $query->code || $type !== $query->type || $deduction !== $query->deduction || $category !== $query->category || $service !== $query->service || $days !== $query->days || $status !== $query->status) {
                    $query = Voucher::where(['id' => $id])->update(['code' => $voucher, 'type' => $type, 'deduction' => $deduction, 'category' => $category, 'service' => $service, 'days' => $days, 'status' => $status]);
                    if ($query){
                        return response()->json(["code" => 200, "type" => "success", "message" => "Voucher successfully updated"]);
                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong!!"]);
                }



                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "No change was made"]);
                  }

              } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong!!"]);
              }

          }
    }
}

/*******************************************************************************************************/











}
