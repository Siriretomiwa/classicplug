<?php

namespace App\Http\Controllers\Coupon;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Http\Controllers\AppController;
use App\Models\Coupon\Funding;
use Illuminate\Support\Facades\Validator;

class FundingController extends Controller
{
    //



    protected function index(Request $request) {
        if ($request->ajax()) {
            $query =  Funding::all();
        $table =  "<table id='table' class='table table-striped table-bordered' style='width:100%'>
        <thead>
            <tr>
                <th><div class='custom-control custom-switch'>
                <input class='form-check-input' id='allCheck' type='checkbox' value=''>
                </div></th>
                <th>S/N</th>
                <th>Coupon</th>
                <th>Amount</th>
                <th>Status</th>
                <th style='padding-right: 50px;'>Action</th>
            </tr>
        </thead>
        <tbody>";
        $init = 1;
        foreach ($query as $coupon)  {
        $serialNumber = $init++;
        if ($coupon->status == "available") {
            $checked = "checked";
        } else {
            $checked = "";
        }
         $table .=  "<tr>
                <td><div class='custom-control custom-switch'>
                <input class='form-check-input checkbox' type='checkbox' name='checkbox[]' data-id=". $coupon->id ." value=''>
                </div>
                </td>
                <td>{$serialNumber}</td>
                <td>{$coupon->code}</td>
                <td>{$coupon->amount}</td>
                <td>

                <div class='custom-control custom-switch'>
                <input type='checkbox' class='custom-control-input toggleSwitch' data-id=". $coupon->id ." id='customSwitches$serialNumber' $checked>
                <label class='custom-control-label' for='customSwitches$serialNumber'></label>
              </div>

                </td>
                <td>
                <button class='btn btn-success btn-sm' data-toggle='tooltip'  id='edit' data-id=". $coupon->id ." style='background-color: #2dbe60; padding: 8px; margin-right: 8px'> <i class='fas fa-edit action_icon' style='font-size: 10px;'></i> </button>
                <button class='btn btn-danger btn-sm' data-toggle='tooltip' id='delete' data-id=". $coupon->id ." style='padding: 8px'> <i class='fas fa-trash action_icon' style='font-size: 10px;'></i> </button>
            </td>
            </tr>";
        }

        $table .= "</tbody>
    </table>";

        return $table;


        } else {
            return view('coupon.funding');
        }
    }


/*******************************************************************************************************/

    protected function create(Request $request) {
        if ($request->ajax()) {
            $validator = Validator::make($request->all(),[
                'coupon'=>'required',
                'amount' => 'required',
                'status'=>'required',
             ]);
              if ($validator->fails())  {
                    $error = $validator->errors()->first();
                    return response()->json(["code" => 500, "type" => "error", "message" => $error]);
              } else {
                  $app = new AppController();
                  $coupon = $app->sanitize($request->coupon);
                  $amount = $app->sanitize($request->amount);
                  $status = $app->sanitize($request->status);
                  $query = Funding::where(["code" => $coupon]);
                    if ($query->count() == 0) {
                        $funding = new Funding();
                        $funding->code = $coupon;
                        $funding->amount = $amount;
                        $funding->status = $status;
                        if ($funding->save()){
                            return response()->json(["code" => 200, "type" => "success", "message" => "Coupon successfully created"]);
                        } else {
                            return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong!!"]);
                        }

                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Coupon already exist"]);
                    }

              }
        }
    }



/*******************************************************************************************************/

protected function statusUpdate(Request $request) {
    if ($request->ajax()) {
        if (!empty($request)) {
            if (!empty($request->id) && !empty($request->status)) {
                $app = new AppController();
                $id = $app->sanitize($request->id);
                $status = $app->sanitize($request->status);
                $query = Funding::where(['id' => $id])->get();
                if ($query->count() == 1) {
                    $query = Funding::where(['id' => $id])->update(['status' => $status]);
                if($query) {
                    return response()->json(["code" => 200, "status" => $status, "message" => "Status successfully set ".$status]);
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }

                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
            }
        }
    }
}



/*******************************************************************************************************/

protected function delete(Request $request) {
    if ($request->ajax()) {
        if (!empty($request)) {
            if (!empty($request->id)) {
                $id = $request->id;
                $query = Funding::where(['id' => $id])->get();
                if ($query->count() == 1) {
                    $query = Funding::where(['id' => $id])->delete();
                if($query) {
                    return response()->json(["code" => 200, "message" => "Coupon successfully deleted"]);
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }

                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
            }
        }
    }
}


/*******************************************************************************************************/


protected function action(Request $request) {
    if ($request->ajax()) {
        if (!empty($request)) {
            if (!empty($request->arr) && !empty($request->action)) {
                foreach ($request->arr as $arr) {
                    if ($request->action == "delete") {
                     $query = Funding::where(['id' => $arr])->delete();
                    } else  {
                     $query = Funding::where(['id' => $arr])->update(['status' => $request->action]);
                    }
                }
                if($query) {
                    return response()->json(["code" => 200, "message" => "Action successfully processed"]);
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
            }
        }
    }
}


/*******************************************************************************************************/

protected function edit(Request $request) {
    if ($request->ajax()) {
        if (!empty($request)) {
            if (!empty($request->id)) {
                $id = $request->id;
                $query = Funding::where(['id' => $id])->get();
                if ($query->count() == 1) {
                    $query = $query->first();
                    return response()->json(["code" => 200, "data" => [
                        'id' => $query->id,
                        'coupon' => $query->code,
                        'amount' => $query->amount,
                        'status' => $query->status,
                    ]]);

                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
            }
        }
    }
}






protected function update(Request $request) {
    if ($request->ajax()) {
        $validator = Validator::make($request->all(),[
            'id'=>'required',
            'coupon'=>'required',
            'amount' => 'required',
            'status'=>'required',
         ]);

          if ($validator->fails())  {
                $error = $validator->errors()->first();
                return response()->json(["code" => 500, "type" => "error", "message" => $error]);
          } else {
              $app = new AppController();
              $id = $app->sanitize($request->id);
              $coupon = $app->sanitize($request->coupon);
              $amount = $app->sanitize($request->amount);
              $status = $app->sanitize($request->status);
              $query = Funding::where(["id" => $id]);
              if ($query->count() == 1) {
                $query = $query->first();
                if ($coupon !== $query->code || $amount !== $query->amount || $status !== $query->status) {
                    $query =     Funding::where(['id' => $id])->update(['code' => $coupon, 'amount' => $amount, 'status' => $status]);
                    if ($query){
                        return response()->json(["code" => 200, "type" => "success", "message" => "Coupon successfully updated"]);
                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong!!"]);
                }



                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "No change was made"]);
                  }

              } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong!!"]);
              }

          }
    }
}

/*******************************************************************************************************/









}
