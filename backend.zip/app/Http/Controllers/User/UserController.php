<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\User\User;
use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\AppController;
use App\Http\Controllers\Transaction\TransactionController;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    //

    protected function index(Request $request) {
        if ($request->ajax()) {
            $entries = $request->entries;
            $search = $request->search;
            $filter = $request->filter;
            if ($filter == "all" || $filter == ""){
            $query =  User::orderBy('id', 'desc')->where('username', 'like', '%'.$search.'%')
                ->orWhere('email', 'like', '%'.$search.'%')
                ->orWhere('firstname', 'like', '%'.$search.'%')
                ->orWhere('lastname', 'like', '%'.$search.'%')
                ->orWhere('phone_number', 'like', '%'.$search.'%')->paginate($entries);
            } else {
                $query =  User::orderBy('id', 'desc')->where('status', $filter)->paginate($entries);
            }

        if ($query->count() > 0) {
        $table =  "<table id='table' class='table table-striped table-bordered' style='width:100%'>
        <thead>
            <tr>
                <th>S/N</th>
                <th>Username</th>
                <th>Email</th>
                <th>Phone Number</th>
                <th>Wallet(&#8358;)</th>
                <th>Category</th>
                <th style='padding-right: 50px;'>Action</th>
            </tr>
        </thead>
        <tbody>";

        $i = ($query->perPage() * ($query->currentPage() - 1)) + 1;
        foreach ($query as $user)  {
        $serialNumber = $i++;
        // $trimmedNumber = ltrim($user->phone_number,$user->phone_number[0]);
         $table .=  "<tr>
                <td>{$serialNumber}</td>
                <td>{$user->username}</td>
                <td>{$user->email}</td>
                <td>{$user->phone_number}</td>
                <td>{$user->wallet}</td>
                <td>{$user->category}</td>

                <td>
                <button class='btn btn-success btn-sm' data-toggle='tooltip'  id='edit' data-id=". $user->id ." style='background-color: #2dbe60; padding: 8px; margin-right: 8px'> <i class='fas fa-edit action_icon' style='font-size: 10px;'></i> </button>
                <button class='btn btn-danger btn-sm' data-toggle='tooltip' id='delete' data-id=". $user->id ." style='padding: 8px'> <i class='fas fa-trash action_icon' style='font-size: 10px;'></i> </button>
                </td>
            </tr>";
        }

        $table .= "</tbody>
    </table>
    <div class='float-start'> Showing ". $query->firstItem() ." to ". $query->lastItem() ." of ". $query->total() ." entries</div>
    <div class='float-end mt-4 mb-2'>". $query->links('pagination::bootstrap-4') ."</div>";

        return $table;
    } else {
        $notFound = "<div class='text-center mt-2'>
            <img src='/images/no-result-found.png' width='200px' />
        </div>";
            return $notFound;
    }

        } else {
            return view('user.user');
        }
    }








    protected function wallet(Request $request) {
        if ($request->ajax()) {

            $validator = Validator::make($request->all(),[
                'user'=>'required',
                'amount' => 'required|int',
                'action'=>'required',
             ]);

              if ($validator->fails())  {
                    $error = $validator->errors()->first();
                    return response()->json(["code" => 500, "type" => "error", "message" => $error]);
              } else {
                  $app = new AppController();
                  $transaction = new TransactionController();
                  $user = $app->sanitize($request->user);
                  $amount = $app->sanitize($request->amount);
                  $action = $app->sanitize($request->action);
                  $query = User::where(["username" => $user])->orWhere(['email' => $user])->get();
                  if ($query->count() == 1) {
                      if ($action == "credit") {
                        $balance = $query[0]->wallet + $amount;
                      } else if($action == "debit")  {
                        $balance = $query[0]->wallet - $amount;
                      } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Invalid action"]);
                      }

                    $update = User::where(["username" => $user])->orWhere(['email' => $user])->update(["wallet" => $balance]);
                      if ($update) {
                        $description = "₦$amount wallet $action";
                        $transaction->save($query[0]->username, $query[0]->email, "Wallet Funding", "System", $description, $query[0]->phone_number, $amount, ucwords($action), $query[0]->wallet, $balance, $app->reference(), "Admin funding", "null", "null", "null", "null", "null", 'success', $app->date);
                        return response()->json(["code" => 200, "type" => "success", "message" => $query[0]->username." wallet has successfully been $action"."ed with ₦$amount naira available balance is ₦$balance naira"]);
                      } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "A critical error ocurred"]);
                      }

                  } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "User not found"]);
                  }
              }

        } else {
            return view('user.wallet');
        }
    }



    protected function password(Request $request) {
        if ($request->ajax()) {

            $validator = Validator::make($request->all(),[
                'user'=>'required',
                'password' => 'bail|required|min:6',
                'confirm_password'=>'required',
             ]);

              if ($validator->fails())  {
                    $error = $validator->errors()->first();
                    return response()->json(["code" => 500, "type" => "error", "message" => $error]);
              } else {
                  $app = new AppController();
                  $user = $app->sanitize($request->user);
                  $password = $app->sanitize($request->password);
                  $confirm_password = $app->sanitize($request->confirm_password);
                  if ($password == $confirm_password) {
                  $query = User::where(["username" => $user])->orWhere(['email' => $user])->get();
                  if ($query->count() == 1) {
                    $password = Hash::make($password);
                    $update = User::where(["username" => $user])->orWhere(['email' => $user])->update(["password" => $password]);
                      if ($update) {
                        return response()->json(["code" => 200, "type" => "success", "message" => $query[0]->username." password has successfully been reset"]);
                      } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "A critical error ocurred"]);
                      }

                  } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "User not found"]);
                  }

                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Passwords do not match"]);
                  }
              }

        } else {
            return view('user.password');
        }
    }


    protected function pin(Request $request) {
        if ($request->ajax()) {

            $validator = Validator::make($request->all(),[
                'user'=>'required',
                'pin' => 'bail|nullable|min:4|max:4',
             ]);

              if ($validator->fails())  {
                    $error = $validator->errors()->first();
                    return response()->json(["code" => 500, "type" => "error", "message" => $error]);
              } else {
                  $app = new AppController();
                  $user = $app->sanitize($request->user);
                  $pin = $app->sanitize($request->pin);

                  $query = User::where(["username" => $user])->orWhere(['email' => $user])->get();
                  if ($query->count() == 1) {
                    $update = User::where(["username" => $user])->orWhere(['email' => $user])->update(["pin" => $pin]);
                      if ($update) {
                        return response()->json(["code" => 200, "type" => "success", "message" => $query[0]->username." transaction PIN has successfully been reset"]);
                      } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "A critical error ocurred"]);
                      }

                  } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "User not found"]);
                  }

              }

        } else {
            return view('user.pin');
        }
    }




protected function edit(Request $request) {
    if ($request->ajax()) {
        if (!empty($request)) {
            if (!empty($request->id)) {
                $id = $request->id;
                $query = User::where(['id' => $id])->get();
                if ($query->count() == 1) {
                    $query = $query->first();
                    return response()->json(["code" => 200, "data" => [
                        'id' => $query->id,
                        'email' => $query->email,
                        'username' => $query->username,
                        'firstname' => $query->firstname,
                        'lastname' => $query->lastname,
                        'phone_number' => $query->phone_number,
                        'apikey' => $query->apikey,
                        'status' => $query->status,
                    ]]);

                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            } else {
                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
            }
        }
    }
}




    protected function delete(Request $request) {
        if ($request->ajax()) {
            if (!empty($request)) {
                if (!empty($request->id)) {
                    $id = $request->id;
                    $query = User::where(['id' => $id])->get();
                    if ($query->count() == 1) {
                        $app = new AppController();
                        if ($app->admin()["role"] == "super-admin") {
                        $query = User::where(['id' => $id])->delete();
                        if($query) {
                            return response()->json(["code" => 200, "message" => "User account successfully deleted"]);
                        } else {
                            return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                        }

                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Action revoked. you're not allowed to do this"]);
                    }

                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                    }
                } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong"]);
                }
            }
        }
    }






    protected function update(Request $request) {
        if ($request->ajax()) {
            $validator = Validator::make($request->all(),[
                'id'=>'required|string',
                'firstname' => 'required|max:50|string',
                'lastname' => 'required|max:50|string',
                'phone_number' => 'required|max:11|string',
                'apikey' => 'required|max:200|string',
                'status'=>'required|string',
             ]);

              if ($validator->fails())  {
                    $error = $validator->errors()->first();
                    return response()->json(["code" => 500, "type" => "error", "message" => $error]);
              } else {
                  $app = new AppController();
                  $id = $app->sanitize($request->id);
                  $firstname = $app->sanitize($request->firstname);
                  $lastname = $app->sanitize($request->lastname);
                  $phone_number = $app->sanitize($request->phone_number);
                  $apikey = $app->sanitize($request->apikey);
                  $status = $app->sanitize($request->status);
                  $query = User::where(["id" => $id]);
                  if ($query->count() == 1) {
                    $query = $query->first();
                    if ($firstname !== $query->firstname || $lastname !== $query->lastname || $phone_number !== $query->phone_number || $apikey !== $query->apikey || $status !== $query->status) {
                        $username = $query->username;
                        $query =  User::where(['id' => $id])->update(['firstname' => $firstname, 'lastname' => $lastname, 'phone_number' => $phone_number, 'apikey' => $apikey, 'status' => $status]);
                        if ($query){
                            return response()->json(["code" => 200, "type" => "success", "message" => "$username account has been  successfully updated"]);
                            } else {
                                return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong!!"]);
                            }

                    } else {
                        return response()->json(["code" => 500, "type" => "error", "message" => "No change was made"]);
                    }

                  } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "Whoops Something went wrong!!"]);
                  }

              }
        }
    }





    protected function extract(Request $request) {
        if ($request->ajax()) {
            $validator = Validator::make($request->all(),[
                'value'=>'required',
             ]);

              if ($validator->fails())  {
                    $error = $validator->errors()->first();
                    return response()->json(["code" => 500, "type" => "error", "message" => $error]);
              } else {
                  $app = new AppController();
                  $value = $app->sanitize($request->value);
                  $query = DB::table('users')->pluck($value);
                  if ($query->count() > 0) {
                    return response()->json(["code" => 200, "type" => "success", "message" => "data fetched", "data" => $query]);
                  } else {
                    return response()->json(["code" => 500, "type" => "error", "message" => "No user found"]);
                }
              }

        } else {
            return view("user.extract");
        }
    }





}

