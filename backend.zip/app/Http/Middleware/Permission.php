<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class Permission
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {


        if (!$request->session()->has('token')) {
            return redirect('/login');
        } else {
            $token = session('token');
            $query = DB::table('admin')->where(['token' => $token])->get();
            if ($query->count() == 1) {
                $query = $query->first();
                if ($query->role !== "super-admin") {
                    $permission = json_decode($query->permission);
                    // print_r($permission);
                    // Modify Service
                    if ($permission->modify_service == "no") {
                        if ($request->is('data/*') || $request->is('data') || $request->is('airtime')
                        || $request->is('airtime/*') || $request->is('cable/*') || $request->is('airtime-cash')
                        || $request->is('airtime-cash/*') || $request->is('bills') || $request->is('bills/*')
                        || $request->is('exam') || $request->is('exam/*') || $request->is('bulk-sms') || $request->is('bulk-sms/*')
                        || $request->is('smile') || $request->is('smile/*') || $request->is('host') || $request->is('host/*')
                        || $request->is('spectranet') || $request->is('spectranet/*') || $request->is('recharge') || $request->is('recharge/*')
                        ) {
                            return abort(403);
                        }
                    }
                    // Allow Funding
                    if ($permission->allow_funding == "no") {
                        if ($request->is('users/wallet/*') || $request->is('users/wallet') || $request->is('coupon/funding/*')
                        || $request->is('coupon/funding')) {
                            return abort(403);
                        }
                    }

                    //
                    if ($permission->modify_tranx == "no") {
                        if ($request->is('transactions/*') || $request->is('transactions')) {
                            return abort(403);
                        }
                    }


                    if ($permission->modify_user == "no") {
                        if ($request->is('users')) {
                            return abort(403);
                        }
                    }

                    
                }
            } else {
                return redirect('/login');
            }
        }


        return $next($request);
    }
}
