<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCableListTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('cable_list', function (Blueprint $table) {
            $table->id();
            $table->string("key");
            $table->string("cable_id");
            $table->string("cable");
            $table->string("category");
            $table->string("charge");
            $table->string("charge_type");
            $table->string("status");
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('cable_list');
    }
}
