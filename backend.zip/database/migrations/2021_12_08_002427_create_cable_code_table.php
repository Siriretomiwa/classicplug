<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCableCodeTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('cable_code', function (Blueprint $table) {
            $table->id();
            $table->string("key");
            $table->string("plan_id");
            $table->string("cable");
            $table->string("cable_id");
            $table->string("plan");
            $table->string("code");
            $table->string("provider");
            $table->string("status");
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('cable_code');
    }
}
