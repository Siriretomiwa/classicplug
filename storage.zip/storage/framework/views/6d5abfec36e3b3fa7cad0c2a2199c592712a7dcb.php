<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="/ajax/bills/charge.js"> </script>
<?php echo $__env->make('layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="content">
               <!-- Start Content-->
                    <div class="container-fluid">
                     <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">admin</a></li>
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">home</a></li>
                                        </ol>
                                    </div>
                                    <h4 class="page-title">Dashboard</h4>
                                </div>
                            </div>
                        </div>
                        <!-- end page title -->
                </div> <!-- end container-fluid -->
          </div> <!-- end content -->


				<div class="row">
                    <div class="col-12">
                                <div class="card-box" style="border: 1px solid white;">


                                    <div class="container" style="margin-bottom: 50px">
                                        <span class="header-title" style="float: left"><b>Bills Charge</b></span>
                                            <span class="" style="float: right">
                            
                            <a href="#" data-toggle="modal" data-target="#add-category" class="btn btn-secondary btn-block waves-effect waves-light">
                            <i class="fa fa-flag mr-1"></i>
                            Merge
                        </a>
                                                    </span>
                                                </div>

                                                <hr/>

                                        <div class="form-group">
                                            <p for=""> Choose category for which you want to set charge </p>
                                    <select class="form-control form-white" id="category" required>
                                        <option value="">Please select</option>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->name); ?>"><?php echo e($category->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                      </select>
                                           </div>


                            <div class="alert alert-primary" style="padding: 5px 8px; border: 2px dashed;" role="alert">
                            <strong>Note:</strong> Convenient fee is an additional charge added to the product,
                                whereas Discount is a percentage reduction in the product price.
                            </div>




                               <div class="table-responsive">
                                <div id="tableContainer"> </div>
                            </div>


                            </div>
						</div>
                        </div>
                        <!-- end row -->



                                  <!-- Modal  -->
                                  <div class="modal fade none-border" id="add-category">
                                    <div class="modal-dialog">
                                        <div class="modal-content" style="border: 2px solid darkgrey;">
                                            <div class="modal-header" style="border-bottom: 2px solid darkgrey;">
                                                <h5 class="modal-title">Bills Charge</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                            </div>
                                            <div class="modal-body p-3">
                                                <form id="form">
                                    <p id="message" class="text-center text-danger"></p>
                                                    <div class="row">



                                                <div class="col-md-6">
                                                    <label class="control-label">Merge | Category 1</label>
                                                    <select class="form-control form-white" id="category_1" required>
                                                        <option value="">Please select</option>
                                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($category->name); ?>"><?php echo e($category->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                        </select>
                                                </div>



                                                <div class="col-md-6">
                                                    <label class="control-label">With | Category 2</label>
                                                    <select class="form-control form-white" id="category_2" required>
                                                        <option value="">Please select</option>
                                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($category->name); ?>"><?php echo e($category->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                        </select>
                                                </div>



                                                    </div>
                                                </form>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary waves-effect" data-dismiss="modal" id="form_cancel">Cancel</button>
                                                <button type="button" class="btn btn-danger waves-effect waves-light save-category" id="merge"> <span id="merge-spinner"></span> <span id="merge-txt"> Merge </span></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- END MODAL -->




                    </div>




<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/xdatyzyi/booda-classic.classicplug.com/resources/views/bills/charge.blade.php ENDPATH**/ ?>