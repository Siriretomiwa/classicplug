<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="content">
               <!-- Start Content-->
                    <div class="container-fluid">
                     <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">admin</a></li>
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">home</a></li>
                                        </ol>
                                    </div>
                                    <h4 class="page-title">Dashboard</h4>
                                </div>
                            </div>
                        </div>
                        <!-- end page title -->
                </div> <!-- end container-fluid -->
          </div> <!-- end content -->


				<div class="row">
                    <div class="col-12">
                                <div class="card-box" style="border: 1px solid darkgrey;">

                                    <p> Choose a user category for which you want to set charge </p>
                                    <div class="form-group">
                                        <label for="">Category.</label>
                                <select class="form-control form-white" id="category" required>
                                    <option value="">Please select</option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->name); ?>"><?php echo e($category->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                  </select>
                                       </div>

                    <button  id="proceed" class="btn btn-primary btn-block waves-effect waves-light" style="border-radius: 10px;"><span id="btn-spinner"></span> <span id="btn-txt"> Proceed </span></button>





                            </div>
						</div>
                        </div>
                        <!-- end row -->




<div id="response"></div>

                                <input id="page" value="1" type="text" readonly hidden/>



<script>
    $(document).on("click", "#proceed", () => {
        let category = $("#category").val();
        let searchParams = new URLSearchParams(window.location.search);
        let param = searchParams.get("service");
        let path = param;
        if (category !== "") {
            $("#proceed").attr("disabled", "disabled");
                    $("#btn-txt").text("redirecting...");
                    $("#btn-spinner").addClass("spinner-border spinner-border-sm");
            window.location.href="/"+path+"-price/?category="+category;
        } else {
            alert("please select a category");
        }
    })
</script>

<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\laravel\vtu-admin\resources\views/group.blade.php ENDPATH**/ ?>