<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="/ajax/gateway/monnify.js"> </script>
<?php echo $__env->make('layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="content">
               <!-- Start Content-->
                    <div class="container-fluid">
                     <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">admin</a></li>
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">home</a></li>
                                        </ol>
                                    </div>
                                    <h4 class="page-title">Dashboard</h4>
                                </div>
                            </div>
                        </div>
                        <!-- end page title -->
                </div> <!-- end container-fluid -->
          </div> <!-- end content -->


				<div class="row">
                    <div class="col-12">
                                <div class="card-box">


                                    <div class="container" style="margin-bottom: 50px">
                                    <span class="header-title" style="float: left">Monnify</span>
									   <span class="" style="float: right">

                                       </span>
                                    </div>

                                    <hr/>


                                    <form method="post" action="#">

                                    <div class="form-group">
                                        <label for="">Monnify API Key *</label>
                                        <input type="text" class="form-control form-white" id="api_key"
                                                    placeholder="Enter Your Monnify API Key"
                                                    value=<?php echo e($monnify !== null ? $monnify->api_key : null); ?>>
                                    </div>



                                        <div class="form-group">
                                        <label for="">Monnify Secret Key *</label>
                                        <input type="text" class="form-control form-white" id="secret_key"
                                                    placeholder="Enter Your Monnify Secret Key"
                                                    value=<?php echo e($monnify !== null ? $monnify->secret_key : null); ?>>
                                        </div>



                                                    <div class="form-group">
                                        <label for=""> Monnify Contract Code </label>
                                        <input type="number" class="form-control form-white" id="contract"
                                        placeholder="Enter Your Monnify Contract Code"
                                        value=<?php echo e($monnify !== null ? $monnify->contract : null); ?>>
                                                            </div>



                                            <div class="form-group">
                                            <label for="">Monnify Business Name</label>
                                            <input type="text" class="form-control form-white" id="name"
                                                    placeholder="Enter Your Monnify Business Name"
                                                    value=<?php echo e($monnify !== null ? $monnify->name : null); ?>>
                                            </div>



                                        <div class="form-group">
                                            <label for="">Monnify Charge Type |  FLAT Rate (0.75%) | VAT Rate (&#8358;50)</label>
                                                    <select class="form-control form-white" id="type">


                                                    <?php if(isset($monnify->type) && $monnify->type == "VAT"): ?>
                                                        <option value="VAT">VAT RATE</option>
                                                        <option value="FLAT">FLAT RATE</option>
                                                    <?php else: ?>
                                                        <option value="FLAT">FLAT RATE</option>
                                                        <option value="VAT">VAT RATE</option>
                                                    <?php endif; ?>
                                                    </select>
                                                    </div>



                                        <div class="form-group">
                                            <label for="">Monnify Charge For Virtual Acct. | FLAT Rate (%) | VAT Rate (&#8358;)</label>
                                                <input type="number" class="form-control form-white" id="transfer_charge"
                                                    placeholder="Monnify Charge | FLAT Rate (%) | VAT Rate (₦)"
                                                    value=<?php echo e($monnify !== null ? $monnify->transfer_charge : null); ?>>
                                            </div>



                                    <div class="form-group">
                                        <label for="">What percent will you like to charge on monnify card Funding(%)* </label>
                                            <input type="number" class="form-control form-white" id="card_charge"
                                                placeholder="What percent will you like to charge on monnify Funding(%)"
                                                value=<?php echo e($monnify !== null ? $monnify->card_charge : null); ?>>
                                        </div>



                                    <div class="form-group">
                                        <label for=""> Your preferred user's bank code for virtual funding * <a href="https://teamapt.atlassian.net/wiki/spaces/MON/pages/295075851/Available+Partner+Banks" target="blank"> click here to view bank code</a> </label>
                                            <input type="text" class="form-control form-white" id="bank_code"
                                                placeholder="Your preferred user's bank code for virtual funding"
                                                value=<?php echo e($monnify !== null ? $monnify->bank_code : null); ?>>
                                        </div>




                                    <div class="form-group">
                                        <label class="control-label">Status</label>
                                        <select class="form-control form-white" id="status" required>
                                            <?php if(isset($monnify->status) && $monnify->status == "unavailable"): ?>
                                                <option value="unavailable">Unavailable</option>
                                                <option value="available">Available</option>
                                            <?php else: ?>
                                                <option value="available">Available</option>
                                                <option value="unavailable">Unavailable</option>

                                            <?php endif; ?>
                                            </select>
                                    </div>



        <button  id="monnify" class="btn btn-secondary btn-block waves-effect waves-light"> <span id="btn-spinner"></span> <span id="btn-txt"> Save </span> </button>

    </form>


                                </div><!-- end col -->






                            </div>
						</div>
                        </div>
                        <!-- end row -->







<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/xdatyzyi/backend.classicplug.com/resources/views/gateway/monnify.blade.php ENDPATH**/ ?>