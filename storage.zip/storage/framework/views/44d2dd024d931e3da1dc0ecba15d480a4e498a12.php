<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="/ajax/data-price.js"> </script>
<?php echo $__env->make('layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="content">
               <!-- Start Content-->
                    <div class="container-fluid">
                     <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">admin</a></li>
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">home</a></li>
                                        </ol>
                                    </div>
                                    <h4 class="page-title">Dashboard</h4>
                                </div>
                            </div>
                        </div>
                        <!-- end page title -->
                </div> <!-- end container-fluid -->
          </div> <!-- end content -->


				<div class="row">
                    <div class="col-12">
                                <div class="card-box" style="border: 1px solid darkgrey;">


                                    <div class="container" style="margin-bottom: 25px">
                                    <div class="header-title"><b>Data Price</b></div>

                                        <div class="form-group">
                                            <p for=""> Choose category for which you want to set charge </p>
                                    <select class="form-control form-white" id="category" required>
                                        <option value="">Please select</option>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->name); ?>"><?php echo e($category->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                      </select>
                                           </div>
                                            </div>



                               <div class="table-responsive">
                                <div id="tableContainer"> </div>
                            </div>


                            </div>
						</div>
                        </div>
                        <!-- end row -->


                                <!-- Modal Add Category -->
                                <div class="modal fade none-border" id="add-category">
                                    <div class="modal-dialog">
                                        <div class="modal-content" style="border: 2px solid darkgrey;">
                                            <div class="modal-header" style="border-bottom: 2px solid darkgrey;">
                                                <h5 class="modal-title">Data</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                            </div>
                                            <div class="modal-body p-3">
                                                <form id="form">
								 <p id="message" class="text-center text-danger"></p>
                                                    <div class="row">




                                                        <div class="col-md-6">
                                                            <label class="control-label">Type</label>
                                             <select class="form-control form-white" id="type" required>
                                                                <option value="GIFTING">GIFTING</option>
                                                                <option value="SME">SME</option>
                                                                <option value="SME">COOPERATE</option>
																</select>
                                                        </div>





														 <div class="col-md-6">
                                                            <label class="control-label">Plan </label>
                           <input class="form-control form-white" id="plan" placeholder="Enter plan name" type="text" required />
                                                        </div>

                                                        <div class="col-md-6">
                                                            <label class="control-label">Host</label>
                                             <select class="form-control form-white" id="provider" required>
                                                                <option value="simpledata">Simpledata</option>
																</select>
                                                        </div>

                                                        <div class="col-md-6">
                                                            <label class="control-label">Host Code </label>
                           <input class="form-control form-white" id="code" placeholder="Enter plan code / USSD query String" type="text" required />
                                                        </div>

                                                        <div class="col-md-6">
                                                            <label class="control-label">Plan Size</label>
                           <input class="form-control form-white" id="size" placeholder="Enter plan size [1GB = 1000, 50MB = 50, 1.2GB = 1200, etc]" type="number" required />
                                                        </div>

                                                        <div class="col-md-12">
                                                            <label class="control-label">Status</label>
                                             <select class="form-control form-white" id="status" required>
                                                                <option value="available">Available</option>
                                                                <option value="unavailable">Unavailable</option>
																</select>
                                                        </div>



                                                    </div>
                                                </form>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary waves-effect" data-dismiss="modal" id="form_cancel">Cancel</button>
                                                <button type="button" class="btn btn-danger waves-effect waves-light save-category" id="createData"> <span id="btn-spinner"></span> <span id="btn-txt"> Save </span></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- END MODAL -->


                        <div id="response"></div>

                                <input id="group" value="<?php echo e(request()->get('category')); ?>" type="text" readonly hidden/>




                                <!-- Modal Add Category -->
                                <div class="modal fade none-border" id="update">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title">Update Data Plan</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                            </div>
                                            <div class="modal-body p-3">
                                                <form>
								 <p id="update-message" class="text-center text-danger"></p>
                                                    <div class="row">

		<input class="form-control form-white" id="update-id" placeholder="ID" hidden readonly type="text" required />

                                  <div class="col-md-6">
                                                            <label class="control-label">Network </label>
           <input class="form-control form-white" id="update-network" placeholder="Network" type="text" readonly required />
                                                        </div>

							<div class="col-md-6">
                                 <label class="control-label">Type </label>
                           <input class="form-control form-white" id="update-type" placeholder="Type" readonly type="text" required />
                                                        </div>


														 <div class="col-md-6">
                                                            <label class="control-label">Plan </label>
                           <input class="form-control form-white" id="update-plan" placeholder="1 GB - 1 month Validity....." type="text" required />
                                                        </div>


									<div class="col-md-6">
                                      <label class="control-label">Plan Size</label>
                           <input class="form-control form-white" id="update-plan-size" placeholder="Plan size e.g 1MB, 2GB" type="text"/>
                                                        </div>

											 <div class="col-md-6">
                                                            <label class="control-label">Plan Code</label>
                           <input class="form-control form-white" id="update-plan-code" placeholder="1, 2, 3, 4" type="text" required />
                                                        </div>



														 <div class="col-md-6">
                                                            <label class="control-label">USSD / SME Plan Code </label>
                           <input class="form-control form-white" id="update-code" placeholder="SMEB, SMEC / *141*6*2*2*1*1*" type="text" required />
                                                        </div>

														 <div class="col-md-6">
                                                            <label class="control-label">Default Price</label>
							<input class="form-control form-white" id="update-default-price" placeholder="Enter your price" type="number" required />
                                                        </div>


                                                    </div>
                                                </form>
                                            </div>
                                            <div class="modal-footer">
 <button type="button" class="btn btn-secondary waves-effect" data-dismiss="modal" id="form_cancel">Cancel</button>
 <button type="button" class="btn btn-danger waves-effect waves-light save-category" id="update-data">Update</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- END MODAL -->


<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\laravel\vtu-admin\resources\views/data-price.blade.php ENDPATH**/ ?>