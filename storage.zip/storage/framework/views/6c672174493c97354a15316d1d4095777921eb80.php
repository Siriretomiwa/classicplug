<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="/ajax/category/user-category.js"> </script>
<?php echo $__env->make('layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="content">
               <!-- Start Content-->
                    <div class="container-fluid">
                     <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">admin</a></li>
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">home</a></li>
                                        </ol>
                                    </div>
                                    <h4 class="page-title">Dashboard</h4>
                                </div>
                            </div>
                        </div>
                        <!-- end page title -->
                </div> <!-- end container-fluid -->
          </div> <!-- end content -->


				<div class="row">
                    <div class="col-12">
                                <div class="card-box" style="border: 1px solid white;">


                                    <div class="container" style="margin-bottom: 50px">
                                    <span class="header-title" style="float: left">User Category</span>
									   <span class="" style="float: right">
                      

                      <img src="/images/avatar.png" alt="#" width="40px" class="avatar-img rounded-circle">
                    </span>
                                    </div>

                                    <hr/>



                                    <div class="row">
                                        <div class="col-xl-6">
                                            <form method="post" action="#">

											<div class="form-group">
                                  <label for=""> Category </label>
                                      <select class="form-control form-white" id="category" required>
									<option value=""> Please select </option>

                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->name); ?>"> <?php echo e($category->name); ?> </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

												</select>
                                                   </div>







                                        </div><!-- end col -->






                                        <div class="col-xl-6">
                                            <form method="post" action="#">

											<div class="form-group">
                                  <label for="">Force charge deduction from wallet </label>
                                      <select class="form-control form-white" id="charge" required>
									        <option value=""> Please select </option>
                                            <option value="no"> No </option>
                                            <option value="yes"> Yes </option>
												</select>
                                                   </div>








                                        </div><!-- end col -->


                                        <div class="col-md-12">
                                            <label for="username">Username [Seperate by comma (,) for multiple username ]</label>
                                                  <textarea class="form-control" id="username" rows="3"></textarea>
                                                                </div>




											</form>

                                                    </div>


                        <a href="#" id="save" class="btn btn-secondary btn-block waves-effect waves-light" style="margin-top: 15px"> <span id="btn-spinner"></span> <span id="btn-txt"> Save </span> </a>



                                        </div>




                                    </div>
                                    </div>









                            </div>
						</div>
                        </div>
                        <!-- end row -->












<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/xdatyzyi/booda-classic.classicplug.com/resources/views/category/user-category.blade.php ENDPATH**/ ?>