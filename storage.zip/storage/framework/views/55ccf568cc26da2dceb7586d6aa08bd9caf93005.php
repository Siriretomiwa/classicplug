<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="/ajax/user/password.js"> </script>
<?php echo $__env->make('layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="content">
               <!-- Start Content-->
                    <div class="container-fluid">
                     <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">admin</a></li>
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">home</a></li>
                                        </ol>
                                    </div>
                                    <h4 class="page-title">Dashboard</h4>
                                </div>
                            </div>
                        </div>
                        <!-- end page title -->
                </div> <!-- end container-fluid -->
          </div> <!-- end content -->


				<div class="row">
                    <div class="col-12">
                                <div class="card-box">


                                    <div class="container" style="margin-bottom: 50px">
                                    <span class="header-title" style="float: left">Reset Password</span>
									   <span class="" style="float: right">

                                       </span>
                                    </div>

                                    <hr/>


                                    <form method="post" action="#">


                                        <div class="form-group">
                                            <label for="">Username or Email</label>
        <input type="text" class="form-control form-white" id="user" placeholder="Enter Username or Email">
                                          </div>



                                          <div class="form-group">
                                            <label for="">Password</label>
        <input type="password" class="form-control form-white" id="password" placeholder="Enter password">
                                           </div>



                            <div class="form-group">
                                            <label for="">Confirm Password</label>
        <input type="password" class="form-control form-white" id="confirm_password" placeholder="Re-type password">
                                           </div>


        <button  id="proceed" class="btn btn-secondary btn-block waves-effect waves-light"> <span id="btn-spinner"></span> <span id="btn-txt"> Proceed </span> </button>

    </form>


                                </div><!-- end col -->






                            </div>
						</div>
                        </div>
                        <!-- end row -->







<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\laravel\vtu-admin\resources\views/user/password.blade.php ENDPATH**/ ?>