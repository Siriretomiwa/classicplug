<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="/ajax/gateway/virtual-accounts.js"> </script>
<?php echo $__env->make('layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="content">
               <!-- Start Content-->
                    <div class="container-fluid">
                     <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">admin</a></li>
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">home</a></li>
                                        </ol>
                                    </div>
                                    <h4 class="page-title">Dashboard</h4>
                                </div>
                            </div>
                        </div>
                        <!-- end page title -->
                </div> <!-- end container-fluid -->
          </div> <!-- end content -->


				<div class="row">
                    <div class="col-12">
                                <div class="card-box">


                                    <div class="container" style="margin-bottom: 50px">
                                    <span class="header-title" style="float: left"> Virtual Accounts </span></div>

                                    <hr/>





            
                        <div class="row">
                            <div class="col">
                                <label class="control-label">Bank Code</label>
                 <select class="form-control form-white" id="bank">
                        <option value="">Please select</option>
                        <?php if($bank_code !== null): ?>
                            <?php if(count($bank_code) !== 0 ): ?>
                                <?php $__currentLoopData = $bank_code; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value=<?php echo e($code); ?>><?php echo e($code); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                        <?php else: ?>
                        <option value=''> No bank</option>
                        <?php endif; ?>


                                    </select>
                            </div>



                            <div class="col">
                                <label class="control-label">Action</label>
                 <select class="form-control form-white" id="action">
                    <option value="">Please select</option>
                    <option value="available"> Available </option>
                    <option value="unavailable"> Unavailable </option>
                    <option value="delete"> Delete </option>
                                    </select>
                            </div>



                            </div>



                <a href="#" id="apply" class="btn btn-secondary btn-block waves-effect waves-light text-white" style="margin-top: 15px; font-weight: 600;">
                    <span id="applybtn-spinner"></span> <span id="applybtn-txt"> Apply </span> </a>






			<div class="row mb-3">
				<div class="col-md-6">
                            <label> Search </label>
                            <input class="form-control form-white" id="search" type="text" placeholder="Searching for something? Try 'username'">
                        </div>


                <div class="col-md-6">
                    <label> Entries </label>
                        <select class="form-control form-white" id="entries" required>
                            <option value="10"> 10 </option>
                            <option value="25"> 25 </option>
                            <option value="50"> 50 </option>
                            <option value="100"> 100 </option>
                            <option value="150"> 150 </option>
                            <option value="200"> 200 </option>
                        </select>
                    </div>

                </div>


                <div class="table-responsive">
                    <div id="tableContainer"> </div>



                            </div>
						</div>
                        </div>
                        <!-- end row -->



<div id="response"></div>





<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\laravel\vtu-admin\resources\views/gateway/virtual-account.blade.php ENDPATH**/ ?>