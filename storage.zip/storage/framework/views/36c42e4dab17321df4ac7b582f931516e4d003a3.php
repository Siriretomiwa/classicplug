<!-- Begin page -->
<div id="wrapper">

    <!-- Topbar Start -->
    <div class="navbar-custom">
        <ul class="list-unstyled topnav-menu float-right mb-0">

            <li class="dropdown notification-list">
                <a class="nav-link dropdown-toggle  waves-effect waves-light" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                    <i class="mdi mdi-bell-outline noti-icon"></i>
                    <span class="noti-icon-badge"></span>
                </a>
          </li>

            <li class="dropdown notification-list">
                <a class="nav-link dropdown-toggle  waves-effect waves-light" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                    <i class="mdi mdi-email-outline noti-icon"></i>
                    <span class="noti-icon-badge"></span>
                </a>
     </li>

            <li class="dropdown notification-list">
                <a class="nav-link dropdown-toggle nav-user mr-0 waves-effect waves-light" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                    <img src="/images/03developer.jpeg" alt="03developer" class="rounded-circle">
                    <span class="d-none d-sm-inline-block ml-1 font-weight-medium">Admin</span>
                    <i class="mdi mdi-chevron-down d-none d-sm-inline-block"></i>
                </a>
                <div class="dropdown-menu dropdown-menu-right profile-dropdown ">
                    <!-- item-->
                    <div class="dropdown-header noti-title">
                        <h6 class="text-overflow text-white m-0">Welcome !</h6>
                    </div>

                    <!-- item-->
                    <a href="/reset-password" class="dropdown-item notify-item">
                        <i class="mdi mdi-account-outline"></i>
                        <span>Edit Password</span>
                    </a>



                    </a>

                    <div class="dropdown-divider"></div>

                    <!-- item-->
                    <a href="/logout" class="dropdown-item notify-item">
                        <i class="mdi mdi-logout-variant"></i>
                        <span>Logout</span>
                    </a>

                </div>
            </li>
        </ul>

        <!-- LOGO -->
        <div class="logo-box">
            <a href="#" class="logo text-center logo-dark">
                <span class="logo-lg">
                    <img src="/images/admin-text.png" alt="" height="22">
                    <!-- <span class="logo-lg-text-dark">Uplon</span> -->
                </span>
                <span class="logo-sm">
                    <!-- <span class="logo-lg-text-dark">U</span> -->
                    <img src="/images/admin-text.png" alt="" height="24">
                </span>
            </a>

            <a href="" class="logo text-center logo-light">
                <span class="logo-lg">
                    <img src="/images/admin-text.png" alt="" height="22">
                    <!-- <span class="logo-lg-text-dark">Uplon</span> -->
                </span>
                <span class="logo-sm">
                    <!-- <span class="logo-lg-text-dark">U</span> -->
                    <img src="/images/admin-text.png" alt="" height="24">
                </span>
            </a>
        </div>

        <ul class="list-unstyled topnav-menu topnav-menu-left m-0">
            <li>
                <button class="button-menu-mobile waves-effect waves-light">
                    <i class="mdi mdi-menu"></i>
                </button>
            </li>

        </ul>
    </div>
    <!-- end Topbar -->


    <!-- ========== Left Sidebar Start ========== -->
    <div class="left-side-menu">

        <div class="slimscroll-menu">

            <!--- Sidemenu -->
            <div id="sidebar-menu">

                <ul class="metismenu" id="side-menu">

                    <li class="menu-title">Navigation</li>

                    <li>
                        <a href="/">
                            <i class="mdi mdi-view-dashboard"></i>
                            <span> Dashboard </span>
                        </a>
                    </li>


    <li>
                        <a href="javascript: void(0);">
                            <i class="fas fa-bullhorn"></i>
                            <span> Notification </span></a>
                <ul class="nav-second-level" aria-expanded="false">
            <li><a href="/notification/email" style='font-weight: 500; color: #fff'>Via Email</a></li>
  <li><a href="/notification/sms" style='font-weight: 500; color: #fff'>Via Sms</a></li>
  <li><a href="/notification/dashboard" style='font-weight: 500; color: #fff'>Via Dashboard</a></li>
                        </ul>
                    </li>




                    








    <li><a href='javascript: void(0);'>
              <i class='fab fa-opencart'></i>
              <span> Transactions </span></a>
            <ul class='nav-second-level' aria-expanded='false'>
  <li><a href='/transactions' style='font-weight: 500; color: #fff'>All</a></li>
    <li><a href='/transactions/limit' style='font-weight: 500; color: #fff'>Limit</a></li>
    <li><a href='/transactions/statistics' style='font-weight: 500; color: #fff'>  Statistics </a></li>
    <li><a href='/transactions/log' style='font-weight: 500; color: #fff'>  Log </a></li>
                        </ul>
                    </li>



<li><a href='javascript: void(0);'>
                            <i class='fas fa-users'></i>
                            <span> Users </span></a>
                <ul class='nav-second-level' aria-expanded='false'>
  <li><a href='/users' style='font-weight: 500; color: #fff'>All</a></li>
            <li><a href='/users/wallet' style='font-weight: 500; color: #fff'>Edit Wallet</a></li>
  <li><a href='/users/reset/password' style='font-weight: 500; color: #fff'>Reset Password</a></li>
  <li><a href='/users/reset/pin' style='font-weight: 500; color: #fff'>Reset PIN</a></li>
  <li><a href='/users/extract-data' style='font-weight: 500; color: #fff'>Extract Data</a></li>
                        </ul>
                    </li>







<li><a href='javascript: void(0);'>
    <i class='fas fa-file'></i>
    <span> KYC </span></a>
<ul class='nav-second-level' aria-expanded='false'>
<li><a href='/kyc' style='font-weight: 500; color: #fff'>Verification</a></li>
<li><a href='/kyc/bvn-charge' style='font-weight: 500; color: #fff'> BVN Charge </a></li>
<li><a href='/kyc/bypass' style='font-weight: 500; color: #fff'>Bypass</a></li>
</ul>
</li>








          <li><a href='javascript: void(0);'>
            <i class='fas fa-box'></i>
            <span> Category </span></a>
<ul class='nav-second-level' aria-expanded='false'>
<li><a href='/category' style='font-weight: 500; color: #fff'>Manage</a></li>
<li><a href='/category/users' style='font-weight: 500; color: #fff'> User Control</a></li>
        </ul>
    </li>





          <li><a href='javascript: void(0);'>
            <i class='fas fa-h-square'></i>
            <span> Host </span></a>
<ul class='nav-second-level' aria-expanded='false'>
<li><a href='/host' style='font-weight: 500; color: #fff'>Manage</a></li>
<li><a href='/host/switch' style='font-weight: 500; color: #fff'>Switch</a></li>
        </ul>
    </li>




    <li><a href='javascript: void(0);'>
        <i class='fas fa-cloud'></i>
        <span> Network </span></a>
<ul class='nav-second-level' aria-expanded='false'>
<li><a href='/network' style='font-weight: 500; color: #fff'>Provider</a></li>
<li><a href='/network/prefix' style='font-weight: 500; color: #fff'>Prefix</a></li>
    </ul>
</li>




          <li><a href='javascript: void(0);'>
            <i class='fas fa-mobile-alt'></i>
            <span> Airtime </span></a>
<ul class='nav-second-level' aria-expanded='false'>
<li><a href='/airtime' style='font-weight: 500; color: #fff'>Type</a></li>
<li><a href='/airtime/code' style='font-weight: 500; color: #fff'>Code</a></li>
<li><a href='/airtime/discount' style='font-weight: 500; color: #fff'>Discount</a></li>
        </ul>
    </li>




          <li><a href='javascript: void(0);'>
            <i class='fas fa-wifi'></i>
            <span> Data </span></a>
<ul class='nav-second-level' aria-expanded='false'>
<li><a href='/data' style='font-weight: 500; color: #fff'>Plan</a></li>
<li><a href='/data/code' style='font-weight: 500; color: #fff'>Code</a></li>
<li><a href='/data/price' style='font-weight: 500; color: #fff'>Price</a></li>
<li><a href='/data/ordering' style='font-weight: 500; color: #fff'>Ordering</a></li>
        </ul>
    </li>




    <li><a href='javascript: void(0);'>
        <i class='fab fa-google-wallet'></i>
        <span> Airtime - Cash </span></a>
<ul class='nav-second-level' aria-expanded='false'>
<li><a href='/airtime-cash' style='font-weight: 500; color: #fff'>Number</a></li>
<li><a href='/airtime-cash/rate' style='font-weight: 500; color: #fff'>Rate</a></li>
    </ul>
</li>






          <li> <a href='javascript: void(0);'>
                            <i class='fas fa-tv'></i>
                            <span> Cable </span></a>
          <ul class='nav-second-level' aria-expanded='false'>
          <li><a href='/cable' style='font-weight: 500; color: #fff'>Tv</a></li>
          <li><a href='/cable/plan' style='font-weight: 500; color: #fff'>Plan</a></li>
          <li><a href='/cable/code' style='font-weight: 500; color: #fff'>Code</a></li>
          <li><a href='/cable/charge' style='font-weight: 500; color: #fff'>Charge</a></li>
          <li><a href='/cable/ordering' style='font-weight: 500; color: #fff'>Ordering</a></li>
                        </ul></li>




          <li><a href='javascript: void(0);'>
            <i class='fas fa-lightbulb'></i>
            <span> Bills </span></a>
<ul class='nav-second-level' aria-expanded='false'>
<li><a href='/bills' style='font-weight: 500; color: #fff'>Disco</a></li>
<li><a href='/bills/code' style='font-weight: 500; color: #fff'>Code</a></li>
<li><a href='/bills/charge' style='font-weight: 500; color: #fff'>Charge</a></li>
        </ul>
    </li>



  <li><a href='javascript: void(0);'>
                            <i class='fas fa-graduation-cap'></i>
                            <span> Result Checker </span></a>
                <ul class='nav-second-level' aria-expanded='false'>
      <li><a href='/exam' style='font-weight: 500; color: #fff'>Exam</a></li>
     <li><a href='/exam/pin' style='font-weight: 500; color: #fff'>Pin</a></li>
     <li><a href='/exam/price' style='font-weight: 500; color: #fff'>Price</a></li>
                        </ul>
                    </li>


                    <li> <a href='/bulk-sms'>
                        <i class='fas fa-sms'></i>
                        <span> Bulk SMS</span>
                      </a></li>



<li><a href='javascript: void(0);'>
                            <i class='ti ti-face-smile'></i>
                            <span> Smile </span></a>
                <ul class='nav-second-level' aria-expanded='false'>

                    <li>
                        <a href="javascript: void(0);" style='font-weight: 500; color: #fff'>Bundle <span class="menu-arrow"></span></a>

                        <ul class="nav-third-level nav" aria-expanded="false">
                            <li>
                                <a href="/smile/bundle" style='font-weight: 500; color: #fff'>Plan</a>
                            </li>
                            <li>
                                <a href="/smile/bundle/code" style='font-weight: 500; color: #fff'>Code</a>
                            </li>
                            <li>
                                <a href="/smile/bundle/price" style='font-weight: 500; color: #fff'>Price</a>
                            </li>
                        </ul>
                    </li>

                    <li>
                        <a href="javascript: void(0);" style='font-weight: 500; color: #fff'>Recharge <span class="menu-arrow"></span></a>

                        <ul class="nav-third-level nav" aria-expanded="false">
                            <li>
                                <a href="javascript: void(0);" style='font-weight: 500; color: #fff'>Unavailable</a>
                            </li>
                        </ul>

                        </ul>
</li>






                    <li> <a href='/spectranet'>
                        <i class='fas fa-fire'></i>
                        <span> Spectranet </span>
                    </a></li>








<li> <a href='javascript: void(0);'>
                            <i class='fas fa-qrcode'></i>
                            <span> Recharge Card </span></a>
                <ul class='nav-second-level' aria-expanded='false'>
      <li><a href='/recharge/range' style='font-weight: 500; color: #fff'>Range</a></li>
      <li><a href='/recharge/charge' style='font-weight: 500; color: #fff'>Charge</a></li>
    <li><a href='/recharge/pin' style='font-weight: 500; color: #fff'>Pin</a></li>
                        </ul>
                    </li>




    <li><a href='javascript: void(0);'>
                <i class='fas fa-ellipsis-h'></i>
                <span> Coupon </span></a>
    <ul class='nav-second-level' aria-expanded='false'>
    <li><a href='/coupon/funding' style='font-weight: 500; color: #fff'>Funding</a></li>
    
            </ul>
        </li>


        <li><a href='javascript: void(0);'>
            <i class='fab fa-amazon-pay'></i>
            <span> Payment Gateway </span></a>
<ul class='nav-second-level' aria-expanded='false'>
<li><a href='/gateway/paystack' style='font-weight: 500; color: #fff'>Paystack</a></li>
<li><a href='/gateway/monnify' style='font-weight: 500; color: #fff'>Monnify</a></li>
<li><a href='/monnify/virtual-account' style='font-weight: 500; color: #fff'>Virtual Accounts</a></li>
        </ul>
    </li>



    <li>
        <a href="/sim/pin">
            <i class="fas fa-sim-card"></i>
            <span> SIM </span>
<span class="badge badge-primary badge-pill float-right">Pin</span>
        </a>
    </li>



    <li>
        <a href="/bank/account">
            <i class="fas fa-location-arrow"></i>
            <span> Bank Account </span>
        </a>
    </li>



<li><a href='javascript: void(0);'>
                            <i class='fas fa-chalkboard-teacher'></i>
                            <span> Admin </span></a>
                <ul class='nav-second-level' aria-expanded='false'>
                <li><a href='/admin' style='font-weight: 500; color: #fff'>Manage</a></li>
                        </ul>
                    </li>




             <li>
                        <a href="javascript: void(0);">
                            <i class="fas fa-users"></i>
                            <span>Referral </span></a>
                <ul class="nav-second-level" aria-expanded="false">
    <li><a href="/referral/log" style='font-weight: 500; color: #fff'>Log</a></li>
    <li><a href="/referral/earning" style='font-weight: 500; color: #fff'>Earnings</a></li>
    <li><a href="/referral/commission" style='font-weight: 500; color: #fff'>Commission</a></li>
                      </ul>
                    </li>

                    <li> <a href="/whatsapp">
                        <i class="fab fa-whatsapp"></i>
                        <span> Whatsapp </span>
                      </a></li>

      <li> <a href="/reset-password">
            <i class="fas fa-key"></i>
            <span> Change Password </span>
          </a></li>


      <li> <a href="/logout">
            <i class="fas fa-power-off"></i>
            <span> Log Out </span>
          </a></li>


                    <li class="menu-title mt-2">03Developers</li>

                </ul>

            </div>
            <!-- End Sidebar -->

            <div class="clearfix"></div>

        </div>
        <!-- Sidebar -left -->

    </div>
    <!-- Left Sidebar End -->

    <div class="content-page">
<?php /**PATH /home/xdatyzyi/booda-classic.classicplug.com/resources/views/layout/nav.blade.php ENDPATH**/ ?>