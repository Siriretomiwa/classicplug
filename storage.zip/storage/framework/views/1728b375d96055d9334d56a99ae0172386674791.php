<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="content">
    <!-- Start Content-->
         <div class="container-fluid">
          <!-- start page title -->
             <div class="row">
                 <div class="col-12">
                     <div class="page-title-box">
                         <div class="page-title-right">
                             <ol class="breadcrumb m-0">
                                 <li class="breadcrumb-item"><a href="javascript: void(0);">admin</a></li>
                                 <li class="breadcrumb-item"><a href="javascript: void(0);">home</a></li>
                             </ol>
                         </div>
                         <h4 class="page-title"> Dashboard </h4>
                     </div>
                 </div>
             </div>
             <!-- end page title -->
     </div> <!-- end container-fluid -->
</div> <!-- end content -->



<div class="row">
    <div class="col-md-6 col-xl-3">
        <div class="card-box tilebox-one">
            
            <img src="/images/wallet-icon.png" width="50" style="box-shadow: rgb(149 157 165 / 20%) 0px 8px 24px; padding: 8px; border-radius: 50%;" class="float-right m-0 h2 text-muted" />
            <h6 class="text-muted text-uppercase mt-0"><b>Balance</b></h6>
            <h3 class="my-3">&#8358;<span data-plugin="counterup"> <?php echo e($wallet); ?> </span></h3>
            <span class="badge badge-success mr-1" style="background: #009688"> Wallet </span> <span class="text-muted">Users Balance</span>
        </div>
    </div>


    <div class="col-md-6 col-xl-3">
        <div class="card-box tilebox-one">
            
            <img src="/images/shopping-cart.png" width="50" style="box-shadow: rgb(149 157 165 / 20%) 0px 8px 24px; padding: 8px; border-radius: 50%;" class="float-right m-0 h2 text-muted" />
            <h6 class="text-muted text-uppercase mt-0"><b>Transactions</b></h6>
            <h3 class="my-3"><span data-plugin="counterup"><?php echo e($transactions["all"]); ?></span></h3>
            <span class="badge badge-danger mr-1" style="background: #f44336"> Orders </span> <span class="text-muted">All Transactions</span>
        </div>
    </div>

    <div class="col-md-6 col-xl-3">
        <div class="card-box tilebox-one">
            
            <img src="/images/third-party.png" width="50" style="box-shadow: rgb(149 157 165 / 20%) 0px 8px 24px; padding: 8px; border-radius: 50%;" class="float-right m-0 h2 text-muted" />
            <h6 class="text-muted text-uppercase mt-0"><b>Commission</b></h6>
            <h3 class="my-3">&#8358;<span data-plugin="counterup"> <?php echo e($commission); ?> </span></h3>
            <span class="badge badge-pink mr-1" style="background: #3f51b5"> Referral </span> <span class="text-muted">All commission</span>
        </div>
    </div>


    <div class="col-md-6 col-xl-3">
        <div class="card-box tilebox-one">
            
            <img src="/images/user_avatar.png" width="50" style="box-shadow: rgb(149 157 165 / 20%) 0px 8px 24px; padding: 8px; border-radius: 50%;" class="float-right m-0 h2 text-muted" />
            <h6 class="text-muted text-uppercase mt-0"><b>Users</b></h6>
            <h3 class="my-3" data-plugin="counterup"><?php echo e($user); ?></h3>
            <span class="badge badge-warning mr-1" style="background: #ff9800"> users </span> <span class="text-muted">All registered user</span>
        </div>
    </div>






    <div class="col-md-6">
        <div class="card-box">
            <h4 class="header-title mb-3">Recent Transactions</h4>
            <div class="table-responsive">
                <table class="table table-bordered table-nowrap mb-0">
                    <thead>
                        <tr>
                            <th>Username</th>
                            <th>Description</th>
                            <th>Amount</th>
                        </tr>
                    </thead>
                    <tbody>


                        <?php $__currentLoopData = $transactions["data"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tranx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <th class="text-muted"> <?php echo e($tranx->username); ?> </th>
                            <td> <?php echo e($tranx->description); ?> </td>
                            <td> &#8358;<?php echo e($tranx->amount); ?> </td>
                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div><!-- end col-->




    <div class="col-md-6">
        <div class="card-box">
            <h4 class="header-title mb-3">Transactions Status</h4>
            <div class="table-responsive">
                <table class="table table-bordered table-nowrap mb-0">
                    <thead>
                        <tr>
                            <th>Successful</th>
                            <th>Pending</th>
                            <th>Cancelled</th>
                            <th>Reversed</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <th class="text-muted"><span class="badge badge-success"><?php echo e($transactions["success"]); ?></span></th>
                            <td><span class="badge badge-warning"><?php echo e($transactions["pending"]); ?></span></td>
                            <td><span class="badge badge-danger"><?php echo e($transactions["cancelled"]); ?></span></td>
                            <td><span class="badge badge-primary"><?php echo e($transactions["reversed"]); ?></span></td>
                        </tr>

                    </tbody>
                </table>
            </div>
        </div>
    </div><!-- end col-->






<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/xdatyzyi/backend.classicplug.com/resources/views/home.blade.php ENDPATH**/ ?>