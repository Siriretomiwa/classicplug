<!-- Footer Start -->
          <footer class="footer">
              <div class="container-fluid">
                  <div class="row">
                      <div class="col-md-12">
                           <b>&copy By 03Developers</b>
                      </div>
                  </div>
              </div>
          </footer>
          <!-- end Footer -->

      </div>

      <!-- ============================================================== -->
      <!-- End Page content -->
      <!-- ============================================================== -->

  </div>


  <!-- END wrapper -->

  <!-- Vendor js -->
  <script src="/assets/js/vendor.min.js"></script>
  <!-- App js -->
  <script src="/assets/js/app.min.js"></script>
      <!-- Sweet Alerts js -->
  <script src="/assets/libs/sweetalert2/sweetalert2.min.js"></script>

  <!-- Sweet alert init js-->
  <script src="/assets/js/pages/sweet-alerts.init.js"></script>
  
  <script src="/assets/izitoast/iziToast.js"></script>
    <script src="/assets/izitoast/iziToast.min.js"></script>

    <script src="/assets/js/overlay.js"></script>

    <script type="text/javascript" src="/chartjs/Chart.min.js"></script>
    
    <script src="/assets/toastr/toastr.js"></script>

        <!-- Datatable plugin js -->
        <script src="/assets/libs/datatables/jquery.dataTables.min.js"></script>
        <script src="/assets/libs/datatables/dataTables.bootstrap4.min.js"></script>

        <script src="/assets/bootstrap-toggle/js/bootstrap4-toggle.min.js"></script>


        
        

        


</body>
</html>

<?php /**PATH /home/xdatyzyi/booda-classic.classicplug.com/resources/views/layout/footer.blade.php ENDPATH**/ ?>