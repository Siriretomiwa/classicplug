<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="/ajax/transaction/limit.js"> </script>
<?php echo $__env->make('layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="content">
               <!-- Start Content-->
                    <div class="container-fluid">
                     <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">admin</a></li>
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">home</a></li>
                                        </ol>
                                    </div>
                                    <h4 class="page-title">Dashboard</h4>
                                </div>
                            </div>
                        </div>
                        <!-- end page title -->
                </div> <!-- end container-fluid -->
          </div> <!-- end content -->


				<div class="row">
                    <div class="col-12">
                                <div class="card-box">


                                    <div class="container" style="margin-bottom: 50px">
                                    <span class="header-title" style="float: left">Transaction Limit</span>
									   <span class="" style="float: right">

                                       </span>
                                    </div>

                                    <hr/>


                                    <form method="post" action="#">



                            <div class="form-group">
                                <label for="">Non-verified users *</label>
                                <input type="number" class="form-control form-white" id="unverified"
                                            placeholder="Enter max limit for non verified users"
                                            value=<?php echo e($limits !== null ? $limits->unverified : null); ?>>
                                                    </div>





                                    <div class="form-group">
                                    <label for="">Verified Users</label>
                                    <input type="number" class="form-control form-white" id="verified"
                                                placeholder="Enter max limit for verified users | leave empty for unlimited"
                                                value=<?php echo e($limits !== null ? $limits->verified : null); ?>>
                                        </div>



                        <button  id="save" class="btn btn-secondary btn-block waves-effect waves-light">
                            <span id="btn-spinner"></span> <span id="btn-txt"> Save </span> </button>

    </form>


                                </div><!-- end col -->






                            </div>
						</div>
                        </div>
                        <!-- end row -->







<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\laravel\vtu-admin\resources\views/transaction/limit.blade.php ENDPATH**/ ?>