<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="/ajax/host/hostswitch.js"> </script>
<?php echo $__env->make('layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="content">
               <!-- Start Content-->
                    <div class="container-fluid">
                     <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">admin</a></li>
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">home</a></li>
                                        </ol>
                                    </div>
                                    <h4 class="page-title">Dashboard</h4>
                                </div>
                            </div>
                        </div>
                        <!-- end page title -->
                </div> <!-- end container-fluid -->
          </div> <!-- end content -->


				<div class="row">
                    <div class="col-12">
                                <div class="card-box" style="border: 1px solid white;">


                                    <div class="container" style="margin-bottom: 50px">
                                    <span class="header-title" style="float: left">Host Switch</span>
									   <span class="" style="float: right">
                      

                      <img src="/images/api.png" alt="#" width="40px" class="avatar-img rounded-circle">
                    </span>
                                    </div>

                                    <hr/>



                                    <div class="row">
                                        <div class="col-xl-6">
                                            <form method="post" action="#">

											<div class="form-group">
                                  <label for="">Service </label>
                                      <select class="form-control form-white" id="service" required>
									<option value=""> Please select </option>
										<option value="AIRTIME"> Airtime Topup </option>
										<option value="DATA"> Data Topup </option>
										<option value="CABLE"> Cable Subscription </option>
										<option value="ELECTRICITY"> Bill Payment </option>
                                        <option value="SMILE"> Smile Bundle </option>
                                        <option value="SPECTRANET"> Spectranet </option>
												</select>
                                                   </div>







                                        <div class="form-group" id="network_div" hidden>
                                        <label for="">Network </label>
                                            <select class="form-control form-white" id="network" required>
                                            <option value=""> Please select </option>
                                            <?php if($networks->count() !== 0): ?>
                                            <?php $__currentLoopData = $networks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $network): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($network->name); ?>"> <?php echo e($network->name); ?> </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                            </select>
                                        </div>







                                        </div><!-- end col -->






                                        <div class="col-xl-6">
                                            <form method="post" action="#">

											<div class="form-group" id="type_div" hidden>
                                  <label for="">Type </label>
                                      <select class="form-control form-white" id="type" required>
									<option value=""> Please select </option>
												</select>
                                                   </div>




                                    <div class="form-group">
                                    <label for="">Host / Delivery Mode </label>
                                        <select class="form-control form-white" id="host" required>
                                        <option value=""> Please select </option>
                                        <?php if($hosts->count() !== 0): ?>
                                        <?php $__currentLoopData = $hosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $host): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($host->name); ?>"> <?php echo e($host->name); ?> </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                            </select>
                                    </div>




                                        </div><!-- end col -->




                                        <div class="form-group col-lg-12" id="phone-div" hidden>
                                            <label for="">Number to receive order </label>
        <input type="number" class="form-control" id="phone_number" placeholder="Enter phone number to receive order">

                                                             </div>






											</form>

                                                    </div>


                        <a href="#" id="save" class="btn btn-secondary btn-block waves-effect waves-light" style="margin-top: 15px"> <span id="btn-spinner"></span> <span id="btn-txt"> Save </span> </a>



                                                    <hr/>



                                                    <div class="table-responsive">
                                                        <div id="tableContainer"> </div>

                                                </div>


                                        </div>




                                    </div>
                                    </div>









                            </div>
						</div>
                        </div>
                        <!-- end row -->












<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/xdatyzyi/booda-classic.classicplug.com/resources/views/host/hostswitch.blade.php ENDPATH**/ ?>