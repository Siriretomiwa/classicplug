<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="/ajax/auth.js"> </script>

<div class="account-pages pt-5 my-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6 col-xl-5">
                <div class="account-card-box">
                    <div class="card mb-0" style="border: 3px solid #a1a1a147 !important">
                        <div class="card-body p-4">

                            <div class="text-center">
                                <div class="my-3">
                                    <a href="#">
                 <span> <img src="/images/03developer.jpeg" alt="" height="60" style="border: 1px solid #fff; border-radius: 50%"></span>
                                    </a>
                                </div>
                                <h5 class="text-muted text-uppercase py-1 font-16"><b>Sign In</b></h5>
                            </div>

                            <form method="post" class="mt-2">

                                <div class="form-group mb-3">
                     <input class="form-control form-white" maxlength="100" type="text" autocomplete="off" placeholder="Enter your username" id="username">
                                </div>

                                <div class="form-group mb-3">
                     <input class="form-control form-white" maxlength="100" type="password" autocomplete="off" id="password" placeholder="Enter your password">
                                </div>

                                                </form>

                                <div class="form-group text-center">
         <button class="btn btn-secondary btn-block waves-effect waves-light" id="login" type="submit"> Login </button>
                                </div>



                        </div> <!-- end card-body -->
                    </div>
                    <!-- end card -->
                </div>



            </div> <!-- end col -->
        </div>
        <!-- end row -->
    </div>
    <!-- end container -->
</div>



<script>
    $(document).ready(function(){
        $('#login').on('click', function(e){
             e.preventDefault();
        });

        login();
    });
</script>

<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/xdatyzyi/backend.classicplug.com/resources/views/auth/login.blade.php ENDPATH**/ ?>