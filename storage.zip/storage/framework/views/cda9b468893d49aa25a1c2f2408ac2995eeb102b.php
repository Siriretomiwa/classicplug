<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="/ajax/referral/commission.js"> </script>
<?php echo $__env->make('layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="content">
               <!-- Start Content-->
                    <div class="container-fluid">
                     <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">admin</a></li>
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">home</a></li>
                                        </ol>
                                    </div>
                                    <h4 class="page-title">Dashboard</h4>
                                </div>
                            </div>
                        </div>
                        <!-- end page title -->
                </div> <!-- end container-fluid -->
          </div> <!-- end content -->


				<div class="row">
                    <div class="col-12">
                                <div class="card-box">


                                    <div class="container" style="margin-bottom: 50px">
                                    <span class="header-title" style="float: left">Commission</span>
									   <span class="" style="float: right">

                                       </span>
                                    </div>

                                    <hr/>


                                    <form method="post" action="#">



											<div class="form-group">
                                                <label for="">Referral Bonus [User Upgrade] *</label>
                                                <input type="number" class="form-control form-white" id="bonus"
                                                           placeholder="Enter referral bonus | leave blank or 0 to disable"
                                                           value=<?php echo e($referral !== null ? $referral->bonus : null); ?>>
                                            </div>


                                            <div class="form-group">
                                                <label for="">Subsequent Bonus [On Transaction] *</label>
                                                <input type="number" class="form-control form-white" id="subsequent_bonus"
                                                           placeholder="Enter subsequent bonus | leave blank or 0 to disable"
                                                        
                                            </div>


                                            <div class="form-group">
                                                <label> Subsequent Bonus Type </label>
                                                    <select class="form-control form-white" id="bonus_type" required>
                                                        <?php if(isset($referral->bonus_type) && $referral->bonus_type == "percentage"): ?>
                                                            <option value="percentage"> Percentage </option>
                                                            <option value="naira"> Naira </option>
                                                        <?php else: ?>
                                                            <option value="naira"> Naira </option>
                                                            <option value="percentage"> Percentage </option>

                                                        <?php endif; ?>

                                                    </select>
                                                </div>


                                                        <div class="form-group">
                                                <label for="">Minimum withdrawal to wallet *</label>
                                                <input type="number" class="form-control form-white" id="minimum_withdrawal"
                                                        placeholder="Enter minimum amount users can withdraw to wallet"
                                                        
                                                </div>


                                    <button  id="submit" class="btn btn-secondary btn-block waves-effect waves-light"> <span id="btn-spinner"></span> <span id="btn-txt"> Save </span> </button>

                                </form>


                                </div><!-- end col -->






                            </div>
						</div>
                        </div>
                        <!-- end row -->







<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/xdatyzyi/backend.classicplug.com/resources/views/referral/commission.blade.php ENDPATH**/ ?>