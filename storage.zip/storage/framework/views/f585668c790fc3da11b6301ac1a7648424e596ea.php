<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="/ajax/transaction/transaction.js"> </script>
<style>
    .list_padding {
        padding: 12px 10px;
    }
</style>

<?php echo $__env->make('layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="content">
               <!-- Start Content-->
                    <div class="container-fluid">
                     <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">admin</a></li>
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">home</a></li>
                                        </ol>
                                    </div>
                                    <h4 class="page-title">Dashboard</h4>
                                </div>
                            </div>
                        </div>
                        <!-- end page title -->
                </div> <!-- end container-fluid -->
          </div> <!-- end content -->




				<div class="row">
                    <div class="col-12">
                                <div class="card-box" style="border: 1px solid white;">


                                    <div class="container" style="margin-bottom: 50px">
                                    <span class="header-title" style="float: left">Transaction(s)</span>

                                    </div>
                        <hr/>


            
                        <div class="row">
                            <div class="col">
                                <label class="control-label">Action</label>
                 <select class="form-control form-white" id="action">
                    <option value="">Please select</option>
                    <option value="success"> Success </option>
                    <option value="pending"> Pending </option>
                    <option value="processing"> Processing </option>
                    <option value="cancel"> Cancel </option>
                    <option value="reversed"> Reverse </option>
                    <option value="delete"> Delete </option>
                                    </select>
                            </div>


<div class="col">
<a href="#" id="apply" class="btn btn-secondary btn-block waves-effect waves-light text-white" style="margin-top: 35px; font-weight: 600;">
    <span id="applybtn-spinner"></span> <span id="applybtn-txt"> Apply </span> </a>
</div>
                            </div>




			<div class="row mb-3">
				<div class="col-md-4">
                            <label> Search </label>
                            <input class="form-control form-white" id="search" type="text" placeholder="Searching for something? Try 'mtn'">
                        </div>


			<div class="col-md-4">
				<label> Filter </label>
                    <select class="form-control form-white" id="filter" required>
                        <option value="All"> All </option>
                        <option value="Debit"> Debit </option>
                        <option value="Credit"> Credit </option>
                        <option value="success"> Success </option>
                        <option value="pending"> Pending </option>
                        <option value="processing"> Processing </option>
                        <option value="cancel"> Cancel </option>
                        <option value="reversed"> Reversed </option>
                        <option value="Airtime Topup"> Airtime Topup </option>
                        <option value="Data Topup"> Data Topup </option>
                        <option value="Cable Subscription"> Cable Subscription </option>
                        <option value="Bills Payment"> Bill Payment </option>
                        <option value="Result Checker "> Result Checker </option>
                        <option value="Wallet Funding"> Wallet Funding </option>
                    </select>
				</div>



                <div class="col-md-4">
                    <label> Entries </label>
                        <select class="form-control form-white" id="entries" required>
                            <option value="12"> 12 </option>
                            <option value="25"> 25 </option>
                            <option value="50"> 50 </option>
                            <option value="100"> 100 </option>
                            <option value="150"> 150 </option>
                            <option value="200"> 200 </option>
                        </select>
                    </div>


		    </div>





<div style="display: flex; justify-content: space-between;">
    <div class="checkbox checkbox-success checkbox-circle">
            <input type="checkbox" id="actions_checkbox" class="all_actions">
            <label for="actions_checkbox" style="font-weight: 600">All Actions</label>
    </div>



    <div class="checkbox checkbox-primary checkbox-circle">
        <input id="full_details" type="checkbox" class="view_all">
        <label for="full_details" style="font-weight: 600">Full Details</label>
    </div>

</div>

                            </div>
						</div>
                        </div>
                        <!-- end row -->






                        <div class="table-responsive">
                                <div id="tableContainer"> </div>
                            </div>








                                <div class="modal fade none-border" id="update">
                                    <div class="modal-dialog">
                                        <div class="modal-content" style="border: none">
                                            <div class="modal-header">
                                                <h5 class="modal-title">Transaction Update</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                            </div>
                                            <div class="modal-body p-3">
                                                <form>
								 <p id="message" class="text-center text-danger"></p>
                                                    <div class="row">

		<input class="form-control form-white" id="data_id" hidden readonly placeholder="ID" type="text" required />


										<div class="col-md-6">
                                                <label class="control-label">Username</label>
			<input class="form-control form-white" id="username_" placeholder="Username" type="text" readonly required />
                                                        </div>


					<div class="col-md-6">
                                                <label class="control-label">Email</label>
			<input class="form-control form-white" id="email_" placeholder="Email" type="text" readonly required />
                                                        </div>


											<div class="col-md-6">
                                            <label class="control-label">Service</label>
					<input class="form-control form-white" id="service_" readonly placeholder="Service" type="text"/>
                                                        </div>


											<div class="col-md-6">
                                 <label class="control-label">Provider</label>
					<input class="form-control form-white" id="service_provider_" placeholder="Service Provider" type="text"/>
                                                        </div>


								<div class="col-md-6">
                            <label class="control-label">Description</label>
                       <input class="form-control form-white" id="description_" placeholder="Description" type="text" required />
                                                        </div>




											<div class="col-md-6">
                            <label class="control-label">Amount</label>
                       <input class="form-control form-white" id="amount_" placeholder="Amount" type="number" required />
                                                        </div>


											<div class="col-md-6">
                            <label class="control-label">Type</label>
                            <select class="form-control form-white" id="type_" required>
                                <option value="Credit"> Credit </option>
                                <option value="Debit"> Debit </option>
                            </select>
                                                        </div>


											<div class="col-md-6">
                            <label class="control-label">Reference</label>
                       <input class="form-control form-white" id="reference_" placeholder="Reference" type="text" required />
                                                        </div>



                                                    </div>
                                                </form>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary waves-effect" data-dismiss="modal" id="form_cancel">Cancel</button>
                                                <button type="button" class="btn btn-danger waves-effect waves-light save-category" id="update-tranx"> <span id="update_btn-spinner"></span> <span id="update_btn-txt"> Update </span></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- END MODAL -->






<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/xdatyzyi/backend.classicplug.com/resources/views/transaction/transaction.blade.php ENDPATH**/ ?>