<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="/ajax/gateway/paystack.js"> </script>
<?php echo $__env->make('layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="content">
               <!-- Start Content-->
                    <div class="container-fluid">
                     <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">admin</a></li>
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">home</a></li>
                                        </ol>
                                    </div>
                                    <h4 class="page-title">Dashboard</h4>
                                </div>
                            </div>
                        </div>
                        <!-- end page title -->
                </div> <!-- end container-fluid -->
          </div> <!-- end content -->


				<div class="row">
                    <div class="col-12">
                                <div class="card-box">


                                    <div class="container" style="margin-bottom: 50px">
                                    <span class="header-title" style="float: left">Paystack</span>
									   <span class="" style="float: right">

                                       </span>
                                    </div>

                                    <hr/>


                                    <form method="post" action="#">



											<div class="form-group">
                                                <label for="">Paystack Secret Key *</label>
                                                <input type="text" class="form-control form-white" id="secret_key"
                                                           placeholder="Enter Your Paystack Secret Key"
                                                           value=<?php echo e($paystack !== null ? $paystack->secret_key : null); ?>>
                                                                 </div>

                                                    <div class="form-group">
                                                    <label for="">Paystack Public Key [Optional]</label>
                                                    <input type="text" class="form-control form-white" id="public_key"
                                                                placeholder="Enter Your Paystack public Key"
                                                                value=<?php echo e($paystack !== null ? $paystack->public_key : null); ?>>
                                                                        </div>

                                                          <div class="form-group">
                                              <label for="">What percent will you like to charge on paystack card Funding(%)*</label>
                                              <input type="number" class="form-control form-white" id="charge"
                                               placeholder="What percent will you like to charge on paystack Funding(%)"
                                               value=<?php echo e($paystack !== null ? $paystack->charge : null); ?>>
                                                                 </div>


                                                <div class="form-group">
                                                <label class="control-label">Status</label>
                                                <select class="form-control form-white" id="status" required>
                                                    <?php if(isset($paystack->status) && $paystack->status == "unavailable"): ?>
                                                        <option value="unavailable">Unavailable</option>
                                                        <option value="available">Available</option>
                                                    <?php else: ?>
                                                        <option value="available">Available</option>
                                                        <option value="unavailable">Unavailable</option>

                                                    <?php endif; ?>
                                                    </select>
                                            </div>


        <button  id="paystack" class="btn btn-secondary btn-block waves-effect waves-light"> <span id="btn-spinner"></span> <span id="btn-txt"> Save </span> </button>

    </form>


                                </div><!-- end col -->






                            </div>
						</div>
                        </div>
                        <!-- end row -->







<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/xdatyzyi/backend.classicplug.com/resources/views/gateway/paystack.blade.php ENDPATH**/ ?>