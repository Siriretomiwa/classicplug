<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="/ajax/gateway/vpay.js"> </script>
<?php echo $__env->make('layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="content">
           <!-- Start Content-->
                <div class="container-fluid">
                 <!-- start page title -->
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item"><a href="javascript: void(0);">admin</a></li>
                                        <li class="breadcrumb-item"><a href="javascript: void(0);">home</a></li>
                                    </ol>
                                </div>
                                <h4 class="page-title">Dashboard</h4>
                            </div>
                        </div>
                    </div>
                    <!-- end page title -->
            </div> <!-- end container-fluid -->
      </div> <!-- end content -->


			<div class="row">
                <div class="col-12">
                            <div class="card-box">


                                <div class="container" style="margin-bottom: 50px">
                                <span class="header-title" style="float: left">Vpay</span>
								   <span class="" style="float: right">

                                   </span>
                                </div>

                                <hr/>


                                <form method="post" action="#">



										<div class="form-group">
                                            <label for="">Vpay Secret Key *</label>
                                            <input type="text" class="form-control form-white" id="secret_key"
                                                       placeholder="Enter Your Vpay Secret Key"
                                                       value=<?php echo e($vpay !== null ? $vpay->secret_key : null); ?>>
                                                             </div>

                                                <div class="form-group">
                                                <label for="">Vpay Public Key [Optional]</label>
                                                <input type="text" class="form-control form-white" id="public_key"
                                                            placeholder="Enter Your Vpay public Key"
                                                            value=<?php echo e($vpay !== null ? $vpay->public_key : null); ?>>
                                                                    </div>

                                                      <div class="form-group">
                                          <label for="">What percent will you like to charge on Vpay card Funding(%)*</label>
                                          <input type="number" class="form-control form-white" id="charge"
                                           placeholder="What percent will you like to charge on Vpay Funding(%)"
                                           value=<?php echo e($vpay !== null ? $vpay->charge : null); ?>>
                                                             </div>


                                            <div class="form-group">
                                            <label class="control-label">Status</label>
                                            <select class="form-control form-white" id="status" required>
                                                <?php if(isset($vpay->status) && $vpay->status == "unavailable"): ?>
                                                    <option value="unavailable">Unavailable</option>
                                                    <option value="available">Available</option>
                                                <?php else: ?>
                                                    <option value="available">Available</option>
                                                    <option value="unavailable">Unavailable</option>

                                                <?php endif; ?>
                                                </select>
                                        </div>


    <button  id="vpay" class="btn btn-secondary btn-block waves-effect waves-light"> <span id="btn-spinner"></span> <span id="btn-txt"> Save </span> </button>

</form>


                            </div><!-- end col -->






                        </div>
					</div>
                    </div>
                    <!-- end row -->







<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/xdatyzyi/backend.classicplug.com/resources/views/gateway/vpay.blade.php ENDPATH**/ ?>