<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="/ajax/kyc/verification.js"> </script>
<style>
    .list_padding {
        padding: 12px 10px;
    }
</style>

<?php echo $__env->make('layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="content">
               <!-- Start Content-->
                    <div class="container-fluid">
                     <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">admin</a></li>
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">home</a></li>
                                        </ol>
                                    </div>
                                    <h4 class="page-title">Dashboard</h4>
                                </div>
                            </div>
                        </div>
                        <!-- end page title -->
                </div> <!-- end container-fluid -->
          </div> <!-- end content -->




				<div class="row">
                    <div class="col-12">
                                <div class="card-box" style="border: 1px solid white;">


                                    <div class="container" style="margin-bottom: 50px">
                                    <span class="header-title" style="float: left">KYC</span>

                                    </div>
                        <hr/>



			<div class="row mb-3">
				<div class="col-md-6">
                            <label> Search </label>
                            <input class="form-control form-white" id="search" type="text" placeholder="Enter username">
                        </div>


                <div class="col-md-6">
                    <label> Entries </label>
                        <select class="form-control form-white" id="entries" required>
                            <option value="10"> 10 </option>
                            <option value="25"> 25 </option>
                            <option value="50"> 50 </option>
                            <option value="100"> 100 </option>
                            <option value="150"> 150 </option>
                            <option value="200"> 200 </option>
                        </select>
                    </div>


		    </div>



                            </div>
						</div>
                        </div>
                        <!-- end row -->






                        <div class="table-responsive">
                                <div id="tableContainer"> </div>
                            </div>







<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/xdatyzyi/booda-classic.classicplug.com/resources/views/kyc/verification.blade.php ENDPATH**/ ?>