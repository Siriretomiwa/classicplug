<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="/ajax/user/user.js"> </script>
<?php echo $__env->make('layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="content">
               <!-- Start Content-->
                    <div class="container-fluid">
                     <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">admin</a></li>
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">home</a></li>
                                        </ol>
                                    </div>
                                    <h4 class="page-title">Dashboard</h4>
                                </div>
                            </div>
                        </div>
                        <!-- end page title -->
                </div> <!-- end container-fluid -->
          </div> <!-- end content -->


				<div class="row">
                    <div class="col-12">
                                <div class="card-box">


                                    <div class="container" style="margin-bottom: 50px">
                                    <span class="header-title" style="float: left">Users</span></div>

                                    <hr/>




			<div class="row mb-3">
				<div class="col-md-4">
                            <label> Search </label>
                            <input class="form-control form-white" id="search" type="text" placeholder="Searching for something? Try 'username'">
                        </div>


			<div class="col-md-4">
				<label> Filter </label>
                    <select class="form-control form-white" id="filter" required>
                        <option value="all"> All </option>
                        <option value="active"> Active </option>
                        <option value="blocked"> Blocked </option>
                    </select>
				</div>



                <div class="col-md-4">
                    <label> Entries </label>
                        <select class="form-control form-white" id="entries" required>
                            <option value="10"> 10 </option>
                            <option value="25"> 25 </option>
                            <option value="50"> 50 </option>
                            <option value="100"> 100 </option>
                            <option value="150"> 150 </option>
                            <option value="200"> 200 </option>
                        </select>
                    </div>

                </div>


                <div class="table-responsive">
                    <div id="tableContainer"> </div>



                            </div>
						</div>
                        </div>
                        <!-- end row -->



<div id="response"></div>







<div class="modal fade none-border" id="update">
    <div class="modal-dialog">
        <div class="modal-content" style="border: none">
            <div class="modal-header">
                <h5 class="modal-title">User Update</h5>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            </div>
            <div class="modal-body p-3">
                <form>
 <p id="message" class="text-center text-danger"></p>
                    <div class="row">

<input class="form-control form-white" id="data_id" hidden readonly placeholder="ID" type="text" required />


        <div class="col-md-6">
                <label class="control-label">Username</label>
<input class="form-control form-white" id="username_" placeholder="Username" type="text" readonly required />
                        </div>


<div class="col-md-6">
                <label class="control-label">Email</label>
<input class="form-control form-white" id="email_" placeholder="Email" type="text" readonly required />
                        </div>


            <div class="col-md-6">
            <label class="control-label">Firstname</label>
<input class="form-control form-white" id="firstname_" placeholder="Firstname" type="text"/>
                        </div>


            <div class="col-md-6">
 <label class="control-label">Lastname</label>
<input class="form-control form-white" id="lastname_" placeholder="Lastname" type="text"/>
                        </div>


<div class="col-md-6">
<label class="control-label">Phone Number</label>
<input class="form-control form-white" id="phone_number_" placeholder="Phone Number" type="number" required />
                        </div>




            <div class="col-md-6">
<label class="control-label">API Key </label>
<input class="form-control form-white" id="apikey_" placeholder="API Key" type="text" required />
                        </div>


            <div class="col-md-12">
<label class="control-label">Status</label>
<select class="form-control form-white" id="status_" required>
<option value="active"> Active </option>
<option value="blocked"> Blocked </option>
</select>
                        </div>


                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary waves-effect" data-dismiss="modal" id="form_cancel">Cancel</button>
                <button type="button" class="btn btn-danger waves-effect waves-light save-category" id="update-tranx"> <span id="update_btn-spinner"></span> <span id="update_btn-txt"> Update </span></button>
            </div>
        </div>
    </div>
</div>
<!-- END MODAL -->










<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/xdatyzyi/booda-classic.classicplug.com/resources/views/user/user.blade.php ENDPATH**/ ?>