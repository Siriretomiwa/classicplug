<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="/ajax/transaction/statistics.js"> </script>
<?php echo $__env->make('layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<style>
    .border_body {
    /* height: 100vh; */
    margin: 0;
    display: grid;
    place-items: center;
    /* background: #222; */
    }

    .o_three_module {
        max-width: 250px;
    padding: 1rem;
    color: black;
    border-width: 3px;
    border-style: double;
    border-image: linear-gradient( to bottom, red, rgba(0, 0, 0, 0) ) 1 100%;
    }

</style>


        <div class="content">
               <!-- Start Content-->
                    <div class="container-fluid">
                     <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">admin</a></li>
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">home</a></li>
                                        </ol>
                                    </div>
                                    <h4 class="page-title">Dashboard</h4>
                                </div>
                            </div>
                        </div>
                        <!-- end page title -->
                </div> <!-- end container-fluid -->
          </div> <!-- end content -->


				<div class="row">
                    <div class="col-12">
                                <div class="card-box">


                                    <div class="container" style="margin-bottom: 50px">
                                    <span class="header-title" style="float: left">Sales Statistics</span>
									   <span class="" style="float: right">

                                       </span>
                                    </div>

                                    <hr/>


                                    <form method="post" action="#">



                                        <div class="row">

                            <div class="form-group col-lg-6">
                                <label for="">From [start date] *</label>
                                <input type="date" class="form-control form-white" id="from_date">
                                
                                            
                                                    </div>





                                    <div class="form-group col-lg-6">
                                    <label for="">To [end date]</label>
                                    <input type="date" class="form-control form-white" id="to_date">
                                        </div>


                                        </div>

                                        <div class="form-group">
                                            <label for="">Username [optional]</label>
                                            <input type="text" class="form-control form-white" id="username"
                                                       placeholder="Enter username to get a particular user record">
                                        </div>



                        <button  id="submit" class="btn btn-secondary btn-block waves-effect waves-light">
                            <span id="btn-spinner"></span> <span id="btn-txt"> View Statistics </span> </button>

    </form>


                                </div><!-- end col -->
                            </div>




            <div id="result_cards" class="col-lg-12" hidden>
                                <div class="col-lg-12" id="data_div" >
                                    <div class="card-box">
                                        <h4 class="header-title">Data Topup Summary</h4>
                                        <p class="sub-header">
                                            Total amount of data purchased for the selected period.
                                        </p>

                                 <div id="data_response"></div>

                                 <br/>


			<div class='border_body'>
				<div class='o_three_module'>
				<div class='text-center'><b> Quantity Sold </b></div> <br/>
							<div class='table-responsive'>
                                        <table class='table table-bordered 0_three_table-bordered table-nowrap mb-0'>
                                            <thead>
                                                <tr>
                                                    <th>Network</th>
                                                    <th>GB / MB</th>


                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <th class='text-muted'><span class='badge badge-warning'> MTN </span></th>
                                                    <td><span class='text-warning'><b> <span id="mtn_data_stat"> </span> </b></span></td>
                                                </tr>


										 <tr>
                                                    <th class='text-muted'><span class='badge badge-success'> GLO </span></th>
                                                    <td><span class='text-success'><b> <span id="glo_data_stat"> </span> </b></span></td>
                                             </tr>


												<tr>
                                                    <th class='text-muted'><span class='badge badge-danger'> AIRTEL </span></th>
                                                    <td><span class='text-danger'><b> <span id="airtel_data_stat"> </span> </b></span></td>
												</tr>


											  <tr>
                                                    <th class='text-muted'><span class='badge badge-success'> 9MOBILE </span></th>
                                                    <td><span class='text-success'><b> <span id="_9mobile_data_stat"> </span> </b></span></td>
                                             </tr>


                                            </tbody>
                                        </table>
                                    </div>
				</div> </div>


<br/>
<br/>



                                 <canvas id="data_chart" width="100" height="50"></canvas>
                                   </div>
                                </div><!-- end col-->




                                <div class="col-lg-12" id="data_div" >
                                    <div class="card-box">
                                        <h4 class="header-title">Airtime Topup Summary</h4>
                                        <p class="sub-header">
                                            Total amount of airtime purchased for the selected period.
                                        </p>
                                 <div id="airtime_response">
                                 </div>
                                 <br/>
                                 <canvas id="airtime_chart" width="100" height="50"></canvas>
                                   </div>
                                </div><!-- end col-->




                                <div class="col-lg-12" id="data_div" >
                                    <div class="card-box">
                                        <h4 class="header-title">Cable Subscription Summary</h4>
                                        <p class="sub-header">
                                            Total amount of cable plan purchased for the selected period.
                                        </p>
                                 <div id="cable_response">
                                 </div>
                                 <br/>
                                 <canvas id="cable_chart" width="100" height="50"></canvas>
                                   </div>
                                </div><!-- end col-->





                                <div class="col-lg-12" id="data_div" >
                                    <div class="card-box">
                                        <h4 class="header-title">Bills Payment Summary</h4>
                                        <p class="sub-header">
                                            Total amount of bills payment made for the selected period.
                                        </p>
                                 <div id="bills_response">
                                 </div>
                                 <br/>
                                 <canvas id="bills_chart" width="100" height="50"></canvas>
                                   </div>
                                </div><!-- end col-->



</div>


						</div>
                        </div>
                        <!-- end row -->







<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/xdatyzyi/booda-classic.classicplug.com/resources/views/transaction/statistics.blade.php ENDPATH**/ ?>