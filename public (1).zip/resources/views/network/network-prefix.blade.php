@include('layout.header')
<script src="/ajax/network/network-prefix.js"> </script>
@include('layout.nav')

        <div class="content">
               <!-- Start Content-->
                    <div class="container-fluid">
                     <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">admin</a></li>
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">home</a></li>
                                        </ol>
                                    </div>
                                    <h4 class="page-title">Dashboard</h4>
                                </div>
                            </div>
                        </div>
                        <!-- end page title -->
                </div> <!-- end container-fluid -->
          </div> <!-- end content -->


				<div class="row">
                    <div class="col-12">
                                <div class="card-box" style="border: 1px solid white;">


                                    <div class="container" style="margin-bottom: 50px">
                                    <span class="header-title" style="float: left">Network Prefix</span>
									   <span class="" style="float: right">
                      {{-- <img src="images/networks.jpg" alt="#" width="40px" class="avatar-img rounded-circle"> --}}
                      <a href="#" data-toggle="modal" data-target="#add-category" class="btn btn-secondary btn-block waves-effect waves-light">
						<i class="mdi mdi-plus mr-1"></i>
                        Create <img src="/images/networks.jpg" alt="#" width="15px" class="avatar-img rounded-circle">
                    </a>
                                       </span>
                                    </div>

                                    <hr/>


            {{-- Apply Action --}}
            <div class="row">
                <div class="col">
                    <label class="control-label">Action</label>
     <select class="form-control form-white" id="action">
                        <option value="">Please select</option>
                        <option value="delete">Delete</option>

                        </select>
                </div>


<div class="col">
<a href="#" id="apply" class="btn btn-outline-primary btn-block waves-effect waves-light" style="margin-top: 35px"> <span id="applybtn-spinner"></span> <span id="applybtn-txt"> Apply </span> </a>
</div>
                </div>


{{-- Apply Action  --}}

<br/>





                                    <div class="table-responsive">
                                        <div id="tableContainer"> </div>

                                </div>

                            </div>
						</div>
                        </div>
                        <!-- end row -->


                                <!-- Modal Add Category -->
                                <div class="modal fade none-border" id="add-category">
                                    <div class="modal-dialog">
                                        <div class="modal-content" style="border: 2px solid darkgrey;">
                                            <div class="modal-header" style="border-bottom: 2px solid darkgrey;">
                                                <h5 class="modal-title">Network Prefix</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                            </div>
                                            <div class="modal-body p-3">
                                                <form id="form">
								 <p id="message" class="text-center text-danger"></p>
                                                    <div class="row">


                                                        <div class="col-md-6">
                                                            <label class="control-label">Network</label>
                                             <select class="form-control form-white" id="network" required>
                                                 @if ($networks->count() == 0)
                                                 <option value=''>Please add network</option>
                                                 @else
                                                    @foreach ($networks as $network)
                                                    <option value='{{ $network->name }}'>{{ $network->name }}</option>
                                                    @endforeach
                                                 @endif

													</select>
                                                        </div>




														 <div class="col-md-6">
                                                            <label class="control-label"> Prefix [seperate with comma (,) to add two or more] </label>
                           <input class="form-control form-white" id="prefix" placeholder="Enter phone number prefix" type="text" required />
                                                        </div>





                                                    </div>
                                                </form>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary waves-effect" data-dismiss="modal" id="form_cancel">Cancel</button>
                                                <button type="button" class="btn btn-danger waves-effect waves-light save-category" id="create"> <span id="btn-spinner"></span> <span id="btn-txt"> Save </span></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- END MODAL -->







                                                             <!-- Update  Modal  -->
                                                             <div class="modal fade none-border" id="updateModel">
                                                                <div class="modal-dialog">
                                                                    <div class="modal-content">
                                                                        <div class="modal-header">
                                                                            <h5 class="modal-title">Network Prefix Update</h5>
                                                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                                                        </div>
                                                                        <div class="modal-body p-3">
                                                                            <form>
                                                                                <div class="row">

                                    <input class="form-control form-white" id="data_id" hidden readonly type="text" required />





                                    <div class="col-md-6">
                                        <label class="control-label">Network </label>
                                        <select class="form-control form-white" id="network_" required>
                                                      <option value="">Please select</option>
                                                      @foreach ($networks as $network)
                                                      <option value="{{ $network->name }}">{{ $network->name }}</option>
                                                      @endforeach

                                                    </select>
                                                      </div>





                                                      <div class="col-md-6">
                                                        <label class="control-label"> Prefix [seperate with comma (,) to add two or more] </label>
                       <input class="form-control form-white" id="prefix_" placeholder="Enter phone number prefix" type="text" required />
                                                    </div>





                                                                                </div>
                                                                            </form>
                                                                        </div>
                                                                        <div class="modal-footer">
                             <button type="button" class="btn btn-secondary waves-effect" data-dismiss="modal" id="form_cancel">Cancel</button>
                             <button type="button" class="btn btn-danger waves-effect waves-light save-category" id="update"> <span id="update_btn-spinner"></span> <span id="update_btn-txt"> Update </span></button>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!-- END MODAL -->







@include('layout.footer')
