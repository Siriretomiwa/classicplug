<!-- Footer Start -->
          <footer class="footer">
              <div class="container-fluid">
                  <div class="row">
                      <div class="col-md-12">
                           <b>&copy By 03Developers</b>
                      </div>
                  </div>
              </div>
          </footer>
          <!-- end Footer -->

      </div>

      <!-- ============================================================== -->
      <!-- End Page content -->
      <!-- ============================================================== -->

  </div>


  <!-- END wrapper -->

  <!-- Vendor js -->
  <script src="/assets/js/vendor.min.js"></script>
  <!-- App js -->
  <script src="/assets/js/app.min.js"></script>
      <!-- Sweet Alerts js -->
  <script src="/assets/libs/sweetalert2/sweetalert2.min.js"></script>

  <!-- Sweet alert init js-->
  <script src="/assets/js/pages/sweet-alerts.init.js"></script>
  {{-- izitoast --}}
  <script src="/assets/izitoast/iziToast.js"></script>
    <script src="/assets/izitoast/iziToast.min.js"></script>
{{-- overlay --}}
    <script src="/assets/js/overlay.js"></script>
{{-- chartjs --}}
    <script type="text/javascript" src="/chartjs/Chart.min.js"></script>
    {{-- Toastr --}}
    <script src="/assets/toastr/toastr.js"></script>

        <!-- Datatable plugin js -->
        <script src="/assets/libs/datatables/jquery.dataTables.min.js"></script>
        <script src="/assets/libs/datatables/dataTables.bootstrap4.min.js"></script>

        <script src="/assets/bootstrap-toggle/js/bootstrap4-toggle.min.js"></script>
{{--
        <script src="/assets/libs/datatables/dataTables.responsive.min.js"></script>
        <script src="/assets/libs/datatables/responsive.bootstrap4.min.js"></script> --}}

        {{-- <script src="/assets/libs/datatables/dataTables.buttons.min.js"></script> --}}
        {{-- <script src="/assets/libs/datatables/buttons.bootstrap4.min.js"></script>

        <script src="/assets/libs/jszip/jszip.min.js"></script>
        <script src="/assets/libs/pdfmake/pdfmake.min.js"></script>
        <script src="/assets/libs/pdfmake/vfs_fonts.js"></script> --}}

        {{-- <script src="/assets/libs/datatables/buttons.html5.min.js"></script>
        <script src="/assets/libs/datatables/buttons.print.min.js"></script>

        <script src="/assets/libs/datatables/dataTables.keyTable.min.js"></script>
        <script src="/assets/libs/datatables/dataTables.select.min.js"></script>

        <!-- Datatables init -->
        <script src="/assets/js/pages/datatables.init.js"></script> --}}


</body>
</html>

