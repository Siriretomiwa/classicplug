<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title>Admin | Dashboard</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="Admin | dashboard" name="description" />
        <meta content="{{ csrf_token() }}" name="csrf-token" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <!-- App favicon -->
        <link rel="shortcut icon" href="/images/03developer.jpeg">
        <!-- App css -->
        <link href="/assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" id="bootstrap-stylesheet" />
        <link href="/assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <link href="/assets/css/app.min.css" rel="stylesheet" type="text/css"  id="app-stylesheet" />
		 <link href="/o3developer.css" rel="stylesheet" type="text/css" />
         {{-- Sweetalert --}}
        <link href="/assets/libs/sweetalert2/sweetalert2.min.css" rel="stylesheet" type="text/css" />
		{{-- izitoast --}}
        <link href="/assets/izitoast/iziToast.min.css" rel="stylesheet" type="text/css" />
		<link href="/assets/izitoast/iziToast.css" rel="stylesheet" type="text/css" />
        {{-- Toastr --}}
		<link href="/assets/toastr/toastr.css" rel="stylesheet" type="text/css" />
        {{-- JQuery --}}
		<script src="/assets/jquery/jquery-3.5.1.min.js"></script>
        <!-- Table datatable css -->
        <link href="/assets/libs/datatables/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />

        <link href="https://fonts.googleapis.com/css2?family=Ibarra+Real+Nova:wght@500&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Roboto+Slab&display=swap" rel="stylesheet">

        {{-- <link href="/assets/libs/datatables/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css" /> --}}
        {{-- <link href="/assets/libs/datatables/responsive.bootstrap4.min.css" rel="stylesheet" type="text/css" /> --}}


        <link href="/assets/bootstrap-toggle/css/bootstrap4-toggle.min.css" rel="stylesheet" type="text/css" />

        <script src="/ajax/main.js"> </script>
        <script type="text/javascript" src="/ckeditor/ckeditor.js"></script>

	  <noscript> Javascript is required to access some resources on this website </noscript>

      <style>
            th {
                border-bottom: 2px solid #dee2e6
            }
          </style>

    </head>
    <body>
