@include('layout.header')
<script src="/ajax/cable/ordering.js"> </script>
@include('layout.nav')

        <div class="content">
               <!-- Start Content-->
                    <div class="container-fluid">
                     <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">admin</a></li>
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">home</a></li>
                                        </ol>
                                    </div>
                                    <h4 class="page-title">Dashboard</h4>
                                </div>
                            </div>
                        </div>
                        <!-- end page title -->
                </div> <!-- end container-fluid -->
          </div> <!-- end content -->


				<div class="row">
                    <div class="col-12">
                                <div class="card-box" style="border: 1px solid white;">

                                    <div class="container" style="margin-bottom: 50px">
                                        <span class="header-title" style="float: left"><b>Cable Plans Arrangement</b></span></div>

                                        <hr/>


                               <div class="table-responsive">
                                <div id="tableContainer"> </div>
                            </div>


                            </div>

                    </div>

                        <!-- end row -->





@include('layout.footer')
