
const ajaxRequest = (path, data, dataType, beforeSend, complete, success) => {
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    $.ajax({
        type: "POST",
        dataType: dataType,
        url: path,
        data: data,
        beforeSend: beforeSend,
        success: success,
        complete: complete
    });
}


const toastProps = (toastIcon) => {
    return {
    tapToDismiss: true,
    iconClass: toastIcon,
    positionClass: 'toast-top-right',
    showEasing: 'swing',
    closeHtml: '<button type="button">&times;</button>',
    preventDuplicates: false,
    progressBar: true,
}
}

const toast = (error, message, type) => {
    toastr.remove();
    switch(type) {
        case "error": toastr.error(message, error, toastProps("toast-error"));
        break;
        case "success": toastr.success(message, error, toastProps("toast-success"));
        break;
        case "warning": toastr.warning(message, error, toastProps("toast-warning"));
        break;
    }

};



$(document).on('click', '#allCheck', function() {
    if ($(this).is(':checked')) {
        $(".checkbox").prop('checked', true);
    } else {
        $(".checkbox").prop('checked', false);
    }
})
