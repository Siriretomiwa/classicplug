$(document).ready(function() {
    $('form').on('submit', function(e) {
        e.preventDefault();
    });
    create();
    view(true);
    apply();
    toggleUpdate();
    delete_();
    edit();
    update();
});


const url = window.location.pathname.endsWith('/') ? '/bundle/' : 'bundle/';

$(document).on('click', '#allCheck', function() {
    if ($(this).is(':checked')) {
        $(".checkbox").prop('checked', true);
    } else {
        $(".checkbox").prop('checked', false);
    }
})



function toggleUpdate() {
    $(document).on('click', '.toggleSwitch', function() {
        let status = "";
        if ($(this).is(':checked')) {
            status = "available";
        } else {
            status = "unavailable";
        }
        let id = $(this).attr('data-id');
        if (status !== "") {

            data = {
                status: status,
                id: id,
            }

            beforeSend = () => { $(this).LoadingOverlay("show") },
                success = (response) => {
                    if (response !== "") {
                        if (response.code == 200) {
                            if (response.status == "available") {
                                toast("Success", response.message, "success");
                            } else if (response.status == "unavailable") {
                                toast("Success", response.message, "warning");
                            }
                        } else {
                            toast("Oops", response.message, "error");
                        }

                    } else {
                        toast("Oops", "An error occured", "error");

                    }

                },
                complete = (response) => { $(this).LoadingOverlay("hide") }
            path = url + "status/update";
            ajaxRequest(path, data, "JSON", beforeSend, complete, success);

        } else {
            alert('Whoops something went wrong');
        }
    })
}




function apply() {
    $(document).on('click', '#apply', function(e) {
        e.preventDefault();
        let action = $('#action').val();
        if (action !== "") {
            let arr = [];
            $(".checkbox:checked").each(function() {
                arr.push($(this).attr('data-id'));
            });
            if (arr.length !== 0) {
                let message = "";
                if (action == "delete") {
                    message = "Are you sure you want to delete this row?";
                } else {
                    message = "Are you sure you want to set this row " + action + "?";
                }
                var check = confirm(message);
                if (check == true) {

                    data = {
                        action: action,
                        arr: arr,
                    }

                    beforeSend = () => {
                            $("#apply").attr("disabled", "disabled");
                            $("#applybtn-txt").text("processing...");
                            $("#applybtn-spinner").addClass("spinner-border spinner-border-sm");

                        },

                        success = (response) => {
                            if (response !== "") {
                                if (response.code == 200) {
                                    toast("Success", response.message, "success");
                                    view();
                                } else {
                                    toast("Oops", response.message, "error");
                                }

                            } else {
                                toast("Oops", "An error occured", "error");

                            }

                        },
                        complete = (response) => {
                            $("#apply").removeAttr("disabled", true);
                            $("#applybtn-txt").text("Apply");
                            $("#applybtn-spinner").removeClass("spinner-border spinner-border-sm");
                        }
                    path = url + "action";
                    ajaxRequest(path, data, "JSON", beforeSend, complete, success);

                }
            } else {
                alert('Please select row');
            }
        } else {
            alert('Please select an action');
        }
    })
}




function create() {
    $(document).on('click', '#create', function() {
        let plan = $("#plan").val();
        let status = $("#status").val();
        if (plan !== "" && status !== "") {
            data = {
                plan: plan,
                status: status,
            }

            beforeSend = () => {
                    $("#create").attr("disabled", "disabled");
                    $("#btn-txt").text("saving...");
                    $("#btn-spinner").addClass("spinner-border spinner-border-sm");

                },

                success = (response) => {
                    if (response !== "") {
                        if (response.code == 200) {
                            toast("Success", response.message, "success");
                            $('#form').trigger('reset');
                            view();
                        } else {
                            toast("Oops", response.message, "error");
                        }

                    } else {
                        toast("Oops", "An error occured", "error");

                    }

                },
                complete = (response) => {
                    $("#create").removeAttr("disabled", true);
                    $("#btn-txt").text("Save");
                    $("#btn-spinner").removeClass("spinner-border spinner-border-sm");
                }
            path = url + "create";
            ajaxRequest(path, data, "JSON", beforeSend, complete, success);

        } else {
            toast("Oops", "Fill the required fields", "error");
        }
    })
}


function view(loading) {
    loading == true ? $.LoadingOverlay("show") : '';
    $.ajax({
        url: url,
        dataType: "HTML",
        success: function(response) {
            $("#tableContainer").html(response);
            $('#table').DataTable({stateSave: true, "ordering": false });
            loading == true ? $.LoadingOverlay("hide") : '';
        }
    });
}



function edit() {
    $(document).on('click', '#edit', function() {
        let data_id = $(this).attr('data-id');
        if (data_id !== "") {
            data = {
                id: data_id,
            };
            beforeSend = () => { $(this).LoadingOverlay("show") },
                success = (response) => {
                    if (response !== "") {
                        if (response.code == 200) {
                            // console.log(response);
                            $('#data_id').val(response.data.id);
                            $('#plan_').val(response.data.plan);
                            $('#status_').val(response.data.status);
                            $('#updateModel').modal('show');
                        } else {
                            toast("Oops", response.message, "error");
                        }

                    } else {
                        toast("Oops", "An error occured", "error");

                    }

                },
                complete = (response) => { $(this).LoadingOverlay("hide") }
            path = url + "edit";
            ajaxRequest(path, data, "JSON", beforeSend, complete, success);

        }
    });
}







function delete_() {
    $(document).on('click', '#delete', function() {
        let message = "Are you sure you want to delete this row?";
        var check = confirm(message);
        if (check == true) {
            let data_id = $(this).attr('data-id');
            if (data_id !== "") {
                data = {
                    id: data_id,
                };

                beforeSend = () => { $(this).LoadingOverlay("show") },
                    success = (response) => {
                        if (response !== "") {
                            if (response.code == 200) {
                                toast("Success", response.message, "success");
                                view();
                            } else {
                                toast("Oops", response.message, "error");
                            }

                        } else {
                            toast("Oops", "An error occured", "error");

                        }

                    },
                    complete = (response) => { $(this).LoadingOverlay("hide") }
                path = url + "delete";
                ajaxRequest(path, data, "JSON", beforeSend, complete, success);

            }
        }
    });

}





function update() {
    $(document).on('click', '#update', function() {
        let data_id = $('#data_id').val();
        let plan = $('#plan_').val();
        let status = $('#status_').val();
        if (data_id !== "" && plan !== "" && status !== "") {
            data = {
                id: data_id,
                status: status,
                plan: plan,
            };

            beforeSend = () => {
                    $("#update").attr("disabled", "disabled");
                    $("#update_btn-txt").text("updating...");
                    $("#update_btn-spinner").addClass("spinner-border spinner-border-sm");

                },

                success = (response) => {
                    if (response !== "") {
                        if (response.code == 200) {
                            toast("Success", response.message, "success");
                            $('#form').trigger('reset');
                            view();
                        } else {
                            toast("Oops", response.message, "error");
                        }

                    } else {
                        toast("Oops", "An error occured", "error");

                    }

                },
                complete = (response) => {
                    $("#update").removeAttr("disabled", true);
                    $("#update_btn-txt").text("Update");
                    $("#update_btn-spinner").removeClass("spinner-border spinner-border-sm");
                }
            path = url + "update";
            ajaxRequest(path, data, "JSON", beforeSend, complete, success);

        } else {
            alert("Please fill the required field");
        }
    });
}
