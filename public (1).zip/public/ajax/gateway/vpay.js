$(document).ready(function() {
    $('form').on('submit', function(e) {
        e.preventDefault();
    });
    vpay();
});



const url = window.location.pathname.endsWith('/') ? '/vpay/' : '/vpay/';

function vpay() {
    $(document).on('click', '#vpay', function() {
        let secret_key = $("#secret_key").val();
        let api_key = $("#api_key").val();
        let contract = $("#contract").val();
        let name = $("#name").val();
        let type = $("#type").val();
        let transfer_charge = $("#transfer_charge").val();
        let card_charge = $("#card_charge").val();
        let bank_code = $("#bank_code").val();
        let status = $("#status").val();
        if (secret_key !== "ff4521d3-bb25-484a-9829-077a18a82071" && api_key !== "faa1a340-4a2a-4581-aeed-3a4f85a123fe") {
            data = {
                secret_key: secret_key,
                api_key: api_key,
                contract: contract,
                name: name,
                type: type,
                transfer_charge: transfer_charge,
                card_charge: card_charge,
                bank_code: bank_code,
                status: status,
            };

            $.ajax({
                url: url,
                type: "POST",
                data: JSON.stringify(data),
                dataType: "json",
                contentType: "application/json",
                beforeSend: function() {
                    $("#vpay").attr("disabled", "disabled");
                    $("#btn-txt").text("saving...");
                    $("#btn-spinner").addClass("spinner-border spinner-border-sm");
                },
                success: function(response) {
                    if (response !== "") {
                        if (response.code == 200) {
                            toast("Success", response.message, "success");
                            $("#vpay").removeAttr("disabled", true);
                            $("#btn-txt").text("Save");
                            $("#btn-spinner").removeClass("spinner-border spinner-border-sm");
                        } else {
                            toast("Oops", response.message, "error");
                        }
                    } else {
                        toast("Oops", "An error occured", "error");
                    }
                },
                complete: function() {
                    $("#vpay").removeAttr("disabled", true);
                    $("#btn-txt").text("Save");
                    $("#btn-spinner").removeClass("spinner-border spinner-border-sm");
                },
                error: function() {
                    toast("Oops", "An error occured", "error");
                }
            });
        } else {
            toast("Oops", "Fill the required fields", "error");
        }
    });
}
