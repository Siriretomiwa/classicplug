$(document).ready(function() {
    $('form').on('submit', function(e) {
        e.preventDefault();
    });
    paystack();
});


const url = window.location.pathname.endsWith('/') ? '/paystack/' : 'paystack/';

function paystack() {
    $(document).on('click', '#paystack', function() {
        let secret_key = $("#secret_key").val();
        let public_key = $("#public_key").val();
        let charge = $("#charge").val();
        let status = $("#status").val();
        if (secret_key !== "" && charge !== "" && status !=="") {
            data = {
                secret_key: secret_key,
                public_key: public_key,
                charge: charge,
                status: status,
            }

            beforeSend = () => {
                    $("#paystack").attr("disabled", "disabled");
                    $("#btn-txt").text("saving...");
                    $("#btn-spinner").addClass("spinner-border spinner-border-sm");
                },

                success = (response) => {
                    if (response !== "") {
                        if (response.code == 200) {
                            toast("Success", response.message, "success");
                            $("#paystack").removeAttr("disabled", true);
                            $("#btn-txt").text("Save");
                            $("#btn-spinner").removeClass("spinner-border spinner-border-sm");
                        } else {
                            toast("Oops", response.message, "error");
                        }

                    } else {
                        toast("Oops", "An error occured", "error");

                    }

                },
                complete = (response) => {
                    $("#paystack").removeAttr("disabled", true);
                    $("#btn-txt").text("Save");
                    $("#btn-spinner").removeClass("spinner-border spinner-border-sm");
                }
            path = url;
            ajaxRequest(path, data, "JSON", beforeSend, complete, success);

        } else {
            toast("Oops", "Fill the required fields", "error");
        }
    })
}


