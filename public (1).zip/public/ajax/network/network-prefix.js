$(document).ready(function() {
    $('form').on('submit', function(e) {
        e.preventDefault();
    });
    create();
    view(true);
    delete_();
    apply();
    edit();
    update();
});


const url = window.location.pathname.endsWith('/') ? '/prefix/' : 'prefix/';


function create() {
    $(document).on('click', '#create', function() {
        let network = $("#network").val();
        let prefix = $("#prefix").val();
        if (network !== "" && prefix !== "") {
            data = {
                network: network,
                prefix: prefix,
            }

            beforeSend = () => {
                    $("#create").attr("disabled", "disabled");
                    $("#btn-txt").text("saving...");
                    $("#btn-spinner").addClass("spinner-border spinner-border-sm");

                },

                success = (response) => {
                    if (response !== "") {
                        if (response.code == 200) {
                            toast("Success", response.message, "success");
                            $('#form').trigger('reset');
                            view();
                        } else {
                            toast("Oops", response.message, "error");
                        }

                    } else {
                        toast("Oops", "An error occured", "error");

                    }

                },
                complete = (response) => {
                    $("#create").removeAttr("disabled", true);
                    $("#btn-txt").text("Save");
                    $("#btn-spinner").removeClass("spinner-border spinner-border-sm");
                }
            path = url + "create";
            ajaxRequest(path, data, "JSON", beforeSend, complete, success);

        } else {
            toast("Oops", "Fill the required fields", "error");
        }
    })
}


function view(loading) {
    loading == true ? $.LoadingOverlay("show") : '';
    $.ajax({
        url: url,
        dataType: "HTML",
        success: function(response) {
            $("#tableContainer").html(response);
            $('#table').DataTable({stateSave: true});
            loading == true ? $.LoadingOverlay("hide") : '';
        }
    });
}




function apply() {
    $(document).on('click', '#apply', function(e) {
        e.preventDefault();
        let action = $('#action').val();
        if (action !== "") {
            let arr = [];
            $(".checkbox:checked").each(function() {
                arr.push($(this).attr('data-id'));
            });
            if (arr.length !== 0) {
                var check = confirm("Are you sure you want to delete this row?");
                if (check == true) {

                    data = {
                        action: action,
                        arr: arr,
                    }

                    beforeSend = () => {
                            $("#apply").attr("disabled", "disabled");
                            $("#applybtn-txt").text("processing...");
                            $("#applybtn-spinner").addClass("spinner-border spinner-border-sm");

                        },

                        success = (response) => {
                            if (response !== "") {
                                if (response.code == 200) {
                                    toast("Success", response.message, "success");
                                    view();
                                } else {
                                    toast("Oops", response.message, "error");
                                }

                            } else {
                                toast("Oops", "An error occured", "error");

                            }

                        },
                        complete = (response) => {
                            $("#apply").removeAttr("disabled", true);
                            $("#applybtn-txt").text("Apply");
                            $("#applybtn-spinner").removeClass("spinner-border spinner-border-sm");
                        }
                    path = url + "action";
                    ajaxRequest(path, data, "JSON", beforeSend, complete, success);

                }
            } else {
                alert('Please select row');
            }
        } else {
            alert('Please select an action');
        }
    })
}


function delete_() {
    $(document).on('click', '#delete', function() {
        let message = "Are you sure you want to delete this row?";
        var check = confirm(message);
        if (check == true) {
            let data_id = $(this).attr('data-id');
            if (data_id !== "") {
                data = {
                    id: data_id,
                };

                beforeSend = () => { $(this).LoadingOverlay("show") },
                    success = (response) => {
                        if (response !== "") {
                            if (response.code == 200) {
                                toast("Success", response.message, "success");
                                view();
                            } else {
                                toast("Oops", response.message, "error");
                            }

                        } else {
                            toast("Oops", "An error occured", "error");

                        }

                    },
                    complete = (response) => { $(this).LoadingOverlay("hide") }
                path = url + "delete";
                ajaxRequest(path, data, "JSON", beforeSend, complete, success);

            }
        }
    });

}



function edit() {
    $(document).on('click', '#edit', function() {
        let data_id = $(this).attr('data-id');
        if (data_id !== "") {
            data = {
                id: data_id,
            };
            beforeSend = () => { $(this).LoadingOverlay("show") },
                success = (response) => {
                    if (response !== "") {
                        if (response.code == 200) {
                            $('#data_id').val(response.data.id);
                            $('#network_').val(response.data.network);
                            $('#prefix_').val(response.data.prefix);
                            $('#updateModel').modal('show');
                        } else {
                            toast("Oops", response.message, "error");
                        }

                    } else {
                        toast("Oops", "An error occured", "error");

                    }

                },
                complete = (response) => { $(this).LoadingOverlay("hide") }
            path = url + "edit";
            ajaxRequest(path, data, "JSON", beforeSend, complete, success);

        }
    });
}



function update() {
    $(document).on('click', '#update', function() {
        let data_id = $('#data_id').val();
        let network = $('#network_').val();
        let prefix = $('#prefix_').val();
        if (data_id !== "" && network !== "" && prefix !== "") {
            data = {
                id: data_id,
                network: network,
                prefix: prefix,
            };

            beforeSend = () => {
                    $("#update").attr("disabled", "disabled");
                    $("#update_btn-txt").text("updating...");
                    $("#update_btn-spinner").addClass("spinner-border spinner-border-sm");

                },

                success = (response) => {
                    if (response !== "") {
                        if (response.code == 200) {
                            toast("Success", response.message, "success");
                            $('#form').trigger('reset');
                            view();
                        } else {
                            toast("Oops", response.message, "error");
                        }

                    } else {
                        toast("Oops", "An error occured", "error");

                    }

                },
                complete = (response) => {
                    $("#update").removeAttr("disabled", true);
                    $("#update_btn-txt").text("Update");
                    $("#update_btn-spinner").removeClass("spinner-border spinner-border-sm");
                }
            path = url + "update";
            ajaxRequest(path, data, "JSON", beforeSend, complete, success);

        } else {
            alert("Please fill the required field");
        }
    });
}
