$(document).ready(function() {
    $('form').on('submit', function(e) {
        e.preventDefault();
    });
    update();
    load();
    merge();
});


const url = window.location.pathname.endsWith('/') ? '/code/' : 'code/';

function update() {
    $(document).on('click', '#proceed', function() {
        var arr = [];
        $('input[name="code[]"]').each(function() {
        arr.push({
            "id": $(this).attr("data-id"),
            "value":this.value
        });
    });

        if (arr !== "") {
            data = {
                code: arr,
            }

            beforeSend = () => {
                    $("#proceed").attr("disabled", "disabled");
                    $("#btn-txt").text("saving...");
                    $("#btn-spinner").addClass("spinner-border spinner-border-sm");

                },

                success = (response) => {
                    if (response !== "") {
                        if (response.code == 200) {
                            toast("Success", response.message, "success");
                            $('#form').trigger('reset');
                        } else {
                            toast("Oops", response.message, "error");
                        }

                    } else {
                        toast("Oops", "An error occured", "error");

                    }
                },

                complete = (response) => {
                    $("#proceed").removeAttr("disabled", true);
                    $("#btn-txt").html("Save <i class='fas fa-save'></i>");
                    $("#btn-spinner").removeClass("spinner-border spinner-border-sm");
                }
            path = url + "update";
            ajaxRequest(path, data, "JSON", beforeSend, complete, success);

        } else {
            toast("Oops", "Fill the required fields", "error");
        }
    })
}


function load() {
    $(document).on('change', '#host', function() {
        var host = $('#host').val();
        view(host, $(this));
    });
}


function view(host, thisProp) {
    $("#tableContainer").html('');
    if (host !== "") {
        $.ajax({
            url: url + "?host=" + host,
            dataType: "HTML",
            beforeSend: () => { $(thisProp).LoadingOverlay("show") },
            success: function(response) {
                $("#tableContainer").html(response);
                $('#table').DataTable({ stateSave: true, "ordering": false });
            },
            complete: (response) => { $(thisProp).LoadingOverlay("hide") }
        });
    } else {
        alert('Select provider');
}
}




function merge() {
    $(document).on('click', '#merge', function() {
        let host_1 = $("#host_1").val();
        let host_2 = $("#host_2").val();
        if (host_1 !== "" && host_2 !== "") {
            if (host_1 !== host_2) {
            data = {
                host_1: host_1,
                host_2: host_2,
            }

            beforeSend = () => {
                    $("#merge").attr("disabled", "disabled");
                    $("#merge-txt").text("merging...");
                    $("#merge-spinner").addClass("spinner-border spinner-border-sm");

                },

                success = (response) => {
                    if (response !== "") {
                        if (response.code == 200) {
                            toast("Success", response.message, "success");
                            $('#form').trigger('reset');
                            $('#host').val(host_2);
                            view(host_2, null);
                        } else {
                            toast("Oops", response.message, "error");
                        }
                    } else {
                        toast("Oops", "An error occured", "error");

                    }

                },
                complete = (response) => {
                    $("#merge").removeAttr("disabled", true);
                    $("#merge-txt").text("Merge");
                    $("#merge-spinner").removeClass("spinner-border spinner-border-sm");
                }
            path = url + "merge";
            ajaxRequest(path, data, "JSON", beforeSend, complete, success);

            } else {
                toast("Oops", "You can't merge the same host", "error");
            }

        } else {
            toast("Oops", "Fill the required fields", "error");
        }
    })
}

