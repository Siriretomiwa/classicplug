$(document).ready(function() {
    $('form').on('submit', function(e) {
        e.preventDefault();
    });
    sms();
});


const url = window.location.pathname.endsWith('/') ? '/bulk-sms/' : 'bulk-sms/';

function sms() {
    $(document).on('click', '#save', function() {
        let charge = $("#charge").val();
        let key = $("#key").val();
        let key_ = $("#key_").val();
        let status = $("#status").val();
        if (charge !== "" && status !== "" && key !== "") {
            data = {
                charge: charge,
                status: status,
                key: key,
                key_: key_

            }

            beforeSend = () => {
                    $("#save").attr("disabled", "disabled");
                    $("#btn-txt").text("saving...");
                    $("#btn-spinner").addClass("spinner-border spinner-border-sm");
                },

                success = (response) => {
                    if (response !== "") {
                        if (response.code == 200) {
                            toast("Success", response.message, "success");
                            $("#save").removeAttr("disabled", true);
                            $("#btn-txt").text("Save");
                            $("#btn-spinner").removeClass("spinner-border spinner-border-sm");
                        } else {
                            toast("Oops", response.message, "error");
                        }

                    } else {
                        toast("Oops", "An error occured", "error");

                    }

                },
                complete = (response) => {
                    $("#save").removeAttr("disabled", true);
                    $("#btn-txt").text("Save");
                    $("#btn-spinner").removeClass("spinner-border spinner-border-sm");
                }
            path = url;
            ajaxRequest(path, data, "JSON", beforeSend, complete, success);

        } else {
            toast("Oops", "Fill the required fields", "error");
        }
    })
}


