$(document).ready(function() {
    $('form').on('submit', function(e) {
        e.preventDefault();
    });
    send();
});


const url = window.location.pathname.endsWith('/') ? '/notification/sms/' : 'sms/';

function send() {
    $(document).on('click', '#send', function() {
        let message = $("#message").val();
        let recipient = $("#recipient").val();
        let sender = $("#sender").val();
        if (recipient !== "" && sender !=="" && message !== "") {
            data = {
                message: message,
                recipient: recipient,
                sender: sender,
            }

            beforeSend = () => {
                    $("#send").attr("disabled", "disabled");
                    $("#btn-txt").text("sending...");
                    $("#btn-spinner").addClass("spinner-border spinner-border-sm");
                },

                success = (response) => {
                    if (response !== "") {
                        if (response.code == 200) {
                            // toast("Success", response.message, "success");
                            swal.fire({
                                title: "Successful",
                                text: response.message,
                                type: "success",
                                button: "Okay",
                            });
                            $("#send").removeAttr("disabled", true);
                            $("#btn-txt").text("Send");
                            $("#btn-spinner").removeClass("spinner-border spinner-border-sm");
                        } else {
                            toast("Oops", response.message, "error");
                        }

                    } else {
                        toast("Oops", "An error occured", "error");

                    }

                },
                complete = (response) => {
                    $("#send").removeAttr("disabled", true);
                    $("#btn-txt").text("Send");
                    $("#btn-spinner").removeClass("spinner-border spinner-border-sm");
                }
            path = url;
            ajaxRequest(path, data, "JSON", beforeSend, complete, success);

        } else {
            toast("Oops", "Fill the required fields", "error");
        }
    })
}


