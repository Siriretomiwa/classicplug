$(document).ready(function() {
    $('form').on('submit', function(e) {
        e.preventDefault();
    });
    submit();
});


const url = window.location.pathname.endsWith('/') ? '/whatsapp/' : 'whatsapp/';

function submit() {
    $(document).on('click', '#submit', function() {
        let number = $("#number").val();
        let link = $("#link").val();
        if (number !== "") {
            data = {
                number: number,
                link: link,
            }

            beforeSend = () => {
                    $("#submit").attr("disabled", "disabled");
                    $("#btn-txt").text("saving...");
                    $("#btn-spinner").addClass("spinner-border spinner-border-sm");
                },

                success = (response) => {
                    if (response !== "") {
                        if (response.code == 200) {
                            toast("Success", response.message, "success");
                            $("#submit").removeAttr("disabled", true);
                            $("#btn-txt").text("Submit");
                            $("#btn-spinner").removeClass("spinner-border spinner-border-sm");
                        } else {
                            toast("Oops", response.message, "error");
                        }

                    } else {
                        toast("Oops", "An error occured", "error");

                    }

                },
                complete = (response) => {
                    $("#submit").removeAttr("disabled", true);
                    $("#btn-txt").text("Save");
                    $("#btn-spinner").removeClass("spinner-border spinner-border-sm");
                }
            path = url;
            ajaxRequest(path, data, "JSON", beforeSend, complete, success);

        } else {
            toast("Oops", "Fill the required fields", "error");
        }
    })
}


