$(document).ready(function() {
    $('form').on('submit', function(e) {
        e.preventDefault();
    });

     view(true);
     search();
     entries();
     pagination();
     delete_();
});


const url = window.location.pathname.endsWith('/') ? '/log/' : 'log/';

function view(loading) {
    let storedPage = sessionStorage.getItem('ref_page');
    let page = storedPage !== null ? storedPage :  1;
    /* Search */
    storedSearch = sessionStorage.getItem('ref_search');
    storedSearch !== null ? $('#search').val(storedSearch) :  $('#search').val();
    let search = $('#search').val();
    /* Entries */
    storedEntries = sessionStorage.getItem('ref_entries');
    storedEntries !== null ? $('#entries').val(storedEntries) :  $('#entries').val();
    let entries = $('#entries').val();

    loading == true ? $.LoadingOverlay("show") : '';
    $.ajax({
        type: "GET",
        url: url + "?page=" + page + "&search=" + search + "&entries=" + entries,
        success: function(data) {
            $('#tableContainer').html(data);
            loading == true ? $.LoadingOverlay("hide") : '';
        },
        error: function(e) {
            loading == true ? $.LoadingOverlay("hide") : '';
        }
    });
}







    function entries() {
        $(document).on('change', '#entries', function(){
            var entries = $('#entries').val();
            sessionStorage.setItem('ref_entries', entries);
            view();
        });
    }




function search() {
	$(document).on('keyup', '#search', function(){
        var search = $('#search').val();
        sessionStorage.setItem('ref_search', search);
        view();

	});
	}



function pagination() {
    $(document).on('click', '#pagination', function(event) {
        event.preventDefault();
        let page = $(this).attr('href').split('page=')[1];
        sessionStorage.setItem('ref_page', page);
        let search = $('#search').val();
        let entries = $('#entries').val();
        $.LoadingOverlay("show");
        $.ajax({
            url: url + "?page=" + page + "&search=" + search + "&entries=" + entries,
            success: function(data) {
                $('#tableContainer').html(data);
                $.LoadingOverlay("hide");
            },
            error: function(e) {
                $.LoadingOverlay("hide");
            }
        });
    })
}



function delete_() {
    $(document).on('click', '#delete', function() {
        let data_id = $(this).attr('data-id');
        let message = "Are you sure you want to delete this row?";
        var check = confirm(message);
        if (check == true) {
            if (data_id !== "") {
                data = {
                    id: data_id,
                };

                beforeSend = () => { $(this).LoadingOverlay("show") },
                    success = (response) => {
                        if (response !== "") {
                            if (response.code == 200) {
                                toast("Success", response.message, "success");
                                view();
                            } else {
                                toast("Oops", response.message, "error");
                            }

                        } else {
                            toast("Oops", "An error occured", "error");

                        }

                    },
                    complete = (response) => { $(this).LoadingOverlay("hide") }
                path = url + "delete";
                ajaxRequest(path, data, "JSON", beforeSend, complete, success);

            }
        }
    });

}

