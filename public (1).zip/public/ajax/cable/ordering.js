$(document).ready(function() {
    $('form').on('submit', function(e) {
        e.preventDefault();
    });
    update();
    view(true);
});


const url = window.location.pathname.endsWith('/') ? '/ordering/' : 'ordering/';

function update() {
    $(document).on('click', '#proceed', function() {
        var arr = [];
        $('input[name="code[]"]').each(function() {
        arr.push({
            "id": $(this).attr("data-id"),
            "value":this.value
        });
    });

        if (arr !== "") {
            data = {
                key: arr,
            }

            beforeSend = () => {
                    $("#proceed").attr("disabled", "disabled");
                    $("#btn-txt").text("saving...");
                    $("#btn-spinner").addClass("spinner-border spinner-border-sm");

                },

                success = (response) => {
                    if (response !== "") {
                        if (response.code == 200) {
                            toast("Success", response.message, "success");
                            view();
                        } else {
                            toast("Oops", response.message, "error");
                        }

                    } else {
                        toast("Oops", "An error occured", "error");

                    }
                },

                complete = (response) => {
                    $("#proceed").removeAttr("disabled", true);
                    $("#btn-txt").html("Save <i class='fas fa-save'></i>");
                    $("#btn-spinner").removeClass("spinner-border spinner-border-sm");
                }
            path = url + "update";
            ajaxRequest(path, data, "JSON", beforeSend, complete, success);

        } else {
            toast("Oops", "Fill the required fields", "error");
        }
    })
}


function view(loading) {
    loading == true ? $.LoadingOverlay("show") : '';
    $.ajax({
        url: url,
        dataType: "HTML",
        success: function(response) {
            $("#tableContainer").html(response);
            $('#table').DataTable({stateSave: true, "ordering": false });
            loading == true ? $.LoadingOverlay("hide") : '';
        }
    });
}


