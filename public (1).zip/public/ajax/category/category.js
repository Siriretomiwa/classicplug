$(document).ready(function() {
    $('form').on('submit', function(e) {
        e.preventDefault();
    });
    create();
     view(true);
     toggleUpdate();
     delete_();
     edit();
     update();
});


const url = window.location.pathname.endsWith('/') ? '/category/' : 'category/';


function toggleUpdate() {
    $(document).on('click', '.toggleSwitch', function() {
        let status = "";
        if ($(this).is(':checked')) {
            status = "available";
        } else {
            status = "unavailable";
        }
        let id = $(this).attr('data-id');
        if (status !== "") {

            data = {
                status: status,
                id: id,
            }

            beforeSend = () => { $(this).LoadingOverlay("show") },
                success = (response) => {
                    if (response !== "") {
                        if (response.code == 200) {
                            if (response.status == "available") {
                                toast("Success", response.message, "success");
                            } else if (response.status == "unavailable") {
                                toast("Success", response.message, "warning");
                            }
                        } else {
                            toast("Oops", response.message, "error");
                        }

                    } else {
                        toast("Oops", "An error occured", "error");

                    }

                },
                complete = (response) => { $(this).LoadingOverlay("hide") }
            path = url + "status/update";
            ajaxRequest(path, data, "JSON", beforeSend, complete, success);

        } else {
            alert('Whoops something went wrong');
        }
    })
}






function create() {
    $(document).on('click', '#create', function() {
        let name = $("#name").val();
        let permission = $("#permission").val();
        let level = $("#level").val();
        let apply_charge = $('#apply_charge').val();
        let price = $("#price").val();
        let status = $("#status").val();
        if (name !== "" && apply_charge !== "" && permission !== "" && status !== "") {

            data = {
                name: name,
                price: price,
                permission: permission,
                level: level,
                apply_charge: apply_charge,
                status: status,
            }

            beforeSend = () => {
                    $("#create").attr("disabled", "disabled");
                    $("#btn-txt").text("saving...");
                    $("#btn-spinner").addClass("spinner-border spinner-border-sm");

                },

                success = (response) => {
                    if (response !== "") {
                        if (response.code == 200) {
                            toast("Success", response.message, "success");
                            $('#form').trigger('reset');
                            view();
                        } else {
                            toast("Oops", response.message, "error");
                        }

                    } else {
                        toast("Oops", "An error occured", "error");

                    }

                },
                complete = (response) => {
                    $("#create").removeAttr("disabled", true);
                    $("#btn-txt").text("Save");
                    $("#btn-spinner").removeClass("spinner-border spinner-border-sm");
                }
            path = url + "create";
                // console.log(apply_charge);
            if (apply_charge == "yes" && price !== "") {
                ajaxRequest(path, data, "JSON", beforeSend, complete, success);
            } else if (apply_charge == "no") {
                ajaxRequest(path, data, "JSON", beforeSend, complete, success);
            } else {
                toast("Oops", "The price field cannot be blank.", "error");
            }


        } else {
            toast("Oops", "Fill the required fields", "error");
        }
    })
}


function view(loading) {
    loading == true ? $.LoadingOverlay("show") : '';
    $.ajax({
        url: url,
        dataType: "HTML",
        success: function(response) {
            $("#tableContainer").html(response);
            $('#table').DataTable({stateSave: true});
            loading == true ? $.LoadingOverlay("hide") : '';
        }
    });
}




$(document).on('change', '#permission', function(){
    if ($(this).val() !== "") {
        if ($(this).val() == "category") {
            $('.category_div').removeAttr('hidden', true); // Show category div if it is selected
        } else {
            $('.category_div').attr('hidden', true); // Hide category div if it is not selected
            $('#level').val('');
        }
            $('.apply_div').removeAttr('hidden', true);
    } else {
        $('.apply_div').attr('hidden', true);
        $('.category_div').attr('hidden', true); // Show category div if it is selected
        $('#level').val('');
        $('.price').attr('hidden', true);
        $('#apply_charge').val("");
        $('#price').val("");
    }
})


$(document).on('change', '#apply_charge', function(){
    if ($(this).val() !== "") {
        if ($(this).val() == "yes") {
            $('.price').removeAttr('hidden', true);
            $('.price').val("");
        } else {
            $('.price').attr('hidden', true);
            $('#price').val("");
        }
    }else {
        $('.price').attr('hidden', true);
        $('#price').val("");
    }
})




function delete_() {
    $(document).on('click', '#delete', function() {
        let message = "Are you sure you want to delete this row?";
        var check = confirm(message);
        if (check == true) {
            let data_id = $(this).attr('data-id');
            if (data_id !== "") {
                data = {
                    id: data_id,
                };

                beforeSend = () => { $(this).LoadingOverlay("show") },
                    success = (response) => {
                        if (response !== "") {
                            if (response.code == 200) {
                                toast("Success", response.message, "success");
                                view();
                            } else {
                                toast("Oops", response.message, "error");
                            }

                        } else {
                            toast("Oops", "An error occured", "error");

                        }

                    },
                    complete = (response) => { $(this).LoadingOverlay("hide") }
                path = url + "delete";
                ajaxRequest(path, data, "JSON", beforeSend, complete, success);

            }
        }
    });

}





function edit() {
    $(document).on('click', '#edit', function() {
        let data_id = $(this).attr('data-id');
        if (data_id !== "") {
            data = {
                id: data_id,
            };
            beforeSend = () => { $(this).LoadingOverlay("show") },
                success = (response) => {
                    if (response !== "") {
                        if (response.code == 200) {
                            // console.log(response);
                            $('#data_id').val(response.data.id);
                            $('#name_').val(response.data.name);
                            $('#permission_').val(response.data.permission);
                            $('#level_').val(response.data.level);
                            $('#apply_charge_').val(response.data.apply_charge);
                            $('#price_').val(response.data.price);
                            $('#status_').val(response.data.status);
                            $('#updateModel').modal('show');
                        } else {
                            toast("Oops", response.message, "error");
                        }

                    } else {
                        toast("Oops", "An error occured", "error");

                    }

                },
                complete = (response) => { $(this).LoadingOverlay("hide") }
            path = url + "edit";
            ajaxRequest(path, data, "JSON", beforeSend, complete, success);

        }
    });
}





function update() {
    $(document).on('click', '#update', function() {
        let data_id = $('#data_id').val();
        let name = $('#name_').val();
        let permission = $('#permission_').val();
        let level = $('#level_').val();
        let apply_charge = $('#apply_charge_').val();
        let price = $('#price_').val();
        let status = $('#status_').val();
        if (name !== "" && apply_charge !== "" && permission !== "" && status !== "") {
            data = {
                id: data_id,
                name: name,
                price: price,
                permission: permission,
                level: level,
                apply_charge: apply_charge,
                status: status,
            };

            beforeSend = () => {
                    $("#update").attr("disabled", "disabled");
                    $("#update_btn-txt").text("updating...");
                    $("#update_btn-spinner").addClass("spinner-border spinner-border-sm");

                },

                success = (response) => {
                    if (response !== "") {
                        if (response.code == 200) {
                            toast("Success", response.message, "success");
                            $('#form').trigger('reset');
                            view();
                        } else {
                            toast("Oops", response.message, "error");
                        }

                    } else {
                        toast("Oops", "An error occured", "error");

                    }

                },
                complete = (response) => {
                    $("#update").removeAttr("disabled", true);
                    $("#update_btn-txt").text("Update");
                    $("#update_btn-spinner").removeClass("spinner-border spinner-border-sm");
                }
            path = url + "update";

            if (apply_charge == "yes" && price !== "") {
                ajaxRequest(path, data, "JSON", beforeSend, complete, success);
            } else if (apply_charge == "no") {
                ajaxRequest(path, data, "JSON", beforeSend, complete, success);
            } else {
                toast("Oops", "The price field cannot be blank.", "error");
            }



        } else {
            alert("Please fill the required field");
        }
    });
}
