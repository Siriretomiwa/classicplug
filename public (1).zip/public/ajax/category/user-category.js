$(document).ready(function() {
    $('form').on('submit', function(e) {
        e.preventDefault();
    });
       save();
});


const url = window.location.pathname.endsWith('/') ? '/users/' : 'users/';

function save() {
    $(document).on('click', '#save', function(e) {
        e.preventDefault();
        let category = $("#category").val();
        let charge = $("#charge").val();
        let username = $("#username").val();
        if (category !== "" && charge !== "" && username !== "") {
            data = {
                category: category,
                username: username,
                charge: charge,
            }

            beforeSend = () => {
                    $("#save").attr("disabled", "disabled");
                    $("#btn-txt").text("saving...");
                    $("#btn-spinner").addClass("spinner-border spinner-border-sm");

                },

                success = (response) => {
                    if (response !== "") {
                        if (response.code == 200) {
                            toast("Success", response.message, "success");
                            $('#form').trigger('reset');
                        } else {
                            toast("Oops", response.message, "error");
                        }

                    } else {
                        toast("Oops", "An error occured", "error");

                    }
                },
                complete = (response) => {
                    $("#save").removeAttr("disabled", true);
                    $("#btn-txt").text("Save");
                    $("#btn-spinner").removeClass("spinner-border spinner-border-sm");
                }

                path = url + "save";
                ajaxRequest(path, data, "JSON", beforeSend, complete, success);



        } else {
            toast("Oops", "Fill the required fields", "error");
        }
    })
}




