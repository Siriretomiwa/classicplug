$(document).ready(function() {
    $('form').on('submit', function(e) {
        e.preventDefault();
    });
    create();
    view();
    apply();
    toggleUpdate();
    delete_();
    edit();
    update();
    generateCoupon();
});


const url = window.location.pathname.endsWith('/') ? '/voucher/' : 'voucher/';

function generateCoupon() {
    $(document).on('change', '#auto_generate', function(){
        var options = $('#auto_generate').val();
        if (options == "yes") {
            const d = new Date();
            let ms = d.getMilliseconds();
        var coupon = Math.random().toString(36).replace(/[^a-z]+/g, '').substring(0, 15);
        $('#voucher').val(coupon.toUpperCase());
        } else {
            $('#voucher').val('');
        }
});

}

function toggleUpdate() {
    $(document).on('click', '.toggleSwitch', function() {
        let status = "";
        if ($(this).is(':checked')) {
            status = "available";
        } else {
            status = "unavailable";
        }
        let id = $(this).attr('data-id');
        if (status !== "") {

            data = {
                status: status,
                id: id,
            }

            beforeSend = () => { $(this).LoadingOverlay("show") },
                success = (response) => {
                    if (response !== "") {
                        if (response.code == 200) {
                            if (response.status == "available") {
                                toast("Success", response.message, "success");
                            } else if (response.status == "unavailable") {
                                toast("Success", response.message, "warning");
                            }
                        } else {
                            toast("Oops", response.message, "error");
                        }

                    } else {
                        toast("Oops", "An error occured", "error");

                    }

                },
                complete = (response) => { $(this).LoadingOverlay("hide") }
            path = url + "status/update";
            ajaxRequest(path, data, "JSON", beforeSend, complete, success);

        } else {
            alert('Whoops something went wrong');
        }
    })
}


function apply() {
    $(document).on('click', '#apply', function(e) {
        e.preventDefault();
        let action = $('#action').val();
        if (action !== "") {
            let arr = [];
            $(".checkbox:checked").each(function() {
                arr.push($(this).attr('data-id'));
            });
            if (arr.length !== 0) {
                let message = "";
                if (action == "delete") {
                    message = "Are you sure you want to delete this row?";
                } else {
                    message = "Are you sure you want to set this row " + action + "?";
                }
                var check = confirm(message);
                if (check == true) {

                    data = {
                        action: action,
                        arr: arr,
                    }

                    beforeSend = () => {
                            $("#apply").attr("disabled", "disabled");
                            $("#applybtn-txt").text("processing...");
                            $("#applybtn-spinner").addClass("spinner-border spinner-border-sm");

                        },

                        success = (response) => {
                            if (response !== "") {
                                if (response.code == 200) {
                                    toast("Success", response.message, "success");
                                    view();
                                } else {
                                    toast("Oops", response.message, "error");
                                }

                            } else {
                                toast("Oops", "An error occured", "error");

                            }

                        },
                        complete = (response) => {
                            $("#apply").removeAttr("disabled", true);
                            $("#applybtn-txt").text("Apply");
                            $("#applybtn-spinner").removeClass("spinner-border spinner-border-sm");
                        }
                    path = url + "action";
                    ajaxRequest(path, data, "JSON", beforeSend, complete, success);

                }
            } else {
                alert('Please select row');
            }
        } else {
            alert('Please select an action');
        }
    })
}



function create() {
    $(document).on('click', '#create', function() {
        let voucher = $("#voucher").val();
        let type = $("#type").val();
        let deduction = $("#deduction").val();
        let category = $("#category").val();
        let service = $("#service").val();
        let days = $("#days").val();
        let status = $("#status").val();
        if (voucher !== "" && type !== "" && deduction !== "" && category !== "" && service !== "" && days !== "" && status !== "") {
            data = {
                voucher: voucher,
                type: type,
                deduction: deduction,
                category: category,
                service: service,
                days: days,
                status: status,
            }

            beforeSend = () => {
                    $("#create").attr("disabled", "disabled");
                    $("#btn-txt").text("saving...");
                    $("#btn-spinner").addClass("spinner-border spinner-border-sm");

                },

                success = (response) => {
                    if (response !== "") {
                        if (response.code == 200) {
                            toast("Success", response.message, "success");
                            $('#form').trigger('reset');
                            view();
                        } else {
                            toast("Oops", response.message, "error");
                        }

                    } else {
                        toast("Oops", "An error occured", "error");

                    }

                },
                complete = (response) => {
                    $("#create").removeAttr("disabled", true);
                    $("#btn-txt").text("Save");
                    $("#btn-spinner").removeClass("spinner-border spinner-border-sm");
                }
            path = url + "create";
            ajaxRequest(path, data, "JSON", beforeSend, complete, success);

        } else {
            toast("Oops", "Fill the required fields", "error");
        }
    })
}



function view() {
    $.ajax({
        url: url,
        dataType: "HTML",
        success: function(response) {
            $("#tableContainer").html(response);
            $('#table').DataTable({ stateSave: true, "ordering": false });
        }
    });
}





function edit() {
    $(document).on('click', '#edit', function() {
        let data_id = $(this).attr('data-id');
        if (data_id !== "") {
            data = {
                id: data_id,
            };
            beforeSend = () => { $(this).LoadingOverlay("show") },
                success = (response) => {
                    if (response !== "") {
                        if (response.code == 200) {
                            // console.log(response);
                            $('#data_id').val(response.data.id);
                            $('#voucher_').val(response.data.code);
                            $('#type_').val(response.data.type);
                            $('#service_').val(response.data.service);
                            $('#deduction_').val(response.data.deduction);
                            $('#days_').val(response.data.days);
                            $('#status_').val(response.data.status);
                            $('#updateModel').modal('show');
                        } else {
                            toast("Oops", response.message, "error");
                        }

                    } else {
                        toast("Oops", "An error occured", "error");

                    }

                },
                complete = (response) => { $(this).LoadingOverlay("hide") }
            path = url + "edit";
            ajaxRequest(path, data, "JSON", beforeSend, complete, success);

        }
    });
}




function update() {
    $(document).on('click', '#update', function() {
        let data_id = $('#data_id').val();
        let voucher = $("#voucher_").val();
        let type = $("#type_").val();
        let deduction = $("#deduction_").val();
        let category = $("#category_").val();
        let service = $("#service_").val();
        let days = $("#days_").val();
        let status = $("#status_").val();
        if (voucher !== "" && type !== "" && deduction !== "" && category !== "" && service !== "" && days !== "" && status !== "") {
            data = {
                id: data_id,
                voucher: voucher,
                type: type,
                deduction: deduction,
                category: category,
                service: service,
                days: days,
                status: status,
            };

            beforeSend = () => {
                    $("#update").attr("disabled", "disabled");
                    $("#update_btn-txt").text("updating...");
                    $("#update_btn-spinner").addClass("spinner-border spinner-border-sm");

                },

                success = (response) => {
                    if (response !== "") {
                        if (response.code == 200) {
                            toast("Success", response.message, "success");
                            $('#form').trigger('reset');
                            view();
                        } else {
                            toast("Oops", response.message, "error");
                        }

                    } else {
                        toast("Oops", "An error occured", "error");

                    }

                },
                complete = (response) => {
                    $("#update").removeAttr("disabled", true);
                    $("#update_btn-txt").text("Update");
                    $("#update_btn-spinner").removeClass("spinner-border spinner-border-sm");
                }
            path = url + "update";
            ajaxRequest(path, data, "JSON", beforeSend, complete, success);

        } else {
            alert("Please fill the required field");
        }
    });
}




function delete_() {
    $(document).on('click', '#delete', function() {
        let message = "Are you sure you want to delete this row?";
        var check = confirm(message);
        if (check == true) {
            let data_id = $(this).attr('data-id');
            if (data_id !== "") {
                data = {
                    id: data_id,
                };

                beforeSend = () => { $(this).LoadingOverlay("show") },
                    success = (response) => {
                        if (response !== "") {
                            if (response.code == 200) {
                                toast("Success", response.message, "success");
                                view();
                            } else {
                                toast("Oops", response.message, "error");
                            }

                        } else {
                            toast("Oops", "An error occured", "error");

                        }

                    },
                    complete = (response) => { $(this).LoadingOverlay("hide") }
                path = url + "delete";
                ajaxRequest(path, data, "JSON", beforeSend, complete, success);

            }
        }
    });

}
