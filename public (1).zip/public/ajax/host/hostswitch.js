$(document).ready(function() {
    $('form').on('submit', function(e) {
        e.preventDefault();
    });
    save();
    view(true);
    delete_();
    resetSelect();
});

const url = window.location.pathname.endsWith('/') ? '/switch/' : 'switch/';

function resetSelect() {
    $(document).on('change', '#service', function(){
        document.getElementById("network").value = '';
        document.getElementById("type").value = '';
        document.getElementById("host").value = '';
    })
}


function save() {
    $(document).on('click', '#save', function(e) {
        e.preventDefault();
        let service = $("#service").val();
        let network = $("#network").val();
        let type = $("#type").val();
        let host = $("#host").val();
        let phone_number = $("#phone_number").val();
        if (service !== "" && host !== "") {
            data = {
                service: service,
                network: network,
                type: type,
                host: host,
                phone_number: phone_number,
            }

            beforeSend = () => {
                    $("#save").attr("disabled", "disabled");
                    $("#btn-txt").text("saving...");
                    $("#btn-spinner").addClass("spinner-border spinner-border-sm");

                },

                success = (response) => {
                    if (response !== "") {
                        if (response.code == 200) {
                            toast("Success", response.message, "success");
                            $('#form').trigger('reset');
                            view();
                        } else {
                            toast("Oops", response.message, "error");
                        }

                    } else {
                        toast("Oops", "An error occured", "error");

                    }
                },
                complete = (response) => {
                    $("#save").removeAttr("disabled", true);
                    $("#btn-txt").text("Save");
                    $("#btn-spinner").removeClass("spinner-border spinner-border-sm");
                }
            path = url + "save";

            if (service == "DATA" || service == "AIRTIME" && type !== "" && network !== "") {
                ajaxRequest(path, data, "JSON", beforeSend, complete, success);
            } else if (service == "CABLE" || service == "ELECTRICITY" || service == "SMILE" || service == "SPECTRANET") {
                ajaxRequest(path, data, "JSON", beforeSend, complete, success);
            } else {
                toast("Oops", "Fill the required fields", "error");
            }


        } else {
            toast("Oops", "Fill the required fields", "error");
        }
    })
}


function view(loading) {
    loading == true ? $.LoadingOverlay("show") : '';
    $.ajax({
        url: url,
        dataType: "HTML",
        success: function(response) {
            $("#tableContainer").html(response);
            $('#table').DataTable({stateSave: true});
            loading == true ? $.LoadingOverlay("hide") : '';
        }
    });
}



function hide(){
    $('#type_div').attr('hidden', true);
    $('#network_div').attr('hidden', true);
    $('#type').html("<option value=''> Select service </option>");
}

function show() {
    $('#type_div').removeAttr('hidden', true);
    $('#network_div').removeAttr('hidden', true);
}


$(document).on('change', '#service', function(){
    $('#type').html("");
    if ($(this).val() !== "") {
        let value = $(this).val();
        if (value == "DATA"){
            show();
            $('#type').append("<option value=''> Please select </option> <option value='GIFTING'> GIFTING </option> <option value='SME'> SME </option> <option value='COOPERATE'> COOPERATE GIFTING </option>");
		} else if (value == "AIRTIME") {
            show();
            $('#type').append("<option value=''> Please select </option> <option value='VTU'> VTU </option> <option value='SNS'> SNS </option>");
		} else {
            hide();
        }
    } else {
        hide();
    }
})



$(document).on('change', '#host', function() {
	let host = $("#host").val();
        $("#phone_number").val("");
	if (host == "SMS") {
		$("#phone-div").removeAttr("hidden");
	} else {
		$("#phone-div").attr("hidden", "hidden");
	}
})




function delete_() {
    $(document).on('click', '#delete', function() {
        let message = "Are you sure you want to delete this row?";
        var check = confirm(message);
        if (check == true) {
            let data_id = $(this).attr('data-id');
            if (data_id !== "") {
                data = {
                    id: data_id,
                };

                beforeSend = () => { $(this).LoadingOverlay("show") },
                    success = (response) => {
                        if (response !== "") {
                            if (response.code == 200) {
                                toast("Success", response.message, "success");
                                view();
                            } else {
                                toast("Oops", response.message, "error");
                            }

                        } else {
                            toast("Oops", "An error occured", "error");

                        }

                    },
                    complete = (response) => { $(this).LoadingOverlay("hide") }
                path = url + "delete";
                ajaxRequest(path, data, "JSON", beforeSend, complete, success);

            }
        }
    });

}

