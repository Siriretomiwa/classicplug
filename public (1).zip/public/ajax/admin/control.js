$(document).ready(function() {
    $('form').on('submit', function(e) {
        e.preventDefault();
    });
    create();
    view();
    delete_();
});


const url = window.location.pathname.endsWith('/') ? '/admin/' : 'admin/';




function create() {
    $(document).on('click', '#create', function() {
        let username = $("#username").val();
        let email = $("#email").val();
        let password = $("#password").val();
        let confirm_password = $("#confirm_password").val();
        let modify_service = $("#modify_service").val();
        let allow_funding = $("#allow_funding").val();
        let modify_transaction = $("#modify_transaction").val();
        let modify_user = $("#modify_user").val();
        if (username !== "" && email !== "" && password !== "" && confirm_password !== "" && modify_service !== ""
            && allow_funding !== "" && modify_transaction !== "" && modify_user !== "") {
            if (password == confirm_password) {
            data = {
                username: username,
                email: email,
                password: password,
                confirm_password: confirm_password,
                modify_service: modify_service,
                allow_funding: allow_funding,
                modify_transaction: modify_transaction,
                modify_user: modify_user
            }

            beforeSend = () => {
                    $("#create").attr("disabled", "disabled");
                    $("#btn-txt").text("saving...");
                    $("#btn-spinner").addClass("spinner-border spinner-border-sm");

                },

                success = (response) => {
                    if (response !== "") {
                        if (response.code == 200) {
                            toast("Success", response.message, "success");
                            $('#form').trigger('reset');
                            view();
                        } else {
                            toast("Oops", response.message, "error");
                        }

                    } else {
                        toast("Oops", "An error occured", "error");

                    }

                },
                complete = (response) => {
                    $("#create").removeAttr("disabled", true);
                    $("#btn-txt").text("Save");
                    $("#btn-spinner").removeClass("spinner-border spinner-border-sm");
                }
            path = url + "create";
            ajaxRequest(path, data, "JSON", beforeSend, complete, success);

            } else {
                toast("Oops", "Passwords do not match", "error");
            }

        } else {
            toast("Oops", "Fill the required fields", "error");
        }
    })
}


function view() {
    $.ajax({
        url: url,
        dataType: "HTML",
        success: function(response) {
            $("#tableContainer").html(response);
             $('#table').DataTable({stateSave: true, "ordering": false});
        }
    });
}







function delete_() {
    $(document).on('click', '#delete', function() {
        let message = "Are you sure you want to delete this row?";
        var check = confirm(message);
        if (check == true) {
            let data_id = $(this).attr('data-id');
            if (data_id !== "") {
                data = {
                    id: data_id,
                };

                beforeSend = () => { $(this).LoadingOverlay("show") },
                    success = (response) => {
                        if (response !== "") {
                            if (response.code == 200) {
                                toast("Success", response.message, "success");
                                view();
                            } else {
                                toast("Oops", response.message, "error");
                            }

                        } else {
                            toast("Oops", "An error occured", "error");

                        }

                    },
                    complete = (response) => { $(this).LoadingOverlay("hide") }
                path = url + "delete";
                ajaxRequest(path, data, "JSON", beforeSend, complete, success);

            }
        }
    });

}



