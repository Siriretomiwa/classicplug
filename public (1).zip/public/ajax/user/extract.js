$(document).ready(function() {
    $('form').on('submit', function(e) {
        e.preventDefault();
    });
    extract();
});


const url = window.location.pathname.endsWith('/') ? '/extract-data/' : 'extract-data/';

function extract() {
    $(document).on('click', '#save', function() {
        let value = $("#value").val();
        if (value !== "") {
            data = {
                value: value,
            }

            beforeSend = () => {
                    $("#save").attr("disabled", "disabled");
                    $("#btn-txt").text("saving...");
                    $("#btn-spinner").addClass("spinner-border spinner-border-sm");
                },

                success = (response) => {
                    if (response !== "") {
                        if (response.code == 200) {
                            $('.response_div').removeAttr('hidden', true);
                            $('#response').html(response.data.toString());
                            // toast("Success", response.message, "success");
                            $("#save").removeAttr("disabled", true);
                            $("#btn-txt").text("Save");
                            $("#btn-spinner").removeClass("spinner-border spinner-border-sm");
                        } else {
                            $('.response_div').attr('hidden', true);
                            toast("Oops", response.message, "error");
                        }

                    } else {
                        toast("Oops", "An error occured", "error");
                    }

                },
                complete = (response) => {
                    $("#save").removeAttr("disabled", true);
                    $("#btn-txt").text("Fetch");
                    $("#btn-spinner").removeClass("spinner-border spinner-border-sm");
                }
            path = url;
            ajaxRequest(path, data, "JSON", beforeSend, complete, success);

        } else {
            toast("Oops", "Fill the required fields", "error");
        }
    })
}


