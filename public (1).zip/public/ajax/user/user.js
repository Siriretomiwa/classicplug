$(document).ready(function() {
    $('form').on('submit', function(e) {
        e.preventDefault();
    });

     view(true);
     filter();
     search();
     entries();
     pagination();
     delete_();
     edit();
     update();
});


const url = window.location.pathname.endsWith('/') ? '/users/' : 'users/';

function view(loading) {
    let storedPage = sessionStorage.getItem('user_page');
    let page = storedPage !== null ? storedPage :  1;
    /* Search */
    storedSearch = sessionStorage.getItem('user_search');
    storedSearch !== null ? $('#search').val(storedSearch) :  $('#search').val();
    let search = $('#search').val();
    /* Entries */
    storedEntries = sessionStorage.getItem('user_entries');
    storedEntries !== null ? $('#entries').val(storedEntries) :  $('#entries').val();
    let entries = $('#entries').val();

    let filter = $('#filter').val();
    loading == true ? $.LoadingOverlay("show") : '';
    $.ajax({
        type: "GET",
        url: url + "?page=" + page + "&search=" + search + "&filter=" + filter + "&entries=" + entries,
        success: function(data) {
            $('#tableContainer').html(data);
            loading == true ? $.LoadingOverlay("hide") : '';
        },
        error: function(e) {
            loading == true ? $.LoadingOverlay("hide") : '';
        }
    });
}




function filter() {
	$(document).on('change', '#filter', function(){
        view();
	});
	}



    function entries() {
        $(document).on('change', '#entries', function(){
            var entries = $('#entries').val();
            sessionStorage.setItem('user_entries', entries);
            view();
        });
    }



function search() {
	$(document).on('keyup', '#search', function(){
        var search = $('#search').val();
        sessionStorage.setItem('user_search', search);
        view();

	});
	}



function pagination() {
    $(document).on('click', '#pagination', function(event) {
        event.preventDefault();
        let page = $(this).attr('href').split('page=')[1];
        sessionStorage.setItem('user_page', page);
        let search = $('#search').val();
        let entries = $('#entries').val();
        let filter = $('#filter').val();
        $.LoadingOverlay("show");
        $.ajax({
            url: url + "?page=" + page + "&search=" + search + "&filter=" + filter + "&entries=" + entries,
            success: function(data) {
                $('#tableContainer').html(data);
                $.LoadingOverlay("hide");
            },
            error: function(e) {
                $.LoadingOverlay("hide");
            }
        });
    })
}




function delete_() {
    $(document).on('click', '#delete', function() {
        let message = "Are you sure you want to delete this row?";
        var check = confirm(message);
        if (check == true) {
            let data_id = $(this).attr('data-id');
            if (data_id !== "") {
                data = {
                    id: data_id,
                };

                beforeSend = () => { $(this).LoadingOverlay("show") },
                    success = (response) => {
                        if (response !== "") {
                            if (response.code == 200) {
                                toast("Success", response.message, "success");
                                view();
                            } else {
                                toast("Oops", response.message, "error");
                            }

                        } else {
                            toast("Oops", "An error occured", "error");

                        }

                    },
                    complete = (response) => { $(this).LoadingOverlay("hide") }
                path = url + "delete";
                ajaxRequest(path, data, "JSON", beforeSend, complete, success);

            }
        }
    });

}



function edit() {
    $(document).on('click', '#edit', function() {
        let data_id = $(this).attr('data-id');
        if (data_id !== "") {
            data = {
                id: data_id,
            };
            beforeSend = () => { $(this).LoadingOverlay("show") },
                success = (response) => {
                    if (response !== "") {
                        if (response.code == 200) {
                            // console.log(response);
                            $('#data_id').val(response.data.id);
                            $('#username_').val(response.data.username);
                            $('#email_').val(response.data.email);
                            $('#firstname_').val(response.data.firstname);
                            $('#lastname_').val(response.data.lastname);
                            $('#phone_number_').val(response.data.phone_number);
                            $('#apikey_').val(response.data.apikey);
                            $('#status_').val(response.data.status);
                            $('#update').modal('show');
                        } else {
                            toast("Oops", response.message, "error");
                        }

                    } else {
                        toast("Oops", "An error occured", "error");

                    }

                },
                complete = (response) => { $(this).LoadingOverlay("hide") }
            path = url + "edit";
            ajaxRequest(path, data, "JSON", beforeSend, complete, success);

        }
    });
}





function update() {
    $(document).on('click', '#update-tranx', function() {
        let data_id = $('#data_id').val();
        let firstname = $('#firstname_').val();
        let lastname = $('#lastname_').val();
        let phone_number = $('#phone_number_').val();
        let apikey = $('#apikey_').val();
        let status = $('#status_').val();
        if (data_id !== "" && firstname !== "" && lastname !== "" && phone_number !== "" && apikey !== "" && status !== "") {
            data = {
                id: data_id,
                firstname: firstname,
                lastname: lastname,
                phone_number: phone_number,
                apikey: apikey,
                status: status,
            };

            beforeSend = () => {
                    $("#update-tranx").attr("disabled", "disabled");
                    $("#update_btn-txt").text("updating...");
                    $("#update_btn-spinner").addClass("spinner-border spinner-border-sm");

                },

                success = (response) => {
                    if (response !== "") {
                        if (response.code == 200) {
                            toast("Success", response.message, "success");
                            $('#form').trigger('reset');
                            view();
                        } else {
                            toast("Oops", response.message, "error");
                        }

                    } else {
                        toast("Oops", "An error occured", "error");

                    }

                },
                complete = (response) => {
                    $("#update-tranx").removeAttr("disabled", true);
                    $("#update_btn-txt").text("Update");
                    $("#update_btn-spinner").removeClass("spinner-border spinner-border-sm");
                }
            path = url + "update";
            ajaxRequest(path, data, "JSON", beforeSend, complete, success);

        } else {
            alert("Please fill the required field");
        }
    });
}
