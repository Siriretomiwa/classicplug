$(document).ready(function() {
    $('form').on('submit', function(e) {
        e.preventDefault();
    });
    resetPIN();
});


const url = window.location.pathname.endsWith('/') ? '/pin/' : 'pin/';

function resetPIN() {
    $(document).on('click', '#proceed', function() {
        let user = $("#user").val();
        let pin = $("#pin").val();
        if (user !== "") {
            data = {
                user: user,
                pin: pin,
            }

            beforeSend = () => {
                    $("#proceed").attr("disabled", "disabled");
                    $("#btn-txt").text("processing...");
                    $("#btn-spinner").addClass("spinner-border spinner-border-sm");

                },

                success = (response) => {
                    if (response !== "") {
                        if (response.code == 200) {
                            // toast("Success", response.message, "success");
                            swal.fire({
                                title: "Successful",
                                text: response.message,
                                type: "success",
                                button: "Okay",
                            });
                            $('#form').trigger('reset');
                        } else {
                            toast("Oops", response.message, "error");
                        }

                    } else {
                        toast("Oops", "An error occured", "error");

                    }

                },
                complete = (response) => {
                    $("#proceed").removeAttr("disabled", true);
                    $("#btn-txt").text("Proceed");
                    $("#btn-spinner").removeClass("spinner-border spinner-border-sm");
                }
            path = url;
            ajaxRequest(path, data, "JSON", beforeSend, complete, success);

        } else {
            toast("Oops", "Fill the required fields", "error");
        }
    })
}


