$(document).ready(function() {
    $('form').on('submit', function(e) {
        e.preventDefault();
    });
    view(true);
    apply();
    pagination();
    delete_();
    edit();
    update();
    actions();
    viewMore();
    action();
    allActions();
    viewAll();
    filter();
    search();
    entries();
});


const url = window.location.pathname.endsWith('/') ? '/transactions/' : 'transactions/';

function apply() {
    $(document).on('click', '#apply', function(e) {
        e.preventDefault();
        let action = $('#action').val();
        if (action !== "") {
            let arr = [];
            $(".checkbox:checked").each(function() {
                arr.push($(this).attr('data-id'));
            });
            if (arr.length !== 0) {
                let message = "";
                if (action == "reversed" || action == "delete") {
                    message = action == "reversed" ? "Are you sure you want to refund this row?" : "Are you sure you want to delete this row?";
                } else {
                    message = "Are you sure you want to set this row " + action + "?";
                }
                var check = confirm(message);
                if (check == true) {

                    data = {
                        action: action,
                        arr: arr,
                    }

                    beforeSend = () => {
                            $("#apply").attr("disabled", "disabled");
                            $("#applybtn-txt").text("processing...");
                            $("#applybtn-spinner").addClass("spinner-border spinner-border-sm");

                        },

                        success = (response) => {
                            if (response !== "") {
                                if (response.code == 200) {
                                    toast("Success", response.message, "success");
                                    view();
                                } else {
                                    toast("Oops", response.message, "error");
                                }

                            } else {
                                toast("Oops", "An error occured", "error");

                            }

                        },
                        complete = (response) => {
                            $("#apply").removeAttr("disabled", true);
                            $("#applybtn-txt").text("Apply");
                            $("#applybtn-spinner").removeClass("spinner-border spinner-border-sm");
                        }
                    path = url + "bulk-action";
                    ajaxRequest(path, data, "JSON", beforeSend, complete, success);

                }
            } else {
                alert('Please select row');
            }
        } else {
            alert('Please select an action');
        }
    })
}





function pagination() {
    $(document).on('click', '#pagination', function(event) {
        event.preventDefault();
        let page = $(this).attr('href').split('page=')[1];
        sessionStorage.setItem('page', page);
        let search = $('#search').val();
        let entries = $('#entries').val();
        let filter = $('#filter').val();

        $.LoadingOverlay("show");
        $.ajax({
            url: url + "?page=" + page + "&search=" + search + "&filter=" + filter + "&entries=" + entries,
            success: function(data) {
                $('#tableContainer').html(data);
                // All actions
                if ($(".all_actions").is(":checked")) {
                    $('.tranx_action').removeAttr('hidden', true);
                } else {
                    $('.tranx_action').attr('hidden', 'hidden');
                }

                // All views
                if ($(".view_all").is(":checked")) {
                    $('.tranx_view').removeAttr('hidden', true);
                } else {
                    $('.tranx_view').attr('hidden', 'hidden');
                }

                $.LoadingOverlay("hide");
            },
            error: function(e) {
                $.LoadingOverlay("hide");
            }
        });
    })
}


function view(loading) {
    let storedPage = sessionStorage.getItem('page');
    let page = storedPage !== null ? storedPage :  1;
    /* Search */
    storedSearch = sessionStorage.getItem('search');
    storedSearch !== null ? $('#search').val(storedSearch) :  $('#search').val();
    let search = $('#search').val();
    /* Entries */
    storedEntries = sessionStorage.getItem('entries');
    storedEntries !== null ? $('#entries').val(storedEntries) :  $('#entries').val();
    let entries = $('#entries').val();
    /* Filter */
    storedFilter = sessionStorage.getItem('filter');
    storedFilter !== null ? $('#filter').val(storedFilter) :  $('#filter').val();
    let filter = $('#filter').val();
    loading == true ? $.LoadingOverlay("show") : '';
    $.ajax({
        type: "GET",
        url: url + "?page=" + page + "&search=" + search + "&filter=" + filter + "&entries=" + entries,
        success: function(data) {
            $('#tableContainer').html(data);

            if ($(".view_all").is(":checked")) {
                $('.tranx_view').removeAttr('hidden', true);
            } else {
                $('.tranx_view').attr('hidden', 'hidden');
            }


            if ($(".all_actions").is(":checked")) {
                $('.tranx_action').removeAttr('hidden', true);
            } else {
                $('.tranx_action').attr('hidden', 'hidden');
            }

           loading == true ? $.LoadingOverlay("hide") : '';
        },
        error: function(e) {
            loading == true ? $.LoadingOverlay("hide") : '';
        }
    });
}


function edit() {
    $(document).on('click', '#edit', function() {
        let data_id = $(this).attr('data-id');
        if (data_id !== "") {
            data = {
                id: data_id,
            };
            beforeSend = () => { $(this).LoadingOverlay("show") },
                success = (response) => {
                    if (response !== "") {
                        if (response.code == 200) {
                            // console.log(response);
                            $('#data_id').val(response.data.id);
                            $('#username_').val(response.data.username);
                            $('#email_').val(response.data.email);
                            $('#service_').val(response.data.service);
                            $('#service_provider_').val(response.data.provider);
                            $('#description_').val(response.data.description);
                            $('#amount_').val(response.data.amount);
                            $('#type_').val(response.data.type);
                            $('#reference_').val(response.data.reference);
                            $('#status_').val(response.data.status);
                            $('#update').modal('show');
                        } else {
                            toast("Oops", response.message, "error");
                        }

                    } else {
                        toast("Oops", "An error occured", "error");

                    }

                },
                complete = (response) => { $(this).LoadingOverlay("hide") }
            path = url + "edit";
            ajaxRequest(path, data, "JSON", beforeSend, complete, success);

        }
    });
}



function delete_() {
    $(document).on('click', '#delete', function() {
        let data_id = $(this).attr('data-id');
        let description = $('#desc_txt_'+data_id).text();
        let username = $('#username_txt_'+data_id).text();
        let message = "Are you sure you want to delete this transaction? Username: "+ username + " | " + description;
        var check = confirm(message);
        if (check == true) {
            if (data_id !== "") {
                data = {
                    id: data_id,
                };

                beforeSend = () => { $(this).LoadingOverlay("show") },
                    success = (response) => {
                        if (response !== "") {
                            if (response.code == 200) {
                                toast("Success", response.message, "success");
                                view();
                            } else {
                                toast("Oops", response.message, "error");
                            }

                        } else {
                            toast("Oops", "An error occured", "error");

                        }

                    },
                    complete = (response) => { $(this).LoadingOverlay("hide") }
                path = url + "delete";
                ajaxRequest(path, data, "JSON", beforeSend, complete, success);

            }
        }
    });

}



function update() {
    $(document).on('click', '#update-tranx', function() {
        let data_id = $('#data_id').val();
        let provider = $('#service_provider_').val();
        let description = $('#description_').val();
        let amount = $('#amount_').val();
        let reference = $('#reference_').val();
        let type = $('#type_').val();
        if (data_id !== "" && provider !== "" && description !== "" && amount !== "" && reference !== "" && type !== "") {
            data = {
                id: data_id,
                type: type,
                reference: reference,
                description: description,
                provider: provider,
                amount: amount,
            };

            beforeSend = () => {
                    $("#update-tranx").attr("disabled", "disabled");
                    $("#update_btn-txt").text("updating...");
                    $("#update_btn-spinner").addClass("spinner-border spinner-border-sm");

                },

                success = (response) => {
                    if (response !== "") {
                        if (response.code == 200) {
                            toast("Success", response.message, "success");
                            $('#form').trigger('reset');
                            view();
                        } else {
                            toast("Oops", response.message, "error");
                        }

                    } else {
                        toast("Oops", "An error occured", "error");

                    }

                },
                complete = (response) => {
                    $("#update-tranx").removeAttr("disabled", true);
                    $("#update_btn-txt").text("Update");
                    $("#update_btn-spinner").removeClass("spinner-border spinner-border-sm");
                }
            path = url + "update";
            ajaxRequest(path, data, "JSON", beforeSend, complete, success);

        } else {
            alert("Please fill the required field");
        }
    });
}


// -------

function actions() {
    $(document).on('click', '#actions', function() {
        let action_id  = $(this).attr('data-id');
        let action_txt = $(this).html();
        if (action_txt == "Actions") {
            $('#action-btn-div-'+action_id).removeAttr('hidden', true);
            $(this).html('Hide Actions')
        } else {
            $('#action-btn-div-'+action_id).attr('hidden', 'hidden');
            $(this).html('Actions')
        }
    })
}


function viewMore() {
    $(document).on('click', '#viewMore', function() {
        let view_id  = $(this).attr('data-id');
        let view_txt = $(this).html();
        // console.log(view_txt);
        if (view_txt == "View") {
            $('#view-item-'+view_id).removeAttr('hidden', true);
            $(this).html('View Less')
        } else {
            $('#view-item-'+view_id).attr('hidden', 'hidden');
            $(this).html('View')
        }
    })
}


function allActions() {
    $(document).on('change', '.all_actions', function() {
        if ($(".all_actions").is(":checked")) {
            $('.tranx_action').removeAttr('hidden', true);
        } else {
            $('.tranx_action').attr('hidden', 'hidden');
        }
    })
}


function viewAll() {
    $(document).on('change', '.view_all', function() {
        if ($(".view_all").is(":checked")) {
            $('.tranx_view').removeAttr('hidden', true);
        } else {
            $('.tranx_view').attr('hidden', 'hidden');
        }
    })
}


function badgeStatus(badge_id, badge, status) {
    badge_id.removeClass();
    badge_id.attr('class', 'badge '+badge);
    badge_id.text(status)
}


// Single Action
function action() {
    $(document).on('click', '#action-status', function() {
        let id = $(this).attr('data-id');
        let option = $(this).attr('data-status');
        let badge_id = $('#badge-status-'+id);
        // console.log(option + ' - ' + id);
        if (id !== "" && option !== "") {
            data = {
                id: id,
                status: option,
            };
            beforeSend = () => { $(this).LoadingOverlay("show") },
                success = (response) => {
                    if (response !== "") {
                        if (response.code == 200) {
                            toast("Success", response.message, "success");
                            let status = null;
                            switch(response.status) {
                                case 'success': badgeStatus(badge_id, "badge-success", response.status);
                                    break;
                                case 'pending': badgeStatus(badge_id, "badge-warning", response.status);
                                    break;
                                case 'initiated': badgeStatus(badge_id, "badge-warning", response.status);
                                    break;
                                case 'cancel': badgeStatus(badge_id, "badge-danger", response.status);
                                    break;
                                case 'reversed': badgeStatus(badge_id, "badge-danger", response.status);
                                    break;
                                case 'processing': badgeStatus(badge_id, "badge-initiated", response.status);
                                    break;
                                default: "badge-warning";
                            }

                        $('#badge').addClass(status);
                            view();
                            // console.log(status);

                        } else {
                            toast("Oops", response.message, "error");
                        }

                    } else {
                        toast("Oops", "An error occured", "error");

                    }

                },
                complete = (response) => { $(this).LoadingOverlay("hide") }
            path = url + "action";
            ajaxRequest(path, data, "JSON", beforeSend, complete, success);

        }
    });
}



function filter() {
	$(document).on('change', '#filter', function(){
        var filter = $('#filter').val();
        sessionStorage.setItem('page', 1);
        sessionStorage.setItem('filter', filter);
        view();
	});
}



    function entries() {
        $(document).on('change', '#entries', function(){
            var entries = $('#entries').val();
            sessionStorage.setItem('page', 1);
            sessionStorage.setItem('entries', entries);
            view();
        });
    }




function search() {
	$(document).on('keyup', '#search', function(){
        var search = $('#search').val();
        sessionStorage.setItem('page', 1);
        sessionStorage.setItem('filter', "All");
        sessionStorage.setItem('search', search);
        view();

	});
	}
