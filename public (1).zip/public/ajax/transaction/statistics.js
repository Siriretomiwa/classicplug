$(document).ready(function(){
    $('form').on('submit', function(e) {
        e.preventDefault();
    });
    // chartDisplay();
    fetch();
})

const url = window.location.pathname.endsWith('/') ? '/statistics/' : 'statistics/';

function lineChart(dom, data, label, color) {

        // var parsedObj = {MTN: 1, GLO: 2, AIRTEL: 3, NINE_MOBILE: 5};

			var chartdata = {
				labels: ["MTN", "GLO", "AIRTEL", "9MOBILE"],
				datasets: [
					{
						label: label,
						fill: false,
						lineTension: 0.1,
						backgroundColor: color,
						borderColor: color,
						pointHoverBackgroundColor: "rgba(59, 89, 152, 1)",
						pointHoverBorderColor: "rgba(59, 89, 152, 1)",
						data: [data.mtn, data.glo, data.airtel, data._9mobile]
					},

				]
			};

			var ctx = $("#"+dom);

			var LineGraph = new Chart(ctx, {
				type: 'line',
				data: chartdata
			});
        }



        function pieChart(dom, data) {

                var chartdata = {
                    labels: ["GOTV", "DSTV", "STARTIMES"],
                    datasets: [
                        {
                            label: "Cable Chart",
                            fill: false,
                            lineTension: 0.1,
                            backgroundColor: [
                                "#298400",
                                "#0000ff",
                                "#e61b23",
                            ],
                            pointHoverBackgroundColor: "rgba(59, 89, 152, 1)",
                            pointHoverBorderColor: "rgba(59, 89, 152, 1)",
                            data: [data.gotv, data.dstv, data.startimes],
                        },

                    ]
                };

                var ctx = $("#"+dom);

                var pieGraph = new Chart(ctx, {
                    type: 'doughnut',
                    data: chartdata
                });
            }



            function barChart(dom, data) {

                var chartdata = {
                    labels: ["IBEDC", "IKEDC", "EKEDC", "EEDC", "KAEDC", "PHEDC", "KEDC", "JEDC"],
                    datasets: [
                        {
                            label: "Bills Chart",
                            fill: false,
                            lineTension: 0.1,
                            backgroundColor: "#00acee",
                            borderColor: "#00acee",
                            pointHoverBackgroundColor: "rgba(59, 89, 152, 1)",
                            pointHoverBorderColor: "rgba(59, 89, 152, 1)",
                            data: [ data.ibedc, data.ikedc, data.ekedc, data.eedc, data.kaedc, data.phedc, data.kedc, data.jedc ]
                        },

                    ]
                };

                var ctx = $("#"+dom);

                var barGraph = new Chart(ctx, {
                    type: 'bar',
                    data: chartdata
                });
            }



function salesResult(data, dom) {
var sum = parseInt(data.mtn) + parseInt(data.glo) + parseInt(data.airtel) + parseInt(data._9mobile);
var resp = "<div class='row text-center'><div class='col'><h4 class='text-warning'>₦" +
    data.mtn + "</h4><p class='text-muted'>MTN</p></div><div class='col'><h4 class='text-success'>₦" +
	data.glo + "</h4><p class='text-muted'>GLO</p></div><div class='col'><h4 class='text-danger'>₦" +
	data.airtel + "</h4><p class='text-muted'>AIRTEL</p></div><div class='col'><h4 class='text-success'>₦" +
	data._9mobile + "</h4><p class='text-muted'>9MOBILE</p></div><div class='col'><h4 class='text-primary'>₦" +
	sum +"</h4><p class='text-muted'>TOTAL</p></div>";

    $("#"+dom).html(resp);
}

function cableResult(data, dom) {
    var sum = parseInt(data.gotv) + parseInt(data.dstv) + parseInt(data.startimes);
    var resp = "<div class='row text-center'><div class='col'><h4 class='text-warning'>₦" +
        data.gotv + "</h4><p class='text-muted'>GOTV</p></div><div class='col'><h4 class='text-success'>₦" +
        data.dstv + "</h4><p class='text-muted'>DSTV</p></div><div class='col'><h4 class='text-danger'>₦" +
        data.startimes + "</h4><p class='text-muted'>STARTIMES</p></div><div class='col'><h4 class='text-primary'>₦" +
        sum +"</h4><p class='text-muted'>TOTAL</p></div>";

        $("#"+dom).html(resp);
    }



function fetch() {
    $(document).on('click', '#submit', function() {
        let from_date = $("#from_date").val();
        let to_date = $("#to_date").val();
        let username = $("#username").val();
        if (from_date !== "" && to_date !== "") {
            data = {
                from_date: from_date,
                to_date: to_date,
                username: username,
            }

            beforeSend = () => {
                    $("#submit").attr("disabled", "disabled");
                    $("#btn-txt").text("fetching...");
                    $("#btn-spinner").addClass("spinner-border spinner-border-sm");
                },

                success = (response) => {
                    if (response !== "") {
                        if (response.code == 200) {
                            // toast("Success", response.message, "success");
                            lineChart('data_chart', response.data.data, "Data Chart", "#ff0000");
                            lineChart('airtime_chart', response.data.airtime, "Airtime Chart", "#9261c6");
                            pieChart('cable_chart', response.data.cable, "Cable Chart");
                            barChart('bills_chart', response.data.bills, "Bills Chart");

                            salesResult(response.data.data, 'data_response');

                            // Data statistics
                            $('#mtn_data_stat').html(response.data.data_stat.mtn);
                            $('#glo_data_stat').html(response.data.data_stat.glo);
                            $('#airtel_data_stat').html(response.data.data_stat.airtel);
                            $('#_9mobile_data_stat').html(response.data.data_stat._9mobile);

                            salesResult(response.data.airtime, 'airtime_response');
                            cableResult(response.data.cable, 'cable_response');

                            $('#result_cards').removeAttr('hidden');

                            $("#submit").removeAttr("disabled", true);
                            $("#btn-txt").text("View Statistics");
                            $("#btn-spinner").removeClass("spinner-border spinner-border-sm");
                        } else {
                            $('#result_cards').attr('hidden', true);
                            toast("Oops", response.message, "error");
                        }

                    } else {
                        toast("Oops", "An error occured", "error");

                    }

                },
                complete = (response) => {
                    $("#submit").removeAttr("disabled", true);
                    $("#btn-txt").text("View Statistics");
                    $("#btn-spinner").removeClass("spinner-border spinner-border-sm");
                }
            path = url;
            ajaxRequest(path, data, "JSON", beforeSend, complete, success);

        } else {
            toast("Oops", "Fill the required fields", "error");
        }
    })
}

