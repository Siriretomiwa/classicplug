$(document).ready(function() {
    $('form').on('submit', function(e) {
        e.preventDefault();
    });
    log();
});


const url = window.location.pathname.endsWith('/') ? '/log/' : 'log/';

function log() {
    $(document).on('click', '#save', function() {
        let reference = $("#reference").val();
        if (reference !== "") {
            data = {
                reference: reference,
            }

            beforeSend = () => {
                    $("#save").attr("disabled", "disabled");
                    $("#btn-txt").text("running...");
                    $("#btn-spinner").addClass("spinner-border spinner-border-sm");
                },

                success = (response) => {
                    if (response !== "") {
                        if (response.code == 200) {
                            $('.response_div').removeAttr('hidden', true);
                            $('#response').html(response.log);
                            // toast("Success", response.message, "success");
                            $("#save").removeAttr("disabled", true);
                            $("#btn-txt").text("Run");
                            $("#btn-spinner").removeClass("spinner-border spinner-border-sm");
                        } else {
                            $('.response_div').attr('hidden', true);
                            toast("Oops", response.message, "error");
                        }

                    } else {
                        toast("Oops", "An error occured", "error");
                    }

                },
                complete = (response) => {
                    $("#save").removeAttr("disabled", true);
                    $("#btn-txt").text("Run");
                    $("#btn-spinner").removeClass("spinner-border spinner-border-sm");
                }
            path = url;
            ajaxRequest(path, data, "JSON", beforeSend, complete, success);

        } else {
            toast("Oops", "Fill the required fields", "error");
        }
    })
}


