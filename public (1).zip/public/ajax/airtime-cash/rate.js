$(document).ready(function() {
    $('form').on('submit', function(e) {
        e.preventDefault();
    });
    update();
    load();
    merge();
});


const url = window.location.pathname.endsWith('/') ? '/rate/' : 'rate/';

function update() {
    $(document).on('click', '#proceed', function() {
        var arr = [];
        $('input[name="rate[]"]').each(function() {
        arr.push({
            "id": $(this).attr("data-id"),
            "value":this.value
        });
    });

        if (arr !== "") {
            data = {
                rate: arr,
            }

            beforeSend = () => {
                    $("#proceed").attr("disabled", "disabled");
                    $("#btn-txt").text("saving...");
                    $("#btn-spinner").addClass("spinner-border spinner-border-sm");

                },

                success = (response) => {
                    if (response !== "") {
                        if (response.code == 200) {
                            toast("Success", response.message, "success");
                            $('#form').trigger('reset');
                        } else {
                            toast("Oops", response.message, "error");
                        }

                    } else {
                        toast("Oops", "An error occured", "error");

                    }
                },

                complete = (response) => {
                    $("#proceed").removeAttr("disabled", true);
                    $("#btn-txt").html("Save <i class='fas fa-save'></i>");
                    $("#btn-spinner").removeClass("spinner-border spinner-border-sm");
                }
            path = url + "update";
            ajaxRequest(path, data, "JSON", beforeSend, complete, success);

        } else {
            toast("Oops", "Fill the required fields", "error");
        }
    })
}



function load() {
    $(document).on('change', '#category', function() {
        var category = $('#category').val();
        view(category, $(this));
    });
}



function view(category, thisProp) {
    $("#tableContainer").html('');
    if (category !== "") {
        $.ajax({
            url: url + "?category=" + category,
            dataType: "HTML",
            beforeSend: () => { $(thisProp).LoadingOverlay("show") },
            success: function(response) {
                $("#tableContainer").html(response);
                $('#table').DataTable({ stateSave: true, "ordering": false });
            },
            complete: (response) => { $(thisProp).LoadingOverlay("hide") }
        });
    } else { alert('Select category'); }
}



function merge() {
    $(document).on('click', '#merge', function() {
        let category_1 = $("#category_1").val();
        let category_2 = $("#category_2").val();
        if (category_1 !== "" && category_2 !== "") {
            if (category_1 !== category_2) {
            data = {
                category_1: category_1,
                category_2: category_2,
            }

            beforeSend = () => {
                    $("#merge").attr("disabled", "disabled");
                    $("#merge-txt").text("merging...");
                    $("#merge-spinner").addClass("spinner-border spinner-border-sm");

                },

                success = (response) => {
                    if (response !== "") {
                        if (response.code == 200) {
                            toast("Success", response.message, "success");
                            $('#form').trigger('reset');
                            $('#category').val(category_2);
                            view(category_2, null);
                        } else {
                            toast("Oops", response.message, "error");
                        }
                    } else {
                        toast("Oops", "An error occured", "error");

                    }

                },
                complete = (response) => {
                    $("#merge").removeAttr("disabled", true);
                    $("#merge-txt").text("Merge");
                    $("#merge-spinner").removeClass("spinner-border spinner-border-sm");
                }
            path = url + "merge";
            ajaxRequest(path, data, "JSON", beforeSend, complete, success);

            } else {
                toast("Oops", "You can't merge the same category", "error");
            }

        } else {
            toast("Oops", "Fill the required fields", "error");
        }
    })
}

