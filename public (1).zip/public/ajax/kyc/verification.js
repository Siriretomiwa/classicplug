$(document).ready(function() {
    $('form').on('submit', function(e) {
        e.preventDefault();
    });
    view(true);
    pagination();
    action();
    search();
    entries();
});


const url = window.location.pathname.endsWith('/') ? '/kyc/' : 'kyc/';


function pagination() {
    $(document).on('click', '#pagination', function(event) {
        event.preventDefault();
        let page = $(this).attr('href').split('page=')[1];
        let search = $('#search').val();
        let entries = $('#entries').val();
        let filter = $('#filter').val();
        $.LoadingOverlay("show");
        $.ajax({
            url: url + "?page=" + page + "&search=" + search + "&filter=" + filter + "&entries=" + entries,
            success: function(data) {
                $('#tableContainer').html(data);
                $.LoadingOverlay("hide");
            },
            error: function(e) {
                $.LoadingOverlay("hide");
            }
        });
    })
}


function view(loading) {
    let page = 1;
    let search = $('#search').val();
    let entries = $('#entries').val();
    let filter = $('#filter').val();
    loading == true ? $.LoadingOverlay("show") : '';
    $.ajax({
        type: "GET",
        url: url + "?page=" + page + "&search=" + search + "&filter=" + filter + "&entries=" + entries,
        success: function(data) {
            $('#tableContainer').html(data);
            loading == true ? $.LoadingOverlay("hide") : '';
        },
        error: function(e) {
            loading == true ? $.LoadingOverlay("hide") : '';
        }
    });
}



// Single Action
function action() {
    $(document).on('click', '#action-status', function() {
        let id = $(this).attr('data-id');
        let option = $(this).attr('data-status');
        // console.log(option + ' - ' + id);
        if (id !== "" && option !== "") {
            data = {
                id: id,
                status: option,
            };
            beforeSend = () => { $(this).LoadingOverlay("show") },
                success = (response) => {
                    if (response !== "") {
                        if (response.code == 200) {
                            view();
                            toast("Success", response.message, "success");
                        $('#badge').addClass(status);

                            // console.log(status);

                        } else {
                            toast("Oops", response.message, "error");
                        }

                    } else {
                        toast("Oops", "An error occured", "error");

                    }

                },
                complete = (response) => { $(this).LoadingOverlay("hide") }
            path = url + "action";
            ajaxRequest(path, data, "JSON", beforeSend, complete, success);

        }
    });
}


    function entries() {
        $(document).on('change', '#entries', function(){
            view();
        });
    }




function search() {
	$(document).on('keyup', '#search', function(){
        view();

	});
	}
