$(document).ready(function() {
    $('form').on('submit', function(e) {
        e.preventDefault();
    });
    bvnCharge();
});


const url = window.location.pathname.endsWith('/') ? '/bvn-charge/' : 'bvn-charge/';

function bvnCharge() {
    $(document).on('click', '#save', function() {
        let charge = $("#charge").val();
        if (charge !== "") {
            data = {
                charge: charge,
            }

            beforeSend = () => {
                    $("#save").attr("disabled", "disabled");
                    $("#btn-txt").text("saving...");
                    $("#btn-spinner").addClass("spinner-border spinner-border-sm");
                },

                success = (response) => {
                    if (response !== "") {
                        if (response.code == 200) {
                            toast("Success", response.message, "success");
                            $("#save").removeAttr("disabled", true);
                            $("#btn-txt").text("Save");
                            $("#btn-spinner").removeClass("spinner-border spinner-border-sm");
                        } else {
                            toast("Oops", response.message, "error");
                        }

                    } else {
                        toast("Oops", "An error occured", "error");

                    }

                },
                complete = (response) => {
                    $("#save").removeAttr("disabled", true);
                    $("#btn-txt").text("Save");
                    $("#btn-spinner").removeClass("spinner-border spinner-border-sm");
                }
            path = url;
            ajaxRequest(path, data, "JSON", beforeSend, complete, success);

        } else {
            toast("Oops", "Fill the required fields", "error");
        }
    })
}


