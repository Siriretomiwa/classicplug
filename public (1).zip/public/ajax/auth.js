const url = window.location.pathname.endsWith('/') ? '/' : '';

function login() {
    $(document).on('click', '#login', function(event) {
        event.preventDefault();
        let username = $("#username").val();
        let password = $("#password").val();
        if (username !== "" && password !== "") {

            data = {
                username: username,
                password: password,
            }

            beforeSend = () => {
                $(this).prop('disabled', true);
                $(this).html("<i class='fas fa-circle-notch fa-spin'></i> please wait...");
            }

            success = (response) => {
                // response = JSON.parse(response);
                if (response !== "") {
                    if (response.code === 200) {
                        $(this).prop('disabled', true);
                        $(this).html("<i class='fas fa-circle-notch fa-spin'></i> redirecting...");
                        window.location.href = '/';
                    } else if (response.code === 100) {
                        alert(response.message);
                        $(this).prop('disabled', false);
                        $(this).html("Login");　
                    }
                } else {
                    alert("Oops an error occured");
                }
                //    console.log(response);
            }

            complete = (response) => {}

            error = (response) => {
                $(this).prop('disabled', false);
                $(this).html("Login");　
                alert("Oops an error occured");
            }
            path = url + "login";
            ajaxRequest(path, data, "JSON", beforeSend, complete, success);


        } else {
            alert("Fill the required fields");
        }
    })
}


function register() {
    $(document).on('click', '#register', function() {
        let username = $("#username").val();
        let password = $("#password").val();
        let email = $("#email").val();
        let confirm_password = $("#confirm_password").val();
        if (username !== "" && password !== "" && email !== "" && confirm_password !== "") {
            if (password === confirm_password) {
                data = {
                    username: username,
                    password: password,
                    email: email,
                }

                beforeSend = () => {
                    $(this).prop('disabled', true);
                    $(this).html("<i class='fas fa-circle-notch fa-spin'></i> please wait...");
                }

                success = (response) => {
                    if (response !== "") {
                        if (response.code === 200) {
                            $(this).prop('disabled', true);　
                            $(this).html("<i class='fas fa-circle-notch fa-spin'></i> redirecting...");
                            window.location.href = '/login';
                        } else if (response.code === 100) {
                            alert(response.message);
                            $(this).prop('disabled', false);　
                            $(this).html("Register");　
                        }
                    } else {
                        alert("Oops an error occured");
                    }
                    //    console.log(response);
                }

                complete = (response) => {}

                error = (response) => {
                    $(this).prop('disabled', false);　
                    $(this).html("Register");　
                    alert("Oops an error occured");
                }

                path = url + "register";
                ajaxRequest(path, data, "JSON", beforeSend, complete, success);
            } else {
                alert("password do not match");
            }
        } else {
            alert("Fill the required fields");
        }
    })
}
